using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class SeleCaptureManager
    {
        /// <summary>
        /// д�����¼�
        /// </summary>
        /// <param name="c">�����¼���</param>
        /// <returns></returns>
        public bool WriteSeleCapture(Capture c)
        {
            string sql = string.Format("insert into capture values(0, '{0}', '{1}', '{2}', {3}, {4}, '{5}', '{6}', '{7}');"
            ,c.picture_path, c.Ship_number, c.capture_Time.ToString(DataHelper.DateTimeFormStr), c.target_Id,
            c.target_type, c.linkage_start.ToString(DataHelper.DateTimeFormStr), c.linkage_end.ToString(DataHelper.DateTimeFormStr),
            c.remark);

            var db = MysqlDBAccess.getInstance();
            var r = db.queryNoResponse(sql, true);
            if (r != 1)
                return false;
            return true;
        }
    }
}
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class OperationLogWriter
    {
        private MySqlConnection conn = null;


        public OperationLogWriter()
        {
            //conn = MysqlDBAccess.getInstance().openConn();
        }


        /// <summary>
        /// д������־��ͬ������
        /// </summary>
        /// <param name="ol">������־</param>
        public void WriteOperationLog(OperationLog ol)
        {
            string sql = string.Format("insert into option_log_list values ({0}, '{1}', now(), '{2}', '{3}', '{4}', {5}, 0);",
            ol.UserID, ol.OptionName, ol.Result, ol.Note, ol.IP, ol.LogType);
            MysqlDBAccess.getInstance().queryNoResponse(sql, false);
        }

        /// <summary>
        /// д������־���첽����
        /// </summary>
        /// <param name="ol">������־</param>
        public async void WriteOperationLogAsync(OperationLog ol)
        {
            await Task.Run(() =>
            {
                WriteOperationLog(ol);
            });
        }
    }
}
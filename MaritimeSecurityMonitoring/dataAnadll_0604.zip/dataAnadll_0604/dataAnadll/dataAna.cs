﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using static dataAnadll.FUS_ICD;
using YimaWF.data;
using System.Collections.Generic;
using System.Net.NetworkInformation;

namespace dataAnadll
{
    public class dataAna
    {
        //三路数据、设备状态委托接口
        public delegate void DMMmessage(int flag, object obj);
        //同步消息委托接口
        public delegate void Syncdelegate(int type,double dScanCourse = 0, float fScanSpeed = 0);
        //平台经纬度
        public static double CenterLongti = 108, CenterLati = 17;
        //初始化融合IP
        private static string fusIP = "192.6.1.102";
        //融合和态势端口
        private static int fusPort = 8123, hostPort = 8066;
        //本机开机状态
        private bool isBoot = false;
        //雷达List
        public static List<ushort> RadarKeepAlive = new List<ushort>();
        //发送到融合的字节数组
        byte[] bytes = new byte[512];
        /// <summary>
        /// 接收目标线程
        /// 发送开机报文线程
        /// 接收设备状态线程
        /// 接收同步消息线程
        /// </summary>
        private Thread RecvTargetthread, Sendthread, PushStatusthread,RecvSync;
        /// <summary>
        /// 态势发送数据的UDP实例
        /// 接收目标UDP
        /// 接收设备状态UDP
        /// 接收同步消息UDP
        /// </summary>
        private static UdpClient dmUdpClient,Recvclient, RecvStatus,RecvSyncInfo;
        public void anaInit(DMMmessage GetData, string fusip, int fusport, int hostport)
        {
            fusIP = fusip;
            fusPort = fusport;
            hostPort = hostport;
            dmUdpClient = new UdpClient(9696);//发送数据UDP实例
            Recvclient = new UdpClient(hostPort);//接收三路目标UDP
            RecvTargetthread = new Thread(Recive);//接收三路目标线程          
            Sendthread = new Thread(sendBootMsg);//发送开机报文线程
            RecvTargetthread.IsBackground = true;
            Sendthread.IsBackground = true;
            try
            {
                RecvTargetthread.Start(GetData);
                Sendthread.Start();
            }
            catch (Exception)
            {
                return;
            }

        }
        /// <summary>
        /// 设备状态初始化
        /// </summary>
        /// <param name="_dmmmesage"></param>
        public void anaInit(DMMmessage _dmmmesage)
        {
            RecvStatus = new UdpClient(8067);//接收状态端口
            PushStatusthread = new Thread(PushDeviceStatus);
            PushStatusthread.Start(_dmmmesage);
        }
        /// <summary>
        /// 同步消息初始化
        /// </summary>
        /// <param name="_syncdelegate"></param>
        public void anaInit(Syncdelegate _syncdelegate)
        {
            RecvSyncInfo = new UdpClient(8065);//接收状态端口
            RecvSync = new Thread(PushSyncInfo);
            RecvSync.Start(_syncdelegate);
        }
        /// <summary>
        /// 发送融合参数初始化函数
        /// </summary>
        /// <param name="fusip"></param>
        /// <param name="fusport"></param>
        public void anaInit(string fusip, int fusport)//发送圈层，融合参数初始化函数
        {
            fusIP = fusip;
            fusPort = fusport;
        }
        /// <summary>
        /// 退出接收网络状态
        /// </summary>
        public void anaClose()
        {
            if (PushStatusthread.IsAlive)
            {
                PushStatusthread.Abort();
            }
        }

        /// <summary>
        /// 退出接收三路数据
        /// </summary>
        public void PushDeviceStatusClose()
        {
            try
            {
                isBoot = false;
                Recvclient.Close();
                dmUdpClient.Close();
                RecvTargetthread.Abort();
                Sendthread.Abort();
                RecvSync.Abort();
            }
            catch (Exception)
            {
                return;
            }
        }
        private void Recive(object delegateGetData)
        {
            int RadarFlag = 0;
            Target target = new Target(0, 0, 0);
            DMMmessage delegateGetDat = (DMMmessage)delegateGetData;
            byte[] receiveData = new byte[110 * 1024];//容纳最大600个目标
            UDP_Head_S UdpHeads = new UDP_Head_S();
            int HeadLen = Marshal.SizeOf(UdpHeads);
            FusTarget_S udp_receive_fus = new FusTarget_S();
            int FusTargetLen = Marshal.SizeOf(udp_receive_fus);
            AISMsg_S udp_receive_ais = new AISMsg_S();
            int AisMsgLen = Marshal.SizeOf(udp_receive_ais);
            RdDetectMsg_S udp_receive_radar = new RdDetectMsg_S();
            int RadLen = Marshal.SizeOf(udp_receive_radar);
            RdStatus_S udp_receive_radarstatus = new RdStatus_S();
            IPEndPoint remotePoint = new IPEndPoint(IPAddress.Any, 0);
            while (true)
            {
                try
                {
                    receiveData = Recvclient.Receive(ref remotePoint);
                    UdpHeads = rawDeserializeHeads(receiveData);
                    switch (UdpHeads.ucDataType)
                    {
                        //融合
                        case 100:
                            {
                                for (int i = 0; i < UdpHeads.ushTgtNum; i++)
                                {
                                    byte[] fustarget = SplitArray(receiveData,HeadLen + i * FusTargetLen, FusTargetLen);//数据包反序列化
                                    udp_receive_fus = rawDeserializeFus(fustarget);
                                    target = fusToNav(udp_receive_fus);
                                    //赋值
                                    delegateGetDat(udp_receive_fus.flag, target);
                                }
                                Array.Clear(receiveData, 0, receiveData.Length);
                                break;
                            }
                        case 2:
                            {
                                for (int i = 0; i < UdpHeads.ushTgtNum; i++)
                                {
                                    byte[] fustarget = SplitArray(receiveData, HeadLen + i * AisMsgLen, AisMsgLen);//数据包反序列化
                                    udp_receive_ais = rawDeserializeAis(fustarget);
                                    //赋值
                                    target = aisToNav(udp_receive_ais);
                                    //赋值
                                    delegateGetDat(udp_receive_ais.flag, target);
                                }
                                Array.Clear(receiveData, 0, receiveData.Length);
                                break;
                            }
                        //雷达3
                        case 3:
                            {
                                for (int i = 0; i < UdpHeads.ushTgtNum; i++)
                                {
                                    byte[] fustarget = SplitArray(receiveData, HeadLen + i * RadLen, RadLen);//数据包反序列化
                                    udp_receive_radar = rawDeserializeRadar(fustarget);
                                    //赋值
                                    target = radarToNavT(udp_receive_radar,out RadarFlag);
                                    //赋值
                                    delegateGetDat(RadarFlag, target);
                                }
                                Array.Clear(receiveData, 0, receiveData.Length);
                                break;
                            }
                        //雷达状态
                        case 186:
                            {
                                for (int i = 0; i < UdpHeads.ushTgtNum; i++)
                                {
                                    byte[] fustarget = SplitArray(receiveData, (8 + i * Marshal.SizeOf(udp_receive_radarstatus)), Marshal.SizeOf(udp_receive_radarstatus));//数据包反序列化
                                    udp_receive_radarstatus = rawDeserializeRadarStatus(fustarget);
                                    //赋值
                                    delegateGetDat(186, udp_receive_radarstatus);
                                }
                                Array.Clear(receiveData, 0, receiveData.Length);
                                break;
                            }
                        case 188:
                            isBoot = true;
                            Array.Clear(receiveData, 0, receiveData.Length);
                            break;
                        default:
                            {
                                Array.Clear(receiveData, 0, receiveData.Length);
                                break;
                            }
                    }
                }
                catch (Exception)
                {  
                    Array.Clear(receiveData, 0, receiveData.Length);
                }
            }
        }
        /// <summary>
        /// 给上层提供状态信息
        /// </summary>
        /// <param name="delegateGetData">委托</param>
        private void PushDeviceStatus(object delegateGetData)
        {
            byte[] _byte = new byte[1024];
            Ping PingFus = new Ping();
            DateTime aisRec = new DateTime(1970,1,1);
            IPEndPoint remotePoint = new IPEndPoint(IPAddress.Any, 0);
            DMMmessage pushStatus = (DMMmessage)delegateGetData;
            Machine_Hardware_State MachineHardwareState = new Machine_Hardware_State();
            Machine_NetWork_State MachineNetWorkState = new Machine_NetWork_State(1);
            RdStatus_S RdStatus_S_ = new RdStatus_S();
            AIS_AlrTxt AISAlrTxt = new AIS_AlrTxt();
            byte msgID;
            while (true)
            {
                try {
                    _byte = RecvStatus.Receive(ref remotePoint);
                    msgID = Convert.ToByte(_byte[0]);
                    switch (msgID)
                    {
                        case 1:
                            _byte = SplitArray(_byte, 1, Marshal.SizeOf(MachineNetWorkState));
                            MachineNetWorkState = rawDeserializeMachineNetWorkStates(_byte);
                            pushStatus(msgID, MachineNetWorkState);
                            break;
                        case 2:
                            _byte = SplitArray(_byte, 1, Marshal.SizeOf(MachineHardwareState));
                            MachineHardwareState = rawDeserializeMachineHardWorkStates(_byte);
                            pushStatus(msgID, MachineHardwareState);
                            if (aisRec.CompareTo(new DateTime(1970, 1, 1)) != 0)//借用硬件状态的实时刷新重置AIS告警的状态
                            {
                                TimeSpan ts = DateTime.Now - aisRec;
                                if (ts.Seconds >=9)
                                {
                                    AIS_AlrTxt aisalrtxt = new AIS_AlrTxt(0,0,0,0,0,0,0,0);
                                    pushStatus(3, aisalrtxt);
                                    aisRec = new DateTime(1970, 1, 1);
                                }
                            }
                            PingReply FusReply = PingFus.Send(fusIP, 100);//检测融合服务器是否在线
                            if (FusReply.Status != IPStatus.Success)//不在线
                            {
                                PingReply FusReplyR = PingFus.Send(fusIP, 100);
                                if (FusReplyR.Status != IPStatus.Success)
                                {
                                    Machine_NetWork_State MachineNetWorkStates = new Machine_NetWork_State(1);
                                    MachineNetWorkStates.lightpingstate = MachineNetWorkState.lightpingstate;
                                    pushStatus(1, MachineNetWorkStates);//把不在线的信息推送给上层
                                }
                            }
                            else
                            {
                                pushStatus(1, MachineNetWorkState);
                            }
                            break;
                        case 3:
                            _byte = SplitArray(_byte, 1, Marshal.SizeOf(AISAlrTxt));
                            AISAlrTxt = rawDeserializeAisalrm(_byte);
                            pushStatus(msgID, AISAlrTxt);
                            aisRec = DateTime.Now;
                            break;
                        case 4:
                            _byte = SplitArray(_byte, 1, Marshal.SizeOf(RdStatus_S_));
                            RdStatus_S_ = rawDeserializeRadarStatus(_byte);
                            pushStatus(msgID, RdStatus_S_);
                            break;
                        default:
                            break;
                    }
                } catch (Exception)
                {
                    Array.Clear(_byte, 0, _byte.Length);
                }
            }
        }

        private void PushSyncInfo(object delegateSync)
        {
            byte[] receiveData = new byte[1024];
            UDP_Head_S UdpHeads = new UDP_Head_S();
            IPEndPoint remotePoint = new IPEndPoint(IPAddress.Any, 0);
            RdScanCourse_S RdScanCourse_S_ = new RdScanCourse_S();
            Syncdelegate _delegateSync = (Syncdelegate)delegateSync;
            while (true)
            {
                try
                {
                    receiveData = RecvSyncInfo.Receive(ref remotePoint);
                    UdpHeads = rawDeserializeHeads(receiveData);
                    switch (UdpHeads.ucDataType)
                    {
                        case 3://雷达扫描线角度速度更新
                            byte[] byte_ = SplitArray(receiveData,8, Marshal.SizeOf(RdScanCourse_S_));
                            RdScanCourse_S_ = rawDeserializeRdScanCourse_S(byte_);
                            _delegateSync(RdScanCourse_S_.PardPara.ucRadarID, RdScanCourse_S_.dScanCourse, RdScanCourse_S_.fScanSpeed);
                            break;
                        default:
                            _delegateSync(UdpHeads.ucDataType);
                            break;
                    }
                }
                catch (Exception)
                {
                }
            }
        }
        //数组截取
        private byte[] SplitArray(byte[] Source, int StartIndex, int Size)
        {
            try
            {
                byte[] result = new byte[Size];
                for (int i = 0; i < Size; i++) result[i] = Source[i + StartIndex];
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        //融合数据从序列化反编译出结构体
        private static FusTarget_S rawDeserializeFus(byte[] rawdatas)
        {
            Type anytype = typeof(FusTarget_S);
            int rawsize = Marshal.SizeOf(anytype);
            if (rawsize > rawdatas.Length)
                return new FusTarget_S();
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.Copy(rawdatas, 0, buffer, rawsize);
            object retobj = Marshal.PtrToStructure(buffer, typeof(FusTarget_S));
            Marshal.FreeHGlobal(buffer);
            return (FusTarget_S)retobj;
        }

        //扫描线数据从序列化反编译出结构体
        private static RdScanCourse_S rawDeserializeRdScanCourse_S(byte[] rawdatas)
        {
            Type anytype = typeof(FusTarget_S);
            int rawsize = Marshal.SizeOf(anytype);
            if (rawsize > rawdatas.Length)
                return new RdScanCourse_S();
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.Copy(rawdatas, 0, buffer, rawsize);
            object retobj = Marshal.PtrToStructure(buffer, typeof(RdScanCourse_S));
            Marshal.FreeHGlobal(buffer);
            return (RdScanCourse_S)retobj;
        }

        //融合数据从序列化反编译出结构体
        private static AIS_AlrTxt rawDeserializeAisalrm(byte[] rawdatas)
        {
            Type anytype = typeof(AIS_AlrTxt);
            int rawsize = Marshal.SizeOf(anytype);
            if (rawsize > rawdatas.Length)
                return new AIS_AlrTxt();
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.Copy(rawdatas, 0, buffer, rawsize);
            object retobj = Marshal.PtrToStructure(buffer, typeof(AIS_AlrTxt));
            Marshal.FreeHGlobal(buffer);
            return (AIS_AlrTxt)retobj;
        }

        //AIS数据从序列化反编译出结构体
        private static AISMsg_S rawDeserializeAis(byte[] rawdatas)
        {
            Type anytype = typeof(AISMsg_S);
            int rawsize = Marshal.SizeOf(anytype);
            if (rawsize > rawdatas.Length)
                return new AISMsg_S();
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.Copy(rawdatas, 0, buffer, rawsize);
            object retobj = Marshal.PtrToStructure(buffer, typeof(AISMsg_S));
            Marshal.FreeHGlobal(buffer);
            return (AISMsg_S)retobj;
        }

        //雷达状态数据从序列化反编译出结构体
        private static RdStatus_S rawDeserializeRadarStatus(byte[] rawdatas)
        {
            Type anytype = typeof(RdStatus_S);
            int rawsize = Marshal.SizeOf(anytype);
            if (rawsize > rawdatas.Length)
                return new RdStatus_S();
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.Copy(rawdatas, 0, buffer, rawsize);
            object retobj = Marshal.PtrToStructure(buffer, typeof(RdStatus_S));
            Marshal.FreeHGlobal(buffer);
            return (RdStatus_S)retobj;
        }

        //圈层告警数据从序列化反编译出结构体
        private static RdDetectMsg_S rawDeserializeRadar(byte[] rawdatas)
        {
            Type anytype = typeof(RdDetectMsg_S);
            int rawsize = Marshal.SizeOf(anytype);
            if (rawsize > rawdatas.Length)
                return new RdDetectMsg_S();
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.Copy(rawdatas, 0, buffer, rawsize);
            object retobj = Marshal.PtrToStructure(buffer, typeof(RdDetectMsg_S));
            Marshal.FreeHGlobal(buffer);
            return (RdDetectMsg_S)retobj;
        }
        //数据包头从序列化反编译出结构体
        private static UDP_Head_S rawDeserializeHeads(byte[] rawdatas)
        {
            Type anytype = typeof(UDP_Head_S);
            int rawsize = Marshal.SizeOf(anytype);
            if (rawsize > rawdatas.Length)
                return new UDP_Head_S();
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.Copy(rawdatas, 0, buffer, rawsize);
            object retobj = Marshal.PtrToStructure(buffer, typeof(UDP_Head_S));
            Marshal.FreeHGlobal(buffer);
            return (UDP_Head_S)retobj;
        }

        //网络状态从序列化反编译出结构体
        private static Machine_NetWork_State rawDeserializeMachineNetWorkStates(byte[] rawdatas)
        {
            Type anytype = typeof(Machine_NetWork_State);
            int rawsize = Marshal.SizeOf(anytype);
            if (rawsize > rawdatas.Length)
                return new Machine_NetWork_State();
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.Copy(rawdatas, 0, buffer, rawsize);
            object retobj = Marshal.PtrToStructure(buffer, typeof(Machine_NetWork_State));
            Marshal.FreeHGlobal(buffer);
            return (Machine_NetWork_State)retobj;
        }

        //网络状态从序列化反编译出结构体
        private static Machine_Hardware_State rawDeserializeMachineHardWorkStates(byte[] rawdatas)
        {
            Type anytype = typeof(Machine_Hardware_State);
            int rawsize = Marshal.SizeOf(anytype);
            if (rawsize > rawdatas.Length)
                return new Machine_Hardware_State();
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.Copy(rawdatas, 0, buffer, rawsize);
            object retobj = Marshal.PtrToStructure(buffer, typeof(Machine_Hardware_State));
            Marshal.FreeHGlobal(buffer);
            return (Machine_Hardware_State)retobj;
        }
        //融合参数设置
        public bool SendFusParaS(FusPara_S fuspara)
        {
            IPEndPoint remoteIpep1 = new IPEndPoint(IPAddress.Parse(fusIP), fusPort);
            byte[] bfuspara = rawSerialize(fuspara);
            UDP_Head_S UdpHeads = new UDP_Head_S();
            UdpHeads.ucDataType = 200;//数据类型200
            UdpHeads.ucSource = 101;//2017-1-9修改
            UdpHeads.ucTarget = 1;
            UdpHeads.ushTgtNum = 1;
            UdpHeads.Reserve = 0;
            UdpHeads.ushLenth = Convert.ToUInt16(bfuspara.Length);
            byte[] budpheads = rawSerialize(UdpHeads);
            budpheads.CopyTo(bytes, 0);
            bfuspara.CopyTo(bytes, budpheads.Length);
            try
            {
                dmUdpClient.Send(bytes, bytes.Length, remoteIpep1);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                Array.Clear(bytes, 0, bytes.Length);
            }
        }
        //告警区域设置，type（1=圈层，2=多边形，3=管道），num（1到5序号）
        public bool SetAlarmAear(object alarmarea, int type, int num)
        {
            IPEndPoint remoteIpep2 = new IPEndPoint(IPAddress.Parse(fusIP), fusPort);
            byte[] balarmarea = rawSerialize(alarmarea);
            UDP_Head_S UdpHeads = new UDP_Head_S();
            UdpHeads.ucDataType = Convert.ToByte(200 + ((type - 1) * 10 + num));//数据类型
            UdpHeads.ucSource = 101;//2017-1-9修改
            UdpHeads.ucTarget = 1;
            UdpHeads.ushTgtNum = 1;
            UdpHeads.Reserve = 0;
            UdpHeads.ushLenth = Convert.ToUInt16(balarmarea.Length);
            byte[] budpheads = rawSerialize(UdpHeads);
            budpheads.CopyTo(bytes, 0);
            balarmarea.CopyTo(bytes, budpheads.Length);
            try
            {
                dmUdpClient.Send(bytes, bytes.Length, remoteIpep2);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                Array.Clear(bytes, 0, bytes.Length);
            }
        }
        //取消告警区域，type（1=圈层，2=多边形，3=管道），num（1到5序号）
        public bool CancelAlarmAear(int type, int num)
        {
            IPEndPoint remoteIpep3 = new IPEndPoint(IPAddress.Parse(fusIP), fusPort);
            UDP_Head_S UdpHeads = new UDP_Head_S();
            UdpHeads.ucDataType = Convert.ToByte(230 + ((type - 1) * 10 + num));//数据类型
            UdpHeads.ucSource = 101;//2017-1-9修改
            UdpHeads.ucTarget = 1;
            UdpHeads.ushTgtNum = 1;
            UdpHeads.Reserve = 0;
            UdpHeads.ushLenth = 0;
            byte[] budpheads = rawSerialize(UdpHeads);
            budpheads.CopyTo(bytes, 0);
            try
            {
                dmUdpClient.Send(bytes, bytes.Length, remoteIpep3);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                Array.Clear(bytes, 0, bytes.Length);
            }
        }
        private void sendBootMsg()//态势开机报文
        {
            IPEndPoint remoteIpep = new IPEndPoint(IPAddress.Parse(fusIP), fusPort);
            Boot_Down_S bootMsg = new Boot_Down_S();
            bootMsg.bootDown = 1;//开机
            //获取IP
            foreach (IPAddress _IPAddress in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
            {
                if (_IPAddress.AddressFamily.ToString() == "InterNetwork")
                {
                    IPAddress  ipa = _IPAddress;
                    bootMsg.hostIP1 = ipa.Address;//获取long型本机IP地址
                }
            }
            UDP_Head_S UdpHeads = new UDP_Head_S();
            UdpHeads.ucDataType = 166;//态势开机报文datatype为166
            UdpHeads.ucSource = 101;
            byte[] budpheads = rawSerialize(UdpHeads);//序列化头
            byte[] balarmarea = rawSerialize(bootMsg);//序列化开机报文
            byte[] sendbyte = new byte[21];
            budpheads.CopyTo(sendbyte, 0);
            balarmarea.CopyTo(sendbyte, budpheads.Length);//拷贝复制到要发送bytes数组
            while (isBoot == false)
            {
                dmUdpClient.Send(sendbyte, sendbyte.Length, remoteIpep);
                Thread.Sleep(3000);
            }
            Array.Clear(bytes, 0, bytes.Length);
        }
        private static byte[] rawSerialize(object obj)
        {
            int rawsize = Marshal.SizeOf(obj);
            IntPtr buffer = Marshal.AllocHGlobal(rawsize);
            Marshal.StructureToPtr(obj, buffer, false);
            byte[] rawdatas = new byte[rawsize];
            Marshal.Copy(buffer, rawdatas, 0, rawsize);
            Marshal.FreeHGlobal(buffer);
            return rawdatas;
        }//结构体序列化函数

        /// <summary>
        /// 接收到的AIS转换为态势Target类
        /// </summary>
        /// <param name="s">AIS源数据</param>
        /// <returns></returns>
        public static Target aisToNav(AISMsg_S s)
        {
            if (s.dLat < 1 || s.dLat > 90 || s.dLong< 1 || s.dLong > 180)
            {
                throw new Exception("Ais TransToT Error");
            }
            Target T = new Target((int)s.ulRecoCode, Math.Round(s.fDirectCourse, 6), s.fDirectSpeed);//初始化Target
            T.Source = TargetSource.AIS;//目标类型为AIS
            T.Latitude = s.dLat;//纬度
            T.Longitude = s.dLong;//经度
            T.Type = TargetType.Unknow;//渔船类型暂定Unknown
            T.AISType = s.ucAIS_Class;//AIS设备类型
            T.IMO = s.ulIMO;//AIS的IMO
            T.MIMSI = s.ulRecoCode.ToString();//唯一识别码MMSI
            T.CallSign = charToString(s.cCall_ID);//呼号
            T.Nationality = mmsiToC(s.ulRecoCode);//国籍
            T.UpdateTime = GetstringTime(s.ulTime);//更新时间
            T.ArrivePlatformTime = GetArrTimes(s.dLong, s.dLat, s.fDirectSpeed);
            T.ArriveTime = s.ucMonth.ToString() //预计到达时间
                + "/" + s.ucDay.ToString() + "/"
                + s.ucHour.ToString() + "/"
                + s.ucMinite.ToString();
            T.SailStatus = s.ucSailStatus;//航行状态
            T.MaxDeep = s.fMaxDeep;//最大吃水深度
            T.Capacity = s.ulCount;//船载人数
            T.Destination = charToString(s.cDestination);//目的地
            T.Name = charToString(s.cName);//船名
            return T;
        }

        /// <summary>
        /// 雷达目标转化为态势Target类
        /// </summary>
        /// <param name="r">雷达原始数据</param>
        /// <returns></returns>
        public static Target radarToNavT(RdDetectMsg_S r,out int Flag)
        {
            if (r.dLati < 1 || r.dLati > 90 || r.dLongti < 1 || r.dLongti > 180)
            {
                throw new Exception("Radar TransToT Error");
            }
            Flag = 0;
            Target T = new Target(r.lTargetNo, Math.Round(r.ulTargetCourse, 6), r.ulTargetSpeed);
            T.Source = TargetSource.Radar;
            T.ArrivePlatformTime = GetArrTimes(r.dLongti, r.dLati, r.ulTargetSpeed);
            T.Type = TargetType.Unknow;
            T.Distance = (int)r.ulTargetDis;//距离
            T.Latitude = Math.Round(r.dLati,6);//纬度
            T.Longitude = Math.Round(r.dLongti,6);//经度
            T.RadarID = r.PardPara.ucRadarID;
            if (r.PardPara.ucRadarID == 1)
            {
                T.RadarBatchNum = r.lTargetNo;
            }
            else if (r.PardPara.ucRadarID == 2)
            {
                T.RadarBatchNum2 = r.lTargetNo;
            }
            T.North = Math.Round(r.dNorthCourse,6);
            T.UpdateTime = GetstringTime(r.lFoundTime);
            if (RadarKeepAlive.Find(delegate (ushort ID) { return ID == r.lTargetNo; }) == 0)//如果目标不存在List中
            {
                if (r.ucTargetFlag != 2)
                {
                    Flag = 0;//标志位为新增
                    RadarKeepAlive.Add(r.lTargetNo);//新加入List
                }
                else
                {
                    Flag = 2;
                }
            }
            else if(RadarKeepAlive.Find(delegate (ushort ID) { return ID == r.lTargetNo; }) != 0)
            {
                if(r.ucTargetFlag == 2)
                {
                    Flag = 2;//标志位为删除
                    RadarKeepAlive.Remove(r.lTargetNo);//删除List中
                }
                else if (r.ucTargetFlag == 0 || r.ucTargetFlag == 1)
                {
                    Flag = 1;
                }
            }
            return T;
        }

        public static Target fusToNav(FusTarget_S f)
        {
            if (f.dLati < 1 || f.dLati > 90 || f.dLongti < 1 || f.dLongti > 180)
            {
                throw new Exception("Fus TransToT Error");
            }
            Target T = new Target(f.lFusBatchID, Math.Round(f.dNorthCourse, 6), f.fSpeed);
            T.Source = TargetSource.Merge;
            T.Type = TargetType.Unknow;
            T.Latitude = f.dLati;
            T.Longitude = f.dLongti;
            T.SrcNum = f.SrcNum;
            T.DataType = f.FusDataType;
            T.Type = TargetType.Unknow;//渔船类型暂定Unknown
            T.AISType = f.ucAIS_Class;//AIS设备类型
            //T.IMO = (int)f.ulAISBatchID;//AIS的IMO
            T.MIMSI = f.ulAISBatchID.ToString();//唯一识别码MMSI
            T.CallSign = charToString(f.cCall_ID);//呼号
            T.Nationality = mmsiToC(f.ulAISBatchID);//国籍
            T.UpdateTime = GetstringTime(f.lTime);//更新时间
            T.Type = GetTargetType(f.ucIFFAttrib);//敌我属性
            T.ArrivePlatformTime = GetArrTimes(f.dLongti, f.dLati, f.fSpeed);
            T.ArriveTime = f.ucMonth.ToString() //预计到达时间
                + "/" + f.ucDay.ToString() + "/"
                + f.ucHour.ToString() + "/"
                + f.ucMinite.ToString();
            T.MaxDeep = f.fMaxDeep;//最大吃水深度
            T.Capacity = f.ulCount;//船载人数
            T.Destination = charToString(f.cDestination);//目的地
            T.Name = charToString(f.cName);//船名
            T.RadarBatchNum = (int)f.ulRdbatchID;
            T.RadarBatchNum2 = (int)f.ulRdbatchID2;//雷达批号
            string AlarmTime;
            AlarmType Alarm;
            if (GetAlarmType(f.ucAlarmNum, out AlarmTime, out Alarm))
            {
                T.Alarm = Alarm;
                T.AlarmTime = AlarmTime;
                ushort flag = (ushort)((f.ucAlarmNum & 0x00ff));
                switch (flag)
                {
                    case 1:
                        T.Action = AlarmAction.Into;
                        break;
                    case 2:
                        T.Action = AlarmAction.Out;
                        break;
                    case 3:
                        T.Action = AlarmAction.Resident;
                        break;
                }
            }
            else
            {
                T.Alarm = AlarmType.None;
                T.AlarmTime = "";
                T.Action = AlarmAction.None;
            } 
            return T;
        }
        /// <summary>
        /// long型告警时间转化为1970-1-1 00:00:00格式string时间
        /// </summary>
        /// <param name="lTime">1970-1-1开始到现在的秒数</param>
        /// <returns></returns>
        private static string timeToString(long lTime)
        {
            string times = "1970-1-1 00:00:00";
            if (lTime < 0)
                return times;
            DateTime timep = new DateTime(1970, 1, 1);
            DateTime timen = timep.AddSeconds(lTime);
            string timer = timen.Year.ToString() + "/"
                + timen.Month.ToString() + "/"
                + timen.Day.ToString() + "  "
                + timen.Hour.ToString() + ":"
                + timen.Minute.ToString() + ":"
                + timen.Second.ToString();
            return timer;
        }

        private static string charToString(char[] Char)//char名称数组截取避免给前台的字符串乱码
        {
            string result = "";
            if (Char.Length <= 0)
                return result;
            for (int i =0; i <Char.Length;)
            {
                if (Char[i] == '\0' || Char[i] == '@')
                {
                    return result;
                }
                result += Char[i];
                i++;
            }
            return result;
        }
        private static string mmsiToC(uint mmsi)
        {
            string Nationality = "其他";
            if (mmsi < 100000000)
                return Nationality;
            string mmsis = mmsi.ToString();
            mmsis = mmsis.Substring(0,3);
            int mmsiint = Convert.ToInt32(mmsis);
            if (mmsiint == 412 || mmsiint == 413)
                Nationality = "中国";
            if (mmsiint == 574)
                Nationality = "越南";
            if (mmsiint == 533)
                Nationality = "马来西亚";
            return Nationality;
        }
        /// <summary>
        /// UTC时间戳转string北京时间
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public static string GetstringTime(long timestamp)
        {
            DateTime begin = new DateTime(1970, 1, 1,8,0,0);
            begin = begin.AddSeconds(timestamp);
            return begin.ToString();
        }

        private static TargetType GetTargetType(byte ucIFFAttrib)
        {
            TargetType type = TargetType.Normal;
            if (ucIFFAttrib == 5 || ucIFFAttrib == 1)
                type = TargetType.Suspicious;
            if (ucIFFAttrib == 0)
                type = TargetType.Unknow;
            return type;
        }
        private static bool GetAlarmType(ushort flag,out string alarmtime,out AlarmType alarmtype)
        {
            alarmtime = "";
            alarmtype = AlarmType.None;
            ushort AlarmNum = (ushort)((flag & 0xff00) >> 8);
            if (flag == 0)
            {
                return false;
            }
            else if (AlarmNum > 0)
            {
                alarmtime = DateTime.Now.ToString();
                switch (AlarmNum)
                {
                    case 201:
                        alarmtype = AlarmType.ExpulsionArea;
                        break;
                    case 202:
                        alarmtype = AlarmType.AlertArea;
                        break;
                    case 203:
                        alarmtype = AlarmType.EarlyWarningArea;
                        break;
                    case 255:
                        alarmtype = AlarmType.Contact;
                        break;
                    default:
                        {
                            if (AlarmNum >= 211 && AlarmNum <= 215)
                            {
                                alarmtype = AlarmType.ForbiddenZone;
                            }
                            if (AlarmNum >= 221 && AlarmNum <= 225)
                            {
                                alarmtype = AlarmType.Pipeline;
                            }
                        }
                        break;
                }
            }            
            return true;
        }
        /// <summary>
        /// 更新平台中心点
        /// </summary>
        /// <param name="Longti"></param>
        /// <param name="Lati"></param>
        public static void UpdatePlatCoordinates(double Longti,double Lati,byte ctr = 0)
        {
            CenterLati = Lati;
            CenterLongti = Longti;
            if (ctr == 1)
            {
                IPEndPoint remoteIpep2 = new IPEndPoint(IPAddress.Parse(fusIP), fusPort);
                UDP_Head_S UdpHeads = new UDP_Head_S();
                UdpHeads.ucDataType = 177;//平台中心数据类型
                UdpHeads.ucSource = 101;//2017-1-9修改
                UdpHeads.ucTarget = 1;
                UdpHeads.ushTgtNum = 0;
                UdpHeads.Reserve = 0;
                UdpHeads.ushLenth = 0;
                byte[] budpheads = rawSerialize(UdpHeads);
                try
                {
                    dmUdpClient.Send(budpheads, budpheads.Length, remoteIpep2);
                }
                catch (Exception)
                {
                }
            }
        }
        /// <summary>
        /// 白名单同步消息
        /// <para>2017年5月21日08:32:16</para>
        /// </summary>
        public static void WhiteListSync()
        {
            IPEndPoint remoteIpep2 = new IPEndPoint(IPAddress.Parse(fusIP), fusPort);
            UDP_Head_S UdpHeads = new UDP_Head_S();
            UdpHeads.ucDataType = 150;
            UdpHeads.ucSource = 101;
            UdpHeads.ucTarget = 1;
            UdpHeads.ushTgtNum = 0;
            UdpHeads.Reserve = 0;
            UdpHeads.ushLenth = 0;
            byte[] budpheads = rawSerialize(UdpHeads);
            try
            {
                dmUdpClient.Send(budpheads, budpheads.Length, remoteIpep2);
            }
            catch (Exception)
            {
                WhiteListSync();
            }
        }
        /// <summary>
        /// 计算目标预计到达平台时间
        /// </summary>
        /// <param name="dLongti"></param>
        /// <param name="dLati"></param>
        /// <param name="speed"></param>
        /// <returns></returns>
        private static string GetArrTimes(double dLongti,double dLati,float speed)
        {
            string timer = "";
            try
            {
                double dis = GetDistance(CenterLati, CenterLongti, dLati, dLongti);
                int seconds = (int)((dis / (speed * 1.852))*3600);
                DateTime dt = new DateTime();
                DateTime dts = dt.AddSeconds(seconds);
                if ((dts.Year - 1)>0|| (dts.Month - 1) > 0|| (dts.Day - 1) > 0)
                    return timer = "-";
                if (dts.Hour > 0)
                    timer += dts.Hour.ToString() + "h";
                if (dts.Minute > 0)
                    timer += dts.Minute.ToString() + "m";
                if (dts.Second > 0)
                    timer += dts.Second.ToString() + "s";
                if (dts.Hour == 0 && dts.Second == 0 && dts.Second == 0)
                    return timer = "0s";
            }
            catch
            {
                return timer;
            }
            return timer;
        }
        /// <summary>
        ///地球半径（km）
        /// </summary>
        private const double EARTH_RADIUS = 6378.137;
        /// <summary>
        /// 根据经纬度计算两点距离
        /// </summary>
        public static double GetDistance(double lat1, double lng1, double lat2, double lng2)
        {
            double radLat1 = rad(lat1);
            double radLat2 = rad(lat2);
            double a = radLat1 - radLat2;
            double b = rad(lng1) - rad(lng2);

            double s = 2 * Math.Asin(Math.Sqrt(Math.Pow(Math.Sin(a / 2), 2) +
             Math.Cos(radLat1) * Math.Cos(radLat2) * Math.Pow(Math.Sin(b / 2), 2)));
            s = s * EARTH_RADIUS;
            s = Math.Round(s * 10000) / 10000;
            return s;
        }

        /// <summary>
        /// 圆周率计算
        /// </summary>     
        private static double rad(double d)
        {
            return d * Math.PI / 180.0;
        }
    }     
}

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YimaWF.data;

namespace dataAnadll
{
    public class PolygonAreaManager
    {
        public PolygonAreaManager()
        {

        }

        /// <summary>
        /// ���¶���α�����
        /// </summary>
        /// <param name="fz"></param>
        /// <param name="geoMultFactor"></param>
        /// <returns></returns>
        public bool UpdatePolygonArea(ForbiddenZone fz, int geoMultFactor)
        {
            string pointStr = DataHelper.PointList2Str(fz.PointList, geoMultFactor);
            string sql = string.Format("update polygon_alert_area set uc_alarm_level={0}, polygon_alert_area_name='{1}'," +
            "polygon_alert_area_string='{2}',polygon_alert_area_ucPotNum={3}," +
            "polygon_alert_area_time=now(), remark='{4}' where polygon_alert_area_ID={5}", fz.AlarmLevel, fz.Name, pointStr, fz.PointList.Count, fz.Remark, fz.ID);

            var db = MysqlDBAccess.getInstance();
            var r = db.queryNoResponse(sql, true);
            if(r != 1)
                return false;
            return true;
        }

        public bool AddPolygonArea(ForbiddenZone fz, int geoMultFactor)
        {
            return UpdatePolygonArea(fz, geoMultFactor);
        }
        /// <summary>
        /// ɾ��һ������α�����
        /// </summary>
        /// <param name="fz"></param>
        /// <returns></returns>
        public bool DeletePolygonArea(ForbiddenZone fz)
        {
            ForbiddenZone tmp = new ForbiddenZone();
            tmp.ID = fz.ID;
            tmp.Name = "";
            return UpdatePolygonArea(tmp, 0);
        }

        /// <summary>
        /// ��ȡ���еĶ���α�����
        /// </summary>
        /// <param name="geoMultFactor"></param>
        /// <returns></returns>
        public List<ForbiddenZone> GetAllPolygonArea(int geoMultFactor)
        {
            string sql = "select polygon_alert_area_ID,polygon_alert_area_name,polygon_alert_area_string,uc_alarm_level,remark from polygon_alert_area";
            List<ForbiddenZone> list = new List<ForbiddenZone>();
            var db = MysqlDBAccess.getInstance();
            DataTable dt = null;
            db.query(sql, ref dt);
            foreach (DataRow row in dt.Rows)
            {
                if ((row[2].ToString()).Length > 0)
                {
                    ForbiddenZone fz = new ForbiddenZone();
                    fz.ID = (int)row[0];
                    fz.Name = (string)row[1];
                    fz.PointList = DataHelper.PointStr2List((string)row[2], geoMultFactor);
                    fz.AlarmLevel = (int)row[3];
                    fz.Remark = row[4].ToString();
                    list.Add(fz);
                }
            }
            return list;
        }
    }
}
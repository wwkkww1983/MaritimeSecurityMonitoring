﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class TrackEventProvider
    {
        /**/

        private int allPageCounts { get; set; }//查询结果的页面总数
        private int pageSize { get; set; }//每页记录数量,默认一千条,可在构造函数里设置
        private StringBuilder conditionStrBuilder { get; set; }//约束条件字符串
        private DataTable latestedDataTable = null;

        private DateTime startTime;
        private DateTime endTime;
        private int type;

        /// <summary>
        /// 初始化构造条件
        /// </summary>
        /// <param name="startTime_">开始时间</param>
        /// <param name="endTime_">结束时间</param>
        /// <param name="pageSizePara">页面大小，默认1000</param>
        public TrackEventProvider(DateTime start, DateTime end, int _type, int pageSizePara = 1000)
        {
            if (pageSizePara <= 0)
                throw new Exception("每页数量大小参数不合法！");
            pageSize = pageSizePara;
            startTime = start;
            endTime = end;
            type = _type;
        }

        /// <summary>
        /// 获取总页数
        /// </summary>
        /// <param name="allPageCountReturn">输出参数，当前条件下的总页数</param>
        /// <returns>当前条件的所有记录条数</returns>
        public int GetPageNum(out int allPageCountReturn)
        {
            string sql = string.Format("select count(*) from track_event where end_time BETWEEN '{0}' and '{1}' and event_type = {2}"
                , startTime.ToString(DataHelper.DateTimeFormStr), endTime.ToString(DataHelper.DateTimeFormStr), type);
            DataTable dt = null;
            try
            {
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);

                int tmpCount = Convert.ToInt32(dt.Rows[0][0]);//总行数
                if (tmpCount % pageSize == 0)
                {
                    allPageCountReturn = tmpCount / pageSize;
                }
                else
                {
                    allPageCountReturn = tmpCount / pageSize + 1;
                }
                allPageCounts = allPageCountReturn;
                return tmpCount;
            }
            catch (Exception)
            {
                allPageCountReturn = 0;
                return 0;
            }
        }


        private void GetPage(int currentPage, out DataTable dt)
        {
            if (startTime.Year < 1900 || endTime.Year < 1900)
                throw new Exception("未初始化查询参数");

            if (this.allPageCounts <= 0)
            {
                throw new Exception("数据库中没有符合条件的数据");
            }
            if (currentPage <= 0 || currentPage > this.allPageCounts)
                throw new Exception("查询的页码超出范围");

            string sql = string.Format("select * from track_event where event_type = {0} and end_time BETWEEN '{1}' and '{2}' limit {3}, {4}",
                type, startTime.ToString(DataHelper.DateTimeFormStr), endTime.ToString(DataHelper.DateTimeFormStr),
                (currentPage - 1) * pageSize, pageSize);

            var db = MysqlDBAccess.getInstance();
            dt = latestedDataTable;
            db.query(sql, ref dt);
        }
        /// <summary>
        /// 获取某一页的数据
        /// </summary>
        /// <param name="currentPage">需要获取的页号</param>
        /// <param name="dataList">输出参数，相应的数据</param>
        public void GetPage(int currentPage, out List<TrackEvent> eventList)
        {
            DataTable dt = null;
            GetPage(currentPage, out dt);
            eventList = new List<TrackEvent>();
            foreach (DataRow row in dt.Rows)
            {
                TrackEvent te = new TrackEvent();
                te.Name = row[1].ToString();
                te.Description = row[2].ToString();
                te.StartTime = (DateTime)row[3];
                te.EndTime = (DateTime)row[4];
                te.Type = (int)row[5];

                eventList.Add(te);
            }
        }



        public void GetFirtstPage(out List<TrackEvent> dataList)
        {
            GetPage(1, out dataList);
        }

        public void GetLastPage(out List<TrackEvent> dataList)
        {
            GetPage(this.allPageCounts, out dataList);
        }
    }



    public class TrackEvent
    {
        public string Name;
        public string Description;
        public DateTime StartTime;
        public DateTime EndTime;
        public int Type;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class Capture
    {
        //  public int linkage_Id { set; get; }
        public string picture_path { set; get; }
        public string Ship_number { set; get; }
        public DateTime capture_Time { set; get; }
        public int target_Id { set; get; }
        public int target_type { set; get; }
        public DateTime linkage_start { set; get; }
        public DateTime linkage_end { set; get; }
        public string remark { set; get; }

    }

    public  class SeleCaptureProvider
    {
        private int allPageCounts { get; set; }//查询结果的页面总数
        private int pageSize { get; set; }//每页记录数量,默认一千条,可在构造函数里设置
        private StringBuilder conditionStrBuilder { get; set; }//约束条件字符串
        private DataTable latestedDataTable = null;

        private DateTime startTime;
        private DateTime endTime;


        public SeleCaptureProvider(DateTime startTime_, DateTime endTime_, int pageSizePara = 1000)
        {
            if (pageSizePara <= 0)
                throw new Exception("每页数量大小参数不合法！");
            pageSize = pageSizePara;
            startTime = startTime_;
            endTime = endTime_;
        }

        public int GetPageNum(out int allPageCountReturn)
        {
            string sql = string.Format("select COUNT(*) from capture where linkage_start  BETWEEN '{0}' and '{1}'", startTime, endTime);
            DataTable dt = null;
            try
            {
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);

                int tmpCount = Convert.ToInt32(dt.Rows[0][0]);//总行数
                if (tmpCount % pageSize == 0)
                {
                    allPageCountReturn = tmpCount / pageSize;
                }
                else
                {
                    allPageCountReturn = tmpCount / pageSize + 1;
                }
                allPageCounts = allPageCountReturn;
                return tmpCount;
            }
            catch (Exception)
            {
                allPageCountReturn = 0;
                return 0;
            }
        }


        private void GetPage(int currentPage, out DataTable dt)
        {
            int offset = (currentPage - 1) * pageSize;//偏移量
            if (startTime == null || endTime == null)
                throw new Exception("未初始化查询参数");

            if (this.allPageCounts <= 0)
            {
                throw new Exception("数据库中没有符合条件的数据");
            }
            if (currentPage <= 0 || currentPage > this.allPageCounts)
                throw new Exception("查询的页码超出范围");

            string sql = string.Format("select picture_path,Ship_number,capture_Time,target_Id,linkage_start,linkage_end,remark from capture where  linkage_start between '{0}' and '{1}' limit {2},{3}",
                startTime, endTime, offset, pageSize);

            var db = MysqlDBAccess.getInstance();
            dt = latestedDataTable;
            db.query(sql, ref dt);
        }

      

        public void GetPage(int currentPage, out List<Capture> dataList)
        {
            DataTable dt = null;
            GetPage(currentPage, out dt);
            dataList = new List<Capture>();
            foreach (DataRow rows in dt.Rows)
            {
                Capture data = new Capture();
                data.picture_path = rows[0].ToString();
                data.Ship_number = rows[1].ToString();
                data.capture_Time  = Convert.ToDateTime(rows[2]);
                data.target_Id = (int)rows[3];
                data.linkage_start = Convert.ToDateTime(rows[4]);
                data.linkage_end = Convert.ToDateTime(rows[5]);
                data.remark = rows[6].ToString();

                dataList.Add(data);
            }
        }


        public void GetFirtstPage(out List<Capture> dataList)
        {
            GetPage(1, out dataList);
        }

        public void GetLastPage(out List<Capture> dataList)
        {
            GetPage(this.allPageCounts, out dataList);
        }
    }
}

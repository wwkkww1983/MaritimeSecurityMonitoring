﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class LoginManager
    {
        /// <summary>
        /// 登陆
        /// </summary>
        /// <param name="username">用户名</param>
        /// <param name="psw">密码</param>
        /// <returns>登陆成功，返回相应的User类，否则返回Null</returns>
        public User Login(string username, string psw)
        {
            DataTable dt = null;
            string sql = "select * from user_manage " 
                + "where name='" + username
                + "' and password='" + psw + "';";
                User user = null;
            try
            {
                int num = MysqlDBAccess.getInstance().query(sql, ref dt);
                if (num >= 1)
                {
                    user = new User();
                    user.ID = (int)dt.Rows[0][0];
                    user.Name = (string)dt.Rows[0][1];
                    user.RoleID = (int)dt.Rows[0][2];
                    user.Password = (string)dt.Rows[0][3];
                    user.Level = (string)dt.Rows[0][4];
                    user.Department = (string)dt.Rows[0][5];
                    user.Email = (string)dt.Rows[0][6];
                    user.Telephone = (string)dt.Rows[0][7];
                    user.Phone = (string)dt.Rows[0][8];
                }
            }
            catch(Exception e)
            {
                //maybe log
                throw e;
            }
            return user;
        }
    }
}

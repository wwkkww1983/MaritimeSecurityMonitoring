﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using dataAnadll;
using static dataAnadll.FUS_ICD_MySql;
using System.Threading.Tasks;
using System.Data;


namespace dataAnadll
{
    public class FUSDataProvider
    {
        private int allPageCounts { get; set; }//查询结果的页面总数
        private int pageSize { get; set; }//每页记录数量,默认一千条,可在构造函数里设置
        private StringBuilder conditionStrBuilder { get; set; }//约束条件字符串
        private DataTable latestedDataTable = null;

        private uint startTime;
        private uint endTime;


        public FUSDataProvider(uint startTime_, uint endTime_, int pageSizePara = 1000)
        {
            if (pageSizePara <= 0)
                throw new Exception("每页数量大小参数不合法！");
            pageSize = pageSizePara;
            startTime = DataHelper.ConvertDateTime2UnixTime(DataHelper.ConvertIntDateTime(startTime_).ToUniversalTime());
            endTime = DataHelper.ConvertDateTime2UnixTime(DataHelper.ConvertIntDateTime(endTime_).ToUniversalTime());
        }

        public int GetPageNum(out int allPageCountReturn)
        {
            string sql = string.Format("select count(*) from fuse_data where lTime BETWEEN {0} and {1}", startTime, endTime);
            DataTable dt = null;
            try
            {
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);

                int tmpCount = Convert.ToInt32(dt.Rows[0][0]);//总行数
                if (tmpCount % pageSize == 0)
                {
                    allPageCountReturn = tmpCount / pageSize;
                }
                else
                {
                    allPageCountReturn = tmpCount / pageSize + 1;
                }
                allPageCounts = allPageCountReturn;
                return tmpCount;
            }
            catch (Exception)
            {
                allPageCountReturn = 0;
                return 0;
            }
        }


        private void GetPage(int currentPage, out DataTable dt)
        {
            if (startTime == 0 || endTime == 0)
                throw new Exception("未初始化查询参数");

            if (this.allPageCounts <= 0)
            {
                throw new Exception("数据库中没有符合条件的数据");
            }
            if (currentPage <= 0 || currentPage > this.allPageCounts)
                throw new Exception("查询的页码超出范围");

            string sql = string.Format("select * from fuse_data where lTime BETWEEN {0} and {1} limit {2}, {3}",
                startTime, endTime, (currentPage - 1) * pageSize, pageSize);

            var db = MysqlDBAccess.getInstance();
            dt = latestedDataTable;
            db.query(sql, ref dt);
        }

        public void GetPage(int currentPage, out List<FusTarget_SS> dataList)
        {
            DataTable dt = null;
            GetPage(currentPage, out dt);
            dataList = new List<FusTarget_SS>();
            int tmp = 0;
            string strtmp = null;
            foreach (DataRow row in dt.Rows)
            {
                FusTarget_SS Fusedata = new FusTarget_SS();
                Fusedata.Fus_count = row[0].ToString();
                Fusedata.lTime = row[1].ToString();
                Fusedata.lFusBatchID = row[2].ToString();
                Fusedata.FusDataType = row[3].ToString();
                Fusedata.SrcNum = row[4].ToString();
                Fusedata.ucConditionType = row[5].ToString();
                Fusedata.ucArmyCivil = row[6].ToString();
                Fusedata.ucIFFAttrib = row[7].ToString();
                Fusedata.ucTargetClass = row[8].ToString();
                Fusedata.ucTargetType = row[9].ToString();
                Fusedata.ucAlarmNum_State = row[10].ToString();
                Fusedata.ucAlarmNum = row[11].ToString();
                Fusedata.cCall_ID = row[12].ToString();
                Fusedata.cName = row[13].ToString();
                Fusedata.shDistanceA = row[14].ToString();
                Fusedata.shDistanceB = row[15].ToString();
                Fusedata.ucDistanceC = row[16].ToString();
                Fusedata.ucDistanceD = row[17].ToString();
                if (row[18] == DBNull.Value)
                {
                    tmp = -1;
                }
                else
                    tmp = Convert.ToInt32(row[18]);
                if (!DataHelper.ShipTypeMap.TryGetValue(tmp, out strtmp))
                {
                    strtmp = "未知";
                }
                Fusedata.ucShipType = strtmp;
                Fusedata.ucMonth = row[19].ToString();
                Fusedata.ucDay = row[20].ToString();
                Fusedata.ucHour = row[21].ToString();
                Fusedata.ucMinite = row[22].ToString();
                Fusedata.fMaxDeep = row[23].ToString();
                Fusedata.cDestination = row[24].ToString();
                if (row[25] == DBNull.Value)
                {
                    tmp = -1;
                }
                else
                    tmp = Convert.ToInt32(row[25]);
                if (!DataHelper.AISTypeMap.TryGetValue(tmp, out strtmp))
                {
                    strtmp = "未知";
                }
                Fusedata.ucAIS_Class = strtmp;
                Fusedata.ulCount = row[26].ToString();
                Fusedata.ulTime = row[27].ToString();
                Fusedata.dLongti = row[28].ToString();
                Fusedata.dLati = row[29].ToString();
                Fusedata.fHeight = row[30].ToString();
                Fusedata.fSpeed = row[31].ToString();
                Fusedata.fDistance = row[32].ToString();
                Fusedata.dNorthCourse = row[33].ToString();
                Fusedata.dPitching = row[34].ToString();
                Fusedata.ulRdbatchID = row[35].ToString();
                Fusedata.ulAISBatchID = row[36].ToString();
                Fusedata.ulOpticalID = row[37].ToString();
                if (row[39] == DBNull.Value)
                {
                    tmp = -1;
                }
                else
                    tmp = Convert.ToInt32(row[39]);
                if (!DataHelper.CountryMap.TryGetValue(tmp, out strtmp))
                {
                    strtmp = "其他";
                }
                Fusedata.country = strtmp;

                dataList.Add(Fusedata);
            }
        }


        public void GetFirtstPage(out List<FusTarget_SS> dataList)
        {
            GetPage(1, out dataList);
        }

        public void GetLastPage(out List<FusTarget_SS> dataList)
        {
            GetPage(this.allPageCounts, out dataList);
        }
    }

    
}

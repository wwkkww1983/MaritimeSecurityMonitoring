using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class PlatformManager
    {
        /// <summary>
        /// ����ƽ̨�����꣬�����������ʵ�ľ�γ�ȣ����Բ���Ҫ�˻����ӣ�����������ͨ����ͼ�ӿ�GetPlatformLocation��ȡ
        /// </summary>
        /// <param name="longitude"></param>
        /// <param name="latitude"></param>
        public void SavePlatform(double longitude, double latitude)
        {
            string sql = string.Format("update Platform_center set point_string='{0},{1},0;' where id=1", longitude, latitude);
            MysqlDBAccess.getInstance().queryNoResponse(sql, true);
            dataAna.UpdatePlatCoordinates(longitude, latitude,1);
        }

        /// <summary>
        /// ��ȡƽ̨���꣬���ﷵ�ص�Ҳ����ʵ�ľ�γ�ȣ����Խ������ȡ�����괫�뺣ͼ�ӿ�SetPlatform����ƽ̨����
        /// </summary>
        /// <param name="longitude"></param>
        /// <param name="latitude"></param>
        /// <returns></returns>
        public bool GetPlatform(out double longitude, out double latitude)
        {
            string sql = "select * from Platform_center where id=1";
            DataTable dt = null;
            try
            {
                if (MysqlDBAccess.getInstance().query(sql, ref dt) != 1)
                {
                    longitude = 0;
                    latitude = 0;
                    return false;
                }
                else
                {
                    var tmp = ((string)dt.Rows[0][1]).Split(';');
                    tmp = tmp[0].Split(',');
                    longitude = double.Parse(tmp[0]);
                    latitude = double.Parse(tmp[1]);
                    dataAna.UpdatePlatCoordinates(longitude, latitude);
                    return true;
                }
            }   
            catch (System.Exception)
            {
                
                longitude = latitude = 0;
                return false;
            }
        }
    }
}
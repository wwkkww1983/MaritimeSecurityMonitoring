﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class WhiteShipListManage
    {
        /// <summary>
        /// 添加一个船只进入白名单
        /// </summary>
        /// <param name="ws"></param>
        /// <returns>操作结果</returns>
        public bool AddWhiteShip(WhiteShip ws)
        {
            string sql = string.Format("insert into ship_white_list values ({0},'{1}',{2},'{3}','{4}','{5}', '{6}',0);",
                ws.MMSI, ws.ShipNumber, ws.IMO, ws.CallID, ws.ShipName, ws.ShipDepartment, ws.ShipUsage);
            if (MysqlDBAccess.getInstance().queryNoResponse(sql, false) == 1)
                return true;
            else
                return false;
        }

        /// <summary>
        /// 通过MMSI获取一个船只的白名单信息
        /// </summary>
        /// <param name="mmsi"></param>
        /// <returns>WhiteShip类</returns>
        public WhiteShip GetWhiteShip(int mmsi)
        {
            WhiteShip ws = null;
            string sql = string.Format("select * from ship_white_list where MMSI={0};", mmsi);
            DataTable dt = null;
            if (MysqlDBAccess.getInstance().query(sql, ref dt) > 0)
            {
                ws = new WhiteShip();
                ws.MMSI = (int)dt.Rows[0][0];
                ws.ShipNumber = dt.Rows[0][1].ToString();
                ws.IMO = Convert.ToUInt32(dt.Rows[0][2]);
                ws.CallID = dt.Rows[0][3].ToString();
                ws.ShipName = dt.Rows[0][4].ToString();
                ws.ShipDepartment = dt.Rows[0][5].ToString();
                ws.ShipUsage = dt.Rows[0][6].ToString();
            }
            return ws;
        }

        /// <summary>
        /// 获取所有船只白名单信息
        /// </summary>
        /// <returns></returns>
        public List<WhiteShip> GetAllWhiteShip()
        {
            List<WhiteShip> list = new List<WhiteShip>();
            string sql = string.Format("select * from ship_white_list;");
            DataTable dt = null;
            if (MysqlDBAccess.getInstance().query(sql, ref dt) > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    WhiteShip ws = new WhiteShip();
                    ws.MMSI = (int)row[0];
                    ws.ShipNumber = row[1].ToString();
                    ws.IMO = Convert.ToUInt32(row[2]);
                    ws.CallID = row[3].ToString();
                    ws.ShipName = row[4].ToString();
                    ws.ShipDepartment = row[5].ToString();
                    ws.ShipUsage = row[6].ToString();
                    list.Add(ws);
                }

            }
            return list;
        }

        /// <summary>
        /// 更新一条船只的白名单信息，通过MMSI索引
        /// </summary>
        /// <param name="ws"></param>
        /// <returns></returns>
        public bool UpdateWhiteShip(WhiteShip ws)
        {
            string sql = string.Format("update ship_white_list set ship_number='{0}',IMO={1},call_id='{2}',ship_name='{3}',ship_department='{4}',ship_usage='{5}' where MMSI={6}",
                ws.ShipNumber, ws.IMO, ws.CallID, ws.ShipName, ws.ShipDepartment, ws.ShipUsage, ws.MMSI);
            if (MysqlDBAccess.getInstance().queryNoResponse(sql, false) == 1)
                return true;
            else
                return false;
        }

        /// <summary>
        /// 删除一条船只的白名单信息，通过MMSI索引
        /// </summary>
        /// <param name="mmsi"></param>
        /// <returns></returns>
        public bool DeleteWhiteShip(int mmsi)
        {
            string sql = string.Format("delete from ship_white_list where MMSI ={0}", mmsi);
            if (MysqlDBAccess.getInstance().queryNoResponse(sql, false) == 1)
                return true;
            else
                return false;
        }
    }
}

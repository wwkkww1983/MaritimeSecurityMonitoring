﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Threading;
using static dataAnadll.FUS_ICD_MySql;
using MySql.Data.MySqlClient;
using YimaWF.data;
using dataAnadll;
using System.IO;

namespace dataAnadll
{
   public class DB_Basement
    {

        /// <summary>
        /// 数据库连接
        /// </summary>
        /// <param name="server">数据库IP</param>
        /// <param name="uid">用户名</param>
        /// <param name="pwd">密码</param>
        /// <param name="Database">数据库名</param>
        /// <param name="port"></param>
        /// <returns></returns>
        public static MySqlConnection init(string server, string uid, string pwd, string Database, string port)
        {
            
            string constr = string.Format("server={0};uid={1};pwd={2};Database={3};PORT=3306;Charset=utf8", server, uid, pwd, Database);
            MySqlConnection mycon = new MySqlConnection(constr);
            mycon.Open();
            return mycon;
        }


        //封装MySqlCommand对象
        public MySqlCommand getSqlCommand(string sql, MySqlConnection mysql)
        {
            
            MySqlCommand mySqlCommand = new MySqlCommand(sql, mysql);

            return mySqlCommand;
        }


        // String 转 Float
        public float StrToFloat(string FloatString)
        {
            float result;
            if (FloatString != null)
            {
                if (float.TryParse(FloatString.ToString(), out result))
                    return result;
                else
                {
                    return (float)0.00;
                }
            }
            else
            {
                return (float)0.00;
            }
        }


        // 底层插入函数
        public void insert(string table, string Datastring, MySqlConnection mycon)
        {
            string sql = "insert into {0} VALUES {1}";
            string sql_str = String.Format(sql, table, Datastring);

            MySqlCommand mySqlCommand = getSqlCommand(sql_str, mycon);

            mySqlCommand.ExecuteNonQuery();

        }

        //底层更新函数
        public void update(string table, string data, string condition, MySqlConnection mycon)
        {
            string sql = "update {0} set {1} where {2}";
            string sql_str = String.Format(sql, table, data, condition);
            MySqlCommand mySqlCommand = getSqlCommand(sql_str, mycon);
            //sql 操作

            mySqlCommand.ExecuteNonQuery();

        }

        //底层全部更新函数
        public void updateAll(string table, string data, MySqlConnection mycon)
        {

            string sql = "update {0} set {1}";
            string sql_str = String.Format(sql, table, data);
            MySqlCommand mySqlCommand = getSqlCommand(sql_str, mycon);
            //sql 操作

            mySqlCommand.ExecuteNonQuery();

        }

        //底层查询函数Datatable
        public static DataTable DSSelect(string idName, string table, string conditon, MySqlConnection mycon)
        {
            string sql = "select {0} from {1} where {2}";
            string sql_str = String.Format(sql, idName, table, conditon);
            MySqlDataAdapter adptr = new MySqlDataAdapter(sql_str, mycon);//Adapter对象
            DataTable dt = new DataTable();
            adptr.Fill(dt);
            return dt;
        }

        //底层全部查询函数
        public static DataTable DSSelectAll(string idName, string table, MySqlConnection mycon)
        {
            string sql = "select {0} from {1}";
            string sql_str = String.Format(sql, idName, table);
            MySqlDataAdapter adptr = new MySqlDataAdapter(sql_str, mycon);//Adapter对象
            DataTable dt = new DataTable();
            adptr.Fill(dt);
            return dt;
        }

        //底层统计函数
        public static int DSSelect_Count(string table, string condition, MySqlConnection mycon)
        {
            string sql_str = String.Format("select COUNT(*) from {0} where {1}", table, condition);
            MySqlCommand cmd = new MySqlCommand(sql_str, mycon);
            int i = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            return i;
        }



        //底层删除函数
        public void delete(string table, string condition, MySqlConnection mycon)
        {
           
            string sql = "delete from {0} where {1}";
            string sql_str = String.Format(sql, table, condition);
            //sql 操作
            MySqlCommand mySqlCommand = getSqlCommand(sql_str, mycon);

            mySqlCommand.ExecuteNonQuery();
        }

    }
}

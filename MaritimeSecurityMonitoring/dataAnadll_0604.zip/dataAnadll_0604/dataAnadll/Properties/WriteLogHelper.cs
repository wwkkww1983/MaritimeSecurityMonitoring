using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class WriteLogHelper
    {
        private MySqlConnection conn = null;


        public WriteLogHelper()
        {
            conn = MysqlDBAccess.getInstance().openConn();
        }



        public void WriteOptionLog(OptionLog ol)
        {
            string sqlFormat = "insert into option_log_list (user_id,option_name,option_time,option_result,option_notes,log_type_ID) VALUES ({0}, '{1}',now(),'{2}','{3}',{4})";
            string sql = string.Format(sqlFormat, ol.UserID, ol.OptionName, ol.Result == null ? "" : ol.Result, ol.Note == null ? "" : ol.Note, ol.LogType);

            lock (this.conn)
            {
                MysqlDBAccess.getInstance().queryNoResponse(sql, conn, true);
            }
        }

        public async void WriteOptionLogAsync(OptionLog ol)
        {
            await Task.Run(() =>
            {
                WriteOptionLog(ol);
            });
        }
    }
}
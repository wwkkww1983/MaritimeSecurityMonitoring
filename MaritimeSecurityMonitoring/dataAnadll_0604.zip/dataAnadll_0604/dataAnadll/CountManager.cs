using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class CountManager
    {
        /// <summary>
        /// ͳ��ƽ̨�澯����
        /// </summary>
        /// <param name="year">���</param>
        /// <param name="startMonth">��ʼ�·�</param>
        /// <param name="endMonth">�����·�</param>
        /// <returns>ÿ�µĸ澯����û�и澯���·�Ϊ0</returns>
        public List<int> CountPlantformAlarm(int year, int startMonth, int endMonth, CountType type = CountType.All)
        {
            List<int> list = new List<int>();
            if (startMonth > endMonth || startMonth == 0 || endMonth == 0 || year == 0)
                throw new Exception("��ѯ��������");

            string formatStr = null;
            switch(type)
            {
                case CountType.Suspicious:
                    formatStr = "select count(*) from alarm_log where alarm_type=1 and alarm_area_num=255 and time >='{0}' and time <= '{1}' and iff_attrib = 5;";
                    break;
                case CountType.Vietnam:
                    formatStr = "select count(*) from alarm_log where alarm_type=1 and alarm_area_num=255 and time >='{0}' and time <= '{1}' and (country = 574 or country = 576);";
                    break;
                case CountType.All:
                    formatStr = "select count(*) from alarm_log where alarm_type=1 and alarm_area_num=255 and time >='{0}' and time <= '{1}';";
                    break;
            }

            //��������ѯ���
            List<string> sqlList = new List<string>();
            for (int i = startMonth; i <= endMonth; i++)
            {
                DateTime start = new DateTime(year, i, 1);
                DateTime end = new DateTime();
                if (i == 12)
                {
                    end = new DateTime(year + 1, 1, 1);
                }
                else
                {
                    end = new DateTime(year, i + 1, 1);
                }
                var a = start.ToString(DataHelper.DateTimeFormStr);
                sqlList.Add(string.Format(formatStr,
                start.ToString(DataHelper.DateTimeFormStr), end.ToString(DataHelper.DateTimeFormStr)));
            }

            List<DataTable> dtList = null;
            MysqlDBAccess.getInstance().query(sqlList.ToArray(), ref dtList);
            foreach (DataTable dt in dtList)
            {
                if (dt.Rows.Count > 0)
                    list.Add(Convert.ToInt32(dt.Rows[0][0]));
                else
                    list.Add(0);
            }
            return list;
        }

        /// <summary>
        /// ͳ����������ĸ澯����
        /// </summary>
        /// <param name="year">���</param>
        /// <param name="startMonth">��ʼ�·�</param>
        /// <param name="endMonth">�����·�</param>
        /// <returns>ÿ�µĸ澯����û�и澯���·�Ϊ0</returns>
        public List<int> CountAllAlarm(int year, int startMonth, int endMonth, CountType type = CountType.All)
        {
            List<int> list = new List<int>();
            if (startMonth > endMonth || startMonth == 0 || endMonth == 0 || year == 0)
                throw new Exception("��ѯ��������");

            string formatStr = null;
            switch (type)
            {
                case CountType.Suspicious:
                    formatStr = "select count(*) from alarm_log where alarm_type=1 and time >='{0}' and time <= '{1}' and iff_attrib = 5;";
                    break;
                case CountType.Vietnam:
                    formatStr = "select count(*) from alarm_log where alarm_type=1 and time >='{0}' and time <= '{1}' and (country = 574 or country = 576);";
                    break;
                case CountType.All:
                    formatStr = "select count(*) from alarm_log where alarm_type=1 and time >='{0}' and time <= '{1}';";
                    break;
            }

            //��������ѯ���
            List<string> sqlList = new List<string>();
            for (int i = startMonth; i <= endMonth; i++)
            {
                DateTime start = new DateTime(year, i, 1);
                DateTime end = new DateTime();
                if (i == 12)
                {
                    end = new DateTime(year + 1, 1, 1);
                }
                else
                {
                    end = new DateTime(year, i + 1, 1);
                }
                var a = start.ToString(DataHelper.DateTimeFormStr);
                sqlList.Add(string.Format(formatStr,
                start.ToString(DataHelper.DateTimeFormStr), end.ToString(DataHelper.DateTimeFormStr)));
            }

            List<DataTable> dtList = null;
            MysqlDBAccess.getInstance().query(sqlList.ToArray(), ref dtList);
            foreach (DataTable dt in dtList)
            {
                if (dt.Rows.Count > 0)
                    list.Add(Convert.ToInt32(dt.Rows[0][0]));
                else
                    list.Add(0);
            }
            return list;
        }


        /// <summary>
        /// ͳ��Ȧ��澯����
        /// </summary>
        /// <param name="year">ѡ�����</param>
        /// <param name="startMonth">��ʼ�·�</param>
        /// <param name="endMonth">�����·�</param>
        /// <returns>����ֵ䣬keyΪ���������ƣ�valueΪÿ�µĸ澯����û�и澯���·�Ϊ0</returns>
        public Dictionary<string, List<int>> CountCircleProtectAreaAlarm(int year, int startMonth, int endMonth, CountType type = CountType.All)
        {
            if (startMonth > endMonth || startMonth == 0 || endMonth == 0 || year == 0)
                throw new Exception("��ѯ��������");

            Dictionary<string, List<int>> resultdic = new Dictionary<string, List<int>>();//���ظ�ǰ̨���ֵ�
            List<int> times = new List<int>();//���·�һ�δ洢��������
            List<string> sqlList = new List<string>(); //��������ѯ���

            string formatStr = null;
            switch (type)
            {
                case CountType.Suspicious:
                    formatStr = "select ac.name, count(*) from alarm_log as al, alarm_circle as ac where alarm_type=1 and al.alarm_area_num={0} and al.time >='{1}' and al.time < '{2}' and al.alarm_area_num = ac.id and iff_attrib = 5;";
                    break;
                case CountType.Vietnam:
                    formatStr = "select ac.name, count(*) from alarm_log as al, alarm_circle as ac where alarm_type=1 and al.alarm_area_num={0} and al.time >='{1}' and al.time < '{2}' and al.alarm_area_num = ac.id and (country = 574 or country = 576);";
                    break;
                case CountType.All:
                    formatStr = "select ac.name, count(*) from alarm_log as al, alarm_circle as ac where alarm_type=1 and al.alarm_area_num={0} and al.time >='{1}' and al.time < '{2}' and al.alarm_area_num = ac.id;";
                    break;
            }

            for (int areatype = 201; areatype <= 203; areatype++)
            {//201-203Ϊ����Ȧ��
                for (int i = startMonth; i <= endMonth; i++)//����ÿ��Ȧ�㱨��������ѯ���
                {
                    DateTime start = new DateTime(year, i, 1);
                    DateTime end = new DateTime();
                    if (i == 12)
                    {
                        end = new DateTime(year + 1, 1, 1);
                    }
                    else
                    {
                        end = new DateTime(year, i + 1, 1);
                    }
                    sqlList.Add(string.Format
                            (formatStr,
                        areatype, start.ToString(DataHelper.DateTimeFormStr), end.ToString(DataHelper.DateTimeFormStr)));
                }
            }

            List<DataTable> dtList = null;
            MysqlDBAccess.getInstance().query(sqlList.ToArray(), ref dtList);

            int count = 0, zeroCount = 0;
            string name = null;
            for (int areatype = 201; areatype <= 203; areatype++)
            {//201-203Ϊ����Ȧ��
                zeroCount = 0;
                for (int i = startMonth; i <= endMonth; i++)//����ÿ�����򱨾�������ѯ���
                {
                    DataTable dt = dtList[count++];
                    name = dt.Rows[0][0].ToString();
                    if (name.Length == 0)
                    {
                        //name = areatype.ToString();
                        name = null;
                    }
                    int tmp = Convert.ToInt32(dt.Rows[0][1]);
                    if (tmp == 0)
                        zeroCount++;
                    times.Add(tmp);
                }
                if (zeroCount == endMonth - startMonth + 1 && name == null)
                {

                }
                else
                {
                    if (name == null)
                        name = areatype.ToString();
                    resultdic.Add(name, times);//�ֵ��������
                }
                times = new List<int>();
            }

            return resultdic;
        }

        /// <summary>
        /// ͳ�ƶ���θ澯����
        /// </summary>
        /// <param name="year"></param>
        /// <param name="startMonth"></param>
        /// <param name="endMonth"></param>
        /// <returns>����ֵ䣬keyΪ���������ƣ�valueΪÿ�µĸ澯����û�и澯���·�Ϊ0</returns>
        public Dictionary<string, List<int>> CountPolygonAlarm(int year, int startMonth, int endMonth, CountType type = CountType.All)
        {

            if (startMonth > endMonth || startMonth == 0 || endMonth == 0 || year == 0)
                throw new Exception("��ѯ��������");

            Dictionary<string, List<int>> resultdic = new Dictionary<string, List<int>>();//���ظ�ǰ̨���ֵ�
            List<int> times = new List<int>();//���·�һ�δ洢��������
            List<string> sqlList = new List<string>(); //��������ѯ���

            string formatStr = null;
            switch (type)
            {
                case CountType.Suspicious:
                    formatStr = "select pa.polygon_alert_area_name, count(*) from alarm_log as al, polygon_alert_area as pa where alarm_type=1 and al.alarm_area_num={0} and al.time >='{1}' and al.time < '{2}' and al.alarm_area_num = pa.polygon_alert_area_ID and al.iff_attrib = 5;";
                    break;
                case CountType.Vietnam://
                    formatStr = "select pa.polygon_alert_area_name, count(*) from alarm_log as al, polygon_alert_area as pa where alarm_type=1 and al.alarm_area_num={0} and al.time >='{1}' and al.time < '{2}' and al.alarm_area_num = pa.polygon_alert_area_ID and (country = 574 or country = 576);";
                    break;
                case CountType.All:
                    formatStr = "select pa.polygon_alert_area_name, count(*) from alarm_log as al, polygon_alert_area as pa where alarm_type=1 and al.alarm_area_num={0} and al.time >='{1}' and al.time < '{2}' and al.alarm_area_num = pa.polygon_alert_area_ID;";
                    break;
            }

            for (int areatype = 211; areatype <= 215; areatype++)
            {//211-215Ϊ5������̶�ID
                for (int i = startMonth; i <= endMonth; i++)//����ÿ�����򱨾�������ѯ���
                {
                    DateTime start = new DateTime(year, i, 1);
                    DateTime end = new DateTime();
                    if (i == 12)
                    {
                        end = new DateTime(year + 1, 1, 1);
                    }
                    else
                    {
                        end = new DateTime(year, i + 1, 1);
                    }
                    sqlList.Add(string.Format
                            (formatStr,
                        areatype, start.ToString(DataHelper.DateTimeFormStr), end.ToString(DataHelper.DateTimeFormStr)));
                }
            }

            List<DataTable> dtList = null;
            MysqlDBAccess.getInstance().query(sqlList.ToArray(), ref dtList);

            int count = 0, zeroCount = 0;
            string name = null;
            for (int areatype = 211; areatype <= 215; areatype++)
            {//211-215Ϊ5������̶�ID
                zeroCount = 0;
                for (int i = startMonth; i <= endMonth; i++)//����ÿ�����򱨾�������ѯ���
                {
                    DataTable dt = dtList[count++];
                    name = dt.Rows[0][0].ToString();
                    if (name.Length == 0)
                    {
                        //name = areatype.ToString();
                        name = null;
                    }
                    int tmp = Convert.ToInt32(dt.Rows[0][1]);
                    if (tmp == 0)
                        zeroCount++;
                    times.Add(tmp);
                }
                if (zeroCount == endMonth - startMonth + 1 && name == null)
                {

                }
                else
                {
                    if (name == null)
                        name = areatype.ToString();
                    resultdic.Add(name, times);//�ֵ��������
                }
                times = new List<int>();
            }

            return resultdic;

        }

        /// <summary>
        /// ͳ�ƹܵ��澯����
        /// </summary>
        /// <param name="year"></param>
        /// <param name="startMonth"></param>
        /// <param name="endMonth"></param>
        /// <returns>����ֵ䣬keyΪ���������ƣ�valueΪÿ�µĸ澯����û�и澯���·�Ϊ0</returns>
        public Dictionary<string, List<int>> CountPipelineAlarm(int year, int startMonth, int endMonth, CountType type = CountType.All)
        {
            if (startMonth > endMonth || startMonth == 0 || endMonth == 0 || year == 0)
                throw new Exception("��ѯ��������");
            Dictionary<string, List<int>> resultdic = new Dictionary<string, List<int>>();//���ظ�ǰ̨���ֵ�
            List<int> times = new List<int>();//���·�һ�δ洢��������
            List<string> sqlList = new List<string>(); //��������ѯ���

            string formatStr = null;
            switch (type)
            {
                case CountType.Suspicious:
                    formatStr = "select oa.name, count(*) from alarm_log as al, oil_pipeline_protect_area as oa where alarm_type=1 and al.alarm_area_num={0} and al.time >='{1}' and al.time < '{2}' and al.alarm_area_num = oa.id and al.iff_attrib = 5;";
                    break;
                case CountType.Vietnam://
                    formatStr = "select oa.name, count(*) from alarm_log as al, oil_pipeline_protect_area as oa where alarm_type=1 and al.alarm_area_num={0} and al.time >='{1}' and al.time < '{2}' and al.alarm_area_num = oa.id and (country = 574 or country = 576);";
                    break;
                case CountType.All:
                    formatStr = "select oa.name, count(*) from alarm_log as al, oil_pipeline_protect_area as oa where alarm_type=1 and al.alarm_area_num={0} and al.time >='{1}' and al.time < '{2}' and al.alarm_area_num = oa.id;";
                    break;
            }

            for (int areatype = 221; areatype <= 225; areatype++)
            {//221-225Ϊ5������̶�ID
                for (int i = startMonth; i <= endMonth; i++)//����ÿ�����򱨾�������ѯ���
                {
                    DateTime start = new DateTime(year, i, 1);
                    DateTime end = new DateTime();
                    if (i == 12)
                    {
                        end = new DateTime(year + 1, 1, 1);
                    }
                    else
                    {
                        end = new DateTime(year, i + 1, 1);
                    }
                    sqlList.Add(string.Format
                            (formatStr,
                        areatype, start.ToString(DataHelper.DateTimeFormStr), end.ToString(DataHelper.DateTimeFormStr)));
                }
            }

            List<DataTable> dtList = null;
            MysqlDBAccess.getInstance().query(sqlList.ToArray(), ref dtList);

            int count = 0, zeroCount;
            string name = null;
            for (int areatype = 221; areatype <= 225; areatype++)
            {//221-225Ϊ5������̶�ID
                zeroCount = 0;
                for (int i = startMonth; i <= endMonth; i++)//����ÿ�����򱨾�������ѯ���
                {
                    DataTable dt = dtList[count++];
                    name = dt.Rows[0][0].ToString();
                    if (name.Length == 0)
                    {
                        //name = areatype.ToString();
                        name = null;
                    }
                    int tmp = Convert.ToInt32(dt.Rows[0][1]);
                    if (tmp == 0)
                        zeroCount++;
                    times.Add(tmp);
                }
                if (zeroCount == endMonth - startMonth + 1 && name == null)
                {

                }
                else
                {
                    if (name == null)
                        name = areatype.ToString();
                    resultdic.Add(name, times);//�ֵ��������
                }
                times = new List<int>();
            }

            return resultdic;
        }
    }


    public enum CountType
    {
        Suspicious,
        Vietnam,
        All
    }

}
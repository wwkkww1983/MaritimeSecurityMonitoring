using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class OperationLogProvider
    {
        private int allPageCounts { get; set; }//查询结果的页面总数
        private int pageSize { get; set; }//每页记录数量,默认一千条,可在构造函数里设置
        private MySqlDataAdapter pageReader { get; set; }
        private StringBuilder conditionStrBuilder { get; set; }//约束条件字符串

        private DataTable latestLogDT = null;


        /// <summary>
        /// 初始化查询类
        /// </summary>
        /// <param name="pageSizePara">每页的大小</param>
        public OperationLogProvider(int pageSizePara = 1000)
        {
            if (pageSizePara <= 0)
                throw new Exception("每页数量大小参数不合法！");
            this.pageSize = pageSizePara;
        }

        /// <summary>
        /// 设置查询参数，需要在调用GetPage类之前调用
        /// </summary>
        /// <param name="logType">日志类型，可以通过这个参数分别操作日志和登陆日志</param>
        /// <param name="startTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <param name="allPageCountReturn">总页数</param>
        /// <returns>当前条件下的所有记录数</returns>
        public int SearchLog(int? logType, DateTime? startTime, DateTime? endTime, out int allPageCountReturn)
        {
            allPageCountReturn = -1;
            this.allPageCounts = -1;
            conditionStrBuilder = new StringBuilder();
            string sqlHeadStr = @"select count(*) from option_log_list ";

            conditionStrBuilder = PrepareSearchPramter(logType, startTime, endTime);//初始化分页查询条件

            DataTable dt = new DataTable();
            MysqlDBAccess.getInstance().query(sqlHeadStr + conditionStrBuilder.ToString(),
                ref dt);

            int tmpCount = Convert.ToInt32(dt.Rows[0][0]);//总页数  向上取整的值
            if (tmpCount % pageSize == 0)
                allPageCountReturn = tmpCount / pageSize;
            else
            {
                allPageCountReturn = tmpCount / pageSize + 1;
            }
            this.allPageCounts = allPageCountReturn;
            return tmpCount;
        }


        private void GetPage(int currentPage, out DataTable dt)
        {
            if (conditionStrBuilder == null)
                throw new Exception("未初始化查询参数");

            if (this.allPageCounts <= 0)
            {
                throw new Exception("数据库中没有符合条件的数据");
            }
            if (currentPage <= 0 || currentPage > this.allPageCounts)
                throw new Exception("查询的页码超出范围");

            int offset = (currentPage - 1) * pageSize;
            StringBuilder sql = new StringBuilder();
            sql.Append("SELECT optlog.option_name,optlog.option_time,um.name,optlog.option_result,optlog.option_notes,optlog.computer_IP, optlog.type from option_log_list as optlog left join user_manage as um on optlog.user_id = um.id ");
            sql.Append(conditionStrBuilder);
            sql.Append(string.Format("limit {0},{1}", offset, pageSize));


            var db = MysqlDBAccess.getInstance();
            dt = latestLogDT;
            db.query(sql.ToString(), ref dt);
        }

        public void GetPage(int currentPage, out List<OperationLog> logList)
        {
            DataTable dt = null;
            GetPage(currentPage, out dt);
            logList = new List<OperationLog>();
            foreach (DataRow row in dt.Rows)
            {
                OperationLog ol = new OperationLog();
                ol.OptionName = row[0].ToString();
                ol.OptionTime = DateTime.Parse(row[1].ToString());
                ol.UserName = row[2].ToString();
                ol.Result = row[3].ToString();
                ol.Note = row[4].ToString();
                ol.IP = row[5].ToString();
                ol.LogType = (int)row[6];

                logList.Add(ol);
            }
        }

        public void GetFirtstPage(out List<OperationLog> dataList)
        {
            GetPage(1, out dataList);
        }

        public void GetLastPage(out List<OperationLog> dataList)
        {
            GetPage(this.allPageCounts, out dataList);
        }


        private StringBuilder PrepareSearchPramter(int? logType, DateTime? startTime, DateTime? endTime)
        {
            StringBuilder condition = new StringBuilder();
            bool tmpFlag = false;
            if (logType != null)
            {
                condition.Append(@" where type = " + Convert.ToInt32(logType));
                tmpFlag = true;
            }
            if (startTime.HasValue)
            {
                if (tmpFlag)
                    condition.Append(" and ");
                else
                    condition.Append(" where ");
                condition.Append(@"option_time >= '" + startTime.ToString() + "'");
                tmpFlag = true;
            }

            if (endTime.HasValue)
            {
                if (tmpFlag)
                    condition.Append(" and ");
                else
                    condition.Append(" where ");
                condition.Append(@"option_time < '" + endTime.ToString() + "'");
            }
            return condition;
        }
    }
}
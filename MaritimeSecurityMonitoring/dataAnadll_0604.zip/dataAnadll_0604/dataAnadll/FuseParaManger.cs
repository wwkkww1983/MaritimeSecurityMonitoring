using System;
using System.Data;


namespace dataAnadll
{
    public class FuseParaManager
    {
        public FuseParaManager()
        { }
        /// <summary>
        /// 更新融合参数
        /// </summary>
        /// <param name="fs">融合参数</param>
        /// <returns>操作结果</returns>
        public bool UpdateFuseArea(FuseParas fs)
        {
            string sql = string.Format("update fuse_parameter set xyz_threshold={0}," +
            "dis_threshold={1},angle_threshold={2},alarm_threshold = {3},"+
            "rd_die_time = {4},AIS_die_time = {5},lM = {6}," +
            "lN = {7}, esti_arith={8} where id=1", fs.XYZThreshold,fs.DisThreshold,fs.AngleThreshold,
            fs.AlarmThreshold,fs.RadarDieTime,fs.AISDieTime,fs.IM,fs.IN, fs.EstiArith);

            var db = MysqlDBAccess.getInstance();
            var r = db.queryNoResponse(sql, true);
            if (r != 1)
                return false;
            return true;
        }

        /// <summary>
        /// 添加融合参数，作用通更新融合参数
        /// </summary>
        /// <param name="fs">融合参数</param>
        /// <returns>操作结果</returns>
        public bool AddFuseArea(FuseParas fs)
        {
            return UpdateFuseArea(fs);
        }
       
        /// <summary>
        /// 查询现在的融合参数
        /// </summary>
        /// <returns>融合参数</returns>
        public FuseParas GetFuseParas()
        {
            string sql = "select * from fuse_parameter";
            FuseParas fs = new FuseParas();
            var db = MysqlDBAccess.getInstance();
            DataTable dt = null;
            db.query(sql, ref dt);
            fs.XYZThreshold = (float)(dt.Rows[0][0]);
            fs.DisThreshold = (float)(dt.Rows[0][1]);
            fs.AngleThreshold = (float)(dt.Rows[0][2]);
            fs.AlarmThreshold = (int)(dt.Rows[0][3]);
            fs.RadarDieTime = (int)(dt.Rows[0][4]);
            fs.AISDieTime = (int)(dt.Rows[0][5]);
            fs.IM = (int)(dt.Rows[0][6]);
            fs.IN = (int)(dt.Rows[0][7]);
            fs.EstiArith = (int)(dt.Rows[0][8]);
            return fs;
        }
    }

    public class FuseParas
    {
        public float XYZThreshold; //XYZ方向上的门限
        public float DisThreshold; //距离上的门限
        public float AngleThreshold; //角度的门限
        public int AlarmThreshold; //告警的门限，1表示>=1就提示、告警，2表示>=2才告警
        public int RadarDieTime; //雷达消失时间，多久认为雷达航迹撤销；（暂定36秒）
        public int AISDieTime; //AIS消失时间，多久认为雷达航迹撤销；（暂定36秒）
        public int IM; //起始规则，M/N,一般选择2/3起始，也可以设置；（暂定为3）
        public int IN; //起始规则，M/N,一般选择2/3起始，也可以设置；（暂定为3）
        public int EstiArith;  //估计算法，1，选择最优，2加权 3=SF;（暂定为1）
    }
}

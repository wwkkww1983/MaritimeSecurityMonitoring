using NPOI.HSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using static dataAnadll.FUS_ICD_MySql;
namespace dataAnadll
{

    public class SaveToExcel
    {
        static private string[] logNumber = { "", "��¼", "����" };
        static private string[] state = { "δ֪", "��", "��", "����", "��", "����" };
        static private string[] alarmType = { "������", "������", "Ԥ����", "���������", "�ܵ�����", "ƽ̨" };
        static private string[] type = { "����", "�쳣", "����" };
        static private string[] mix = { "AIS", "�״�", "�ں�" };
        public static int Save_AISdata(String filepath, List<AISMsg_SS> data, String[] title, int titleCnt)
        {
            int cnt = 0;
            int flag = 0;
            int startRow = 0;//��ʼ��
            //int StartCol = 0;//��ʼ��
            if (filepath == null || data == null || title == null)
            {
                return -1;
            }
            HSSFWorkbook wb;
            FileStream file;
            if (File.Exists(filepath) == true)
            {
                flag = 1;
                file = new FileStream(filepath, FileMode.Open, FileAccess.Read);
                wb = new HSSFWorkbook(file);
                file.Close();
            }
            else
            {
                file = new FileStream(filepath, FileMode.Create, FileAccess.Write);
                wb = new HSSFWorkbook();
                file.Close();
            }

            HSSFSheet sheet;
            if (flag == 1)
            //�ļ��Ѿ�����  
            {
                sheet = wb.GetSheet("sheet1");
            }
            else
            {
                sheet = wb.CreateSheet("sheet1");
                for (int i = 0; i < titleCnt; i++)
                {
                    sheet.CreateRow(0).CreateCell(i).SetCellValue(title[i]);//����������
                }
            }
            startRow = sheet.LastRowNum + 1;
            for (int i = 0; i < data.Count; i++)
            {
                sheet.CreateRow(startRow + i);
                sheet.GetRow(startRow + i).CreateCell(0).SetCellValue(data[i].cName);//����
                sheet.GetRow(startRow + i).CreateCell(1).SetCellValue(data[i].ulIMO);//IMO
                sheet.GetRow(startRow + i).CreateCell(2).SetCellValue(data[i].ulRecoCode);//MMSI  
                sheet.GetRow(startRow + i).CreateCell(3).SetCellValue(data[i].cCall_ID);//����

                sheet.GetRow(startRow + i).CreateCell(4).SetCellValue(data[i].country);//����Ϊ��

                sheet.GetRow(startRow + i).CreateCell(5).SetCellValue(data[i].dLong);//����
                sheet.GetRow(startRow + i).CreateCell(6).SetCellValue(data[i].dLat);//γ��
                sheet.GetRow(startRow + i).CreateCell(7).SetCellValue(data[i].fDirectCourse);//�����


                sheet.GetRow(startRow + i).CreateCell(8).SetCellValue(data[i].fDirectSpeed);//�ٶ�
                string t = (new System.DateTime(1970, 1, 1).AddSeconds(Convert.ToDouble(data[i].ulTime))).ToLocalTime().ToString();
                sheet.GetRow(startRow + i).CreateCell(9).SetCellValue(t);//����ʱ��
                sheet.GetRow(startRow + i).CreateCell(10).SetCellValue(data[i].ucSailStatus);//����״̬
                sheet.GetRow(startRow + i).CreateCell(12).SetCellValue(data[i].ulCount);//��������
                sheet.GetRow(startRow + i).CreateCell(11).SetCellValue(data[i].fMaxDeep);//��ˮ���
                sheet.GetRow(startRow + i).CreateCell(13).SetCellValue(data[i].cDestination);//Ŀ�ĵ�
                cnt++;
            }
            file = new FileStream(filepath, FileMode.Open, FileAccess.Write);
            wb.Write(file);
            file.Close();
            return cnt;
        }
        public static int Save_Radardata(String filepath, List<RdDetectMsg_SS> data, String[] title, int titleCnt)
        {
            int cnt = 0;
            int flag = 0;
            int startRow = 0;//��ʼ��
            //int StartCol = 0;//��ʼ��
            if (filepath == null || data == null || title == null)
            {
                return -1;
            }
            HSSFWorkbook wb;
            FileStream file;
            if (File.Exists(filepath) == true)
            {
                flag = 1;
                file = new FileStream(filepath, FileMode.Open, FileAccess.Read);
                wb = new HSSFWorkbook(file);
                file.Close();
            }
            else
            {
                file = new FileStream(filepath, FileMode.Create, FileAccess.Write);
                wb = new HSSFWorkbook();
                file.Close();
            }

            HSSFSheet sheet;
            if (flag == 1)
            //�ļ��Ѿ�����  
            {
                sheet = wb.GetSheet("sheet1");
            }
            else
            {
                sheet = wb.CreateSheet("sheet1");
                for (int i = 0; i < titleCnt; i++)
                {
                    sheet.CreateRow(0).CreateCell(i).SetCellValue(title[i]);//����������
                }
            }
            startRow = sheet.LastRowNum + 1;
            for (int i = 0; i < data.Count; i++)
            {
                sheet.CreateRow(startRow + i);
                sheet.GetRow(startRow + i).CreateCell(0).SetCellValue(data[i].lTargetNo);//�״�����
                sheet.GetRow(startRow + i).CreateCell(1).SetCellValue(data[i].ulTargetDis);//����
                sheet.GetRow(startRow + i).CreateCell(2).SetCellValue(data[i].ulTargetCourse);//�����
                sheet.GetRow(startRow + i).CreateCell(3).SetCellValue(data[i].dNorthCourse);//�汱����
                sheet.GetRow(startRow + i).CreateCell(4).SetCellValue(data[i].ulTargetSpeed);//�ٶ�
                string t = (new System.DateTime(1970, 1, 1).AddSeconds(Convert.ToDouble(data[i].lFoundTime))).ToLocalTime().ToString();
                sheet.GetRow(startRow + i).CreateCell(5).SetCellValue(t);//����ʱ��
                cnt++;
            }
            file = new FileStream(filepath, FileMode.Open, FileAccess.Write);
            wb.Write(file);
            file.Close();
            return cnt;
        }

        public static int Save_Fusedata(String filepath, List<FusTarget_SS> data, String[] title, int titleCnt)
        {
            int cnt = 0;
            int flag = 0;
            int startRow = 0;//��ʼ��
            //int StartCol = 0;//��ʼ��
            if (filepath == null || data == null || title == null)
            {
                return -1;
            }
            HSSFWorkbook wb;
            FileStream file;
            if (File.Exists(filepath) == true)
            {
                flag = 1;
                file = new FileStream(filepath, FileMode.Open, FileAccess.Read);
                wb = new HSSFWorkbook(file);
                file.Close();
            }
            else
            {
                file = new FileStream(filepath, FileMode.Create, FileAccess.Write);
                wb = new HSSFWorkbook();
                file.Close();
            }

            HSSFSheet sheet;
            if (flag == 1)
            //�ļ��Ѿ�����  
            {
                sheet = wb.GetSheet("sheet1");
            }
            else
            {
                sheet = wb.CreateSheet("sheet1");
                for (int i = 0; i < titleCnt; i++)
                {
                    sheet.CreateRow(0).CreateCell(i).SetCellValue(title[i]);//����������
                }
            }
            startRow = sheet.LastRowNum + 1;
            for (int i = 0; i < data.Count; i++)
            {
                sheet.CreateRow(startRow + i);
                sheet.GetRow(startRow + i).CreateCell(0).SetCellValue(data[i].lFusBatchID);//�ں�����
                string t = (new System.DateTime(1970, 1, 1).AddSeconds(Convert.ToDouble(data[i].lTime))).ToLocalTime().ToString();
                sheet.GetRow(startRow + i).CreateCell(1).SetCellValue(t);//�ںϷ���ʱ��
                sheet.GetRow(startRow + i).CreateCell(2).SetCellValue(data[i].FusDataType);//�ں�����
                sheet.GetRow(startRow + i).CreateCell(3).SetCellValue(data[i].SrcNum);//��Դ����
                sheet.GetRow(startRow + i).CreateCell(4).SetCellValue(data[i].dLongti);//����
                sheet.GetRow(startRow + i).CreateCell(5).SetCellValue(data[i].dLati);//γ��
                sheet.GetRow(startRow + i).CreateCell(6).SetCellValue(data[i].fDistance);//Ŀ�����
                sheet.GetRow(startRow + i).CreateCell(7).SetCellValue(data[i].dNorthCourse);//����     
                sheet.GetRow(startRow + i).CreateCell(8).SetCellValue(data[i].cName);//����
                sheet.GetRow(startRow + i).CreateCell(9).SetCellValue(data[i].cCall_ID);//����
                sheet.GetRow(startRow + i).CreateCell(10).SetCellValue(data[i].country);//����
                int Attrib = Convert.ToInt32(data[i].ucIFFAttrib);
                sheet.GetRow(startRow + i).CreateCell(11).SetCellValue(state[Attrib]);//��������  
                sheet.GetRow(startRow + i).CreateCell(12).SetCellValue(data[i].fMaxDeep);//����ˮ��� 
                sheet.GetRow(startRow + i).CreateCell(13).SetCellValue(data[i].ulCount);//��������         
                sheet.GetRow(startRow + i).CreateCell(14).SetCellValue(data[i].ulAISBatchID);//MMSI
                cnt++;
            }
            file = new FileStream(filepath, FileMode.Open, FileAccess.Write);
            wb.Write(file);
            file.Close();
            return cnt;
        }
        public static int Save_Optionlog(String filepath, List<String[]> data, String[] title, int titleCnt)
        {
            int cnt = 0;
            int flag = 0;
            int startRow = 0;//��ʼ��
            //int StartCol = 0;//��ʼ��
            if (filepath == null || data == null || title == null)
            {
                return -1;
            }
            HSSFWorkbook wb;
            FileStream file;
            if (File.Exists(filepath) == true)
            {
                flag = 1;
                file = new FileStream(filepath, FileMode.Open, FileAccess.Read);
                wb = new HSSFWorkbook(file);
                file.Close();
            }
            else
            {
                file = new FileStream(filepath, FileMode.Create, FileAccess.Write);
                wb = new HSSFWorkbook();
                file.Close();
            }

            HSSFSheet sheet;
            if (flag == 1)
            //�ļ��Ѿ�����  
            {
                sheet = wb.GetSheet("sheet1");
            }
            else
            {
                sheet = wb.CreateSheet("sheet1");
                for (int i = 0; i < titleCnt; i++)
                {
                    sheet.CreateRow(0).CreateCell(i).SetCellValue(title[i]);//����������
                }
            }
            startRow = sheet.LastRowNum + 1;
            for (int i = 0; i < data.Count; i++)
            {
                sheet.CreateRow(startRow + i);
                for (int j = 0; j < titleCnt; j++)
                {
                    sheet.GetRow(startRow + i).CreateCell(j).SetCellValue(data[i][j]);
                }
                cnt++;
            }
            file = new FileStream(filepath, FileMode.Open, FileAccess.Write);
            wb.Write(file);
            file.Close();
            return cnt;
        }
        public static int Save_LoginLog(String filepath, List<String[]> data, String[] title, int titleCnt)
        {
            int cnt = 0;
            int flag = 0;
            int startRow = 0;//��ʼ��
            //int StartCol = 0;//��ʼ��
            if (filepath == null || data == null || title == null)
            {
                return -1;
            }
            HSSFWorkbook wb;
            FileStream file;
            if (File.Exists(filepath) == true)
            {
                flag = 1;
                file = new FileStream(filepath, FileMode.Open, FileAccess.Read);
                wb = new HSSFWorkbook(file);
                file.Close();
            }
            else
            {
                file = new FileStream(filepath, FileMode.Create, FileAccess.Write);
                wb = new HSSFWorkbook();
                file.Close();
            }

            HSSFSheet sheet;
            if (flag == 1)
            //�ļ��Ѿ�����  
            {
                sheet = wb.GetSheet("sheet1");
            }
            else
            {
                sheet = wb.CreateSheet("sheet1");
                for (int i = 0; i < titleCnt; i++)
                {
                    sheet.CreateRow(0).CreateCell(i).SetCellValue(title[i]);//����������
                }
            }
            startRow = sheet.LastRowNum + 1;
            for (int i = 0; i < data.Count; i++)
            {
                sheet.CreateRow(startRow + i);
                for (int j = 0; j < titleCnt; j++)
                {
                    sheet.GetRow(startRow + i).CreateCell(j).SetCellValue(data[i][j]);
                }
                cnt++;
            }
            file = new FileStream(filepath, FileMode.Open, FileAccess.Write);
            wb.Write(file);
            file.Close();
            return cnt;
        }
        public static int Save_AlarmLog(String filepath, List<String[]> data, String[] title, int titleCnt)
        {
            int cnt = 0;
            int flag = 0;
            int startRow = 0;//��ʼ��
            //int StartCol = 0;//��ʼ��
            if (filepath == null || data == null || title == null)
            {
                return -1;
            }
            HSSFWorkbook wb;
            FileStream file;
            if (File.Exists(filepath) == true)
            {
                flag = 1;
                file = new FileStream(filepath, FileMode.Open, FileAccess.Read);
                wb = new HSSFWorkbook(file);
                file.Close();
            }
            else
            {
                file = new FileStream(filepath, FileMode.Create, FileAccess.Write);
                wb = new HSSFWorkbook();
                file.Close();
            }

            HSSFSheet sheet;
            if (flag == 1)
            //�ļ��Ѿ�����  
            {
                sheet = wb.GetSheet("sheet1");
            }
            else
            {
                sheet = wb.CreateSheet("sheet1");
                for (int i = 0; i < titleCnt; i++)
                {
                    sheet.CreateRow(0).CreateCell(i).SetCellValue(title[i]);//����������
                }
            }
            startRow = sheet.LastRowNum + 1;
            for (int i = 0; i < data.Count; i++)
            {
                sheet.CreateRow(startRow + i);
                for (int j = 0; j < titleCnt; j++)
                {
                    sheet.GetRow(startRow + i).CreateCell(j).SetCellValue(data[i][j]);
                }
                cnt++;
            }
            file = new FileStream(filepath, FileMode.Open, FileAccess.Write);
            wb.Write(file);
            file.Close();
            return cnt;
        }
        public static int Save_SystemLog(String filepath, List<String[]> data, String[] title, int titleCnt)
        {
            int cnt = 0;
            int flag = 0;
            int startRow = 0;//��ʼ��
            //int StartCol = 0;//��ʼ��
            if (filepath == null || data == null || title == null)
            {
                return -1;
            }
            HSSFWorkbook wb;
            FileStream file;
            if (File.Exists(filepath) == true)
            {
                flag = 1;
                file = new FileStream(filepath, FileMode.Open, FileAccess.Read);
                wb = new HSSFWorkbook(file);
                file.Close();
            }
            else
            {
                file = new FileStream(filepath, FileMode.Create, FileAccess.Write);
                wb = new HSSFWorkbook();
                file.Close();
            }

            HSSFSheet sheet;
            if (flag == 1)
            //�ļ��Ѿ�����  
            {
                sheet = wb.GetSheet("sheet1");
            }
            else
            {
                sheet = wb.CreateSheet("sheet1");
                for (int i = 0; i < titleCnt; i++)
                {
                    sheet.CreateRow(0).CreateCell(i).SetCellValue(title[i]);//����������
                }
            }
            startRow = sheet.LastRowNum + 1;
            for (int i = 0; i < data.Count; i++)
            {
                sheet.CreateRow(startRow + i);
                for (int j = 0; j < titleCnt; j++)
                {
                    sheet.GetRow(startRow + i).CreateCell(j).SetCellValue(data[i][j]);
                }
                cnt++;
            }
            file = new FileStream(filepath, FileMode.Open, FileAccess.Write);
            wb.Write(file);
            file.Close();
            return cnt;
        }
    }
}
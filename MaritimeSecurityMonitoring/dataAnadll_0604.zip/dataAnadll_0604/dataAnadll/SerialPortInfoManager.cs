using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class SerialPortInfoManager
    {
        /// <summary>
        /// ���ô��ڲ���
        /// </summary>
        /// <param name="baud_rate">������</param>
        /// <param name="data_bit">����λ</param>
        /// <param name="parity">У��λ</param>
        /// <param name="stop">ֹͣλ</param>
        /// <returns>�������</returns>
        public bool SetSerialPortInfo(int baud_rate, int data_bit, int parity, int stop)
        {
            string sql = string.Format("update gorge_line_parameter set baud_rate={0},data_bit={1},parity={2},stop={3}", 
            baud_rate, data_bit, parity, stop);
            if(MysqlDBAccess.getInstance().queryNoResponse(sql, false) == 1)
                return true;
            else
                return false;
        }

        /// <summary>
        /// ��ȡ���ڲ���
        /// </summary>
        /// <param name="baud_rate">������</param>
        /// <param name="data_bit">����λ</param>
        /// <param name="parity">У��λ</param>
        /// <param name="stop">ֹͣλ</param>
        /// <returns>�������������falseʱ�����������Ϊ0</returns>
        public bool GetSerialPortInfo(out int baud_rate, out int data_bit, out int parity, out int stop)
        {
            string sql = "select * from gorge_line_parameter where id=1";
            DataTable dt = null;
            if (MysqlDBAccess.getInstance().query(sql, ref dt) == 1)
            {
                baud_rate = (int)dt.Rows[0][0];
                data_bit = (int)dt.Rows[0][1];
                parity = (int)dt.Rows[0][2];
                stop = (int)dt.Rows[0][3];
                return true;
            }
            else
            {
                baud_rate = 0;
                data_bit = 0;
                parity = 0;
                stop = 0;
                return false;
            }
        }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using MySql.Data.MySqlClient;

//MysqlDBAccess.getInstance()

namespace dataAnadll
{
    public class MysqlDBAccess 
    {
        private static MysqlDBAccess dbAccess = null;

        private static string MainConnectionStr = null;//数据库连接字符串


        private MysqlDBAccess()
        {        
        }

        public static void SetConnectionStr(string server, string uid, string pwd, string Database)
        {
            MysqlDBAccess.MainConnectionStr = string.Format("server={0};uid={1};pwd={2};Database={3};PORT=3306;Charset=utf8", server, uid, pwd, Database);
        }

        /// <summary>
        /// 获取对象的唯一实例
        /// </summary>
        /// <returns></returns>
        public static MysqlDBAccess getInstance()
        {
            if (MainConnectionStr != null)
            {
                if (dbAccess == null)
                    dbAccess = new MysqlDBAccess();
                return dbAccess;
            }
            else
                return null;
        }

        /// <summary>
        /// 打开一个私有连接，为日志写入提供
        /// </summary>
        /// <returns>私有数据库连接</returns>
        public MySqlConnection openConn()
        {
            MySqlConnection conn = new MySqlConnection(MainConnectionStr);
            conn.Open();
            return conn;
        }

      
        /// <summary>
        /// ִ执行一个没有数据返回的sql语句
        /// </summary>
        /// <param name="sqlStr">sql语句</param>
        /// <param name="isTransaction">是否以事务方式执行</param>
        /// <returns>sql影响的记录数</returns>
        public int queryNoResponse(string sqlStr, bool isTransaction = false)
        {
            MySqlConnection conn = null;
            int resultCount = 0;
            if (sqlStr.Trim().Length <= 0)
                throw new Exception("sql错误");

            using (conn = openConn())
            {
                using (MySqlCommand scommand = new MySqlCommand(sqlStr, conn))
                {
                    MySqlTransaction stransaction = null;
                    try
                    {

                        if (isTransaction)
                        {
                            stransaction = conn.BeginTransaction();//��������
                            scommand.Transaction = stransaction;
                        }

                        resultCount = scommand.ExecuteNonQuery();//������Ӱ���ļ�¼����

                        if (isTransaction)
                        {
                            stransaction.Commit();
                        }
                    }
                    catch (Exception e)
                    {
                        if (isTransaction && stransaction != null)
                            stransaction.Rollback();
                        throw e;
                    }
                }
            }
            return resultCount;
        }

        public int queryNoResponse(string sqlStr, MySqlConnection conn, bool isTransaction = false)
        {
            int resultCount = 0;
            if (sqlStr.Trim().Length <= 0)
                throw new Exception("sql错误");
            using (MySqlCommand scommand = new MySqlCommand(sqlStr, conn))
            {
                MySqlTransaction stransaction = null;
                try
                {

                    if (isTransaction)
                    {
                        stransaction = conn.BeginTransaction();
                        scommand.Transaction = stransaction;
                    }

                    resultCount = scommand.ExecuteNonQuery();

                    if (isTransaction)
                    {
                        stransaction.Commit();
                    }
                }
                catch (Exception e)
                {
                    if (isTransaction && stransaction != null)
                        stransaction.Rollback();
                    throw e;
                }
            }
            return resultCount;
        }


        /// <summary>
        /// 执行一组没有返回的sql语句
        /// </summary>
        /// <param name="sqlStrArr">sql数组</param>
        /// <returns></returns>
        public int queryNoResponse(String[] sqlStrArr)
        {
            if (sqlStrArr.Length <= 0)
                throw new Exception("sql错误");
            StringBuilder sql = new StringBuilder();
            try
            {
                foreach (string strItem in sqlStrArr)
                {
                    sql.Append(strItem);
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            return queryNoResponse(sql.ToString(), true);
        }





        public int queryNoResponse(string sql, MySqlParameter[] parameters)
        {
            int result = 0;
            if (sql.Trim().Length < 1)//sql���䳤�ȴ���
                throw new Exception("Ҫִ�еĲ�ѯ���䲻����");
            MySqlConnection conn = null;
            MySqlTransaction tran = null;
            using (conn = openConn())//���������쳣���ϱ�
            {
                using (MySqlCommand command = new MySqlCommand(sql, conn))
                {
                    try
                    {
                        foreach (MySqlParameter parameter in parameters)
                        {
                            command.Parameters.Add(parameter);
                        }
                        tran = conn.BeginTransaction();
                        command.Transaction = tran;
                        result = command.ExecuteNonQuery();
                        tran.Commit();
                    }
                    catch (Exception e)
                    {
                        if (tran != null)
                            tran.Rollback();
                        throw e;
                    }
                }
            }
            return result;
        }






        public int query(string[] sqlStrArr, ref List<DataTable> dtList)
        {
            int resultAccount = 0;

            StringBuilder sqlStrBuilder = new StringBuilder();
            if (sqlStrArr.Length <= 0)
                throw new Exception("sql错误");
            foreach (String item in sqlStrArr)
            {
                sqlStrBuilder.Append(item);
            }
            MySqlConnection conn = null;
            using (conn = openConn())
            {
                using (MySqlDataAdapter sda = new MySqlDataAdapter(sqlStrBuilder.ToString(), conn))
                {
                    DataSet set = new DataSet();
                    sda.Fill(set);
                    if (dtList == null)
                        dtList = new List<DataTable>();
                    dtList.Clear();
                    foreach (DataTable dt in set.Tables)
                    {
                        dtList.Add(dt);
                        resultAccount += dt.Rows.Count;
                    }
                }
            }
            return resultAccount;
        }


        public int query(string sqlStr, ref DataTable dt)
        {
            int resultAccount = 0;
            if (sqlStr.Trim().Length <= 0)
                throw new Exception("sql长度错误");
            MySqlConnection conn = null;

            using (conn = openConn())
            {
                using (MySqlCommand scommand = new MySqlCommand(sqlStr, conn))
                {
                    MySqlDataReader sreader = null;
                    using (sreader = scommand.ExecuteReader())
                    {
                        if (dt == null)
                            dt = new DataTable();
                        dt.Clear();
                        dt.Load(sreader);
                        resultAccount = dt.Rows.Count;
                    }
                }
            }

            return resultAccount;
        }


   

        /// <summary>
        /// ��ȡ��������Ԫ�ṹ�ı�����
        /// </summary>
        /// <param name="tableName">����</param>
        /// <returns></returns>
        public DataTable getSchemaFromDB(string tableName)
        {
            MySqlConnection conn = null;   /////////////�����Լ��ĵģ���д����û����
            using (conn =openConn())
            {

                MySqlDataAdapter sda = new MySqlDataAdapter("select * from " + tableName, conn);//��ȡ���Ľṹ
                DataTable Table = new DataTable();
                try
                {
                    sda.FillSchema(Table, SchemaType.Source);

                }
                catch (MySqlException)
                {
                    throw new Exception("��" + tableName + "������");
                }

                return Table;
            }
        }

        public String[] getTableFiledNameList(String tableName)
        {
            String[] filedList = null;
            DataTable dt = getSchemaFromDB(tableName);
            int i = dt.Columns.Count;
            filedList = new String[i];
            for (int j = 0; j < i; j++)
            {
                filedList[j] = dt.Columns[j].ColumnName;

            }
            return filedList;
        }
    }
}

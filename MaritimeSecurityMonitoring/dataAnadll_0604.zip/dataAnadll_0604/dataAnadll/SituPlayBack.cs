﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using YimaWF.data;

namespace dataAnadll
{
    public class SituPlayBack
    {
        private bool isRunning = true;
        private Thread AISPlayBackThread = null;
        private Thread MergePlayBackThread = null;
        private Thread RadarPlayBackThread = null;
        public delegate void GetPlayBackDataDelegate(int Type, object obj);
        public delegate void PlayBackFinishDelegate();
        private GetPlayBackDataDelegate GetPlayBackData;
        private PlayBackFinishDelegate PlayBackFinish;
        private long startTime;
        private long endTime;
        private bool isError = false;
        private static long timeStep = 30;
        private object lock_ = new object();
        /// <summary>
        /// 态势回放类
        /// </summary>
        /// <param name="getPlayBackDatadel">获取数据回调，传入Target类</param>
        /// <param name="playBackFinish">结束回调，回放结束时调用</param>
        /// <param name="timeStart">开始时间</param>
        /// <param name="timeEnd">结束时间</param>
        public SituPlayBack(GetPlayBackDataDelegate getPlayBackDatadel, PlayBackFinishDelegate playBackFinish, DateTime timeStart, DateTime timeEnd)
        {
            GetPlayBackData = getPlayBackDatadel;
            PlayBackFinish = playBackFinish;
            startTime = DataHelper.ConvertDateTime2UnixTime(timeStart.ToUniversalTime());
            endTime = DataHelper.ConvertDateTime2UnixTime(timeEnd.ToUniversalTime());
        }

        private static void AISDataSimulatie(object obj)
        {
            SituPlayBack p = (SituPlayBack)obj;
            try
            {
                long currentTime = p.startTime;
                long endTime = p.startTime;

                while(currentTime < p.endTime)
                {
                    endTime = currentTime + timeStep;
                    if (endTime > p.endTime)
                        endTime = p.endTime;
                    string sql = String.Format("select * from AIS_data where ulTime BETWEEN {0} and {1} ORDER BY ulTime ASC", currentTime, endTime);
                    var db = MysqlDBAccess.getInstance();
                    if (db == null)
                        return;
                    DataTable dt = null;
                    db.query(sql, ref dt);
                    long lastTime = 0;
                    foreach (DataRow row in dt.Rows)
                    {
                        if (!p.isRunning)
                            break;
                        Target t = new Target((int)row[4], (double)row[9], (float)row[6], TargetSource.AIS);
                        t.SailStatus = Convert.ToByte(row[5]);
                        t.Longitude = (double)row[7];
                        t.Latitude = (double)row[8];

                        t.IMO = Convert.ToUInt32(row[11]);
                        t.CallSign = row[12].ToString();
                        t.Name = row[13].ToString();
                        t.ArriveTime = String.Format("{0}/{1}/{2}/{3}",
                            row[19].ToString(), row[20].ToString(), row[21].ToString(), row[22].ToString());
                        t.MaxDeep = (float)row[23];
                        t.Destination = row[24].ToString();
                        t.AISType = Convert.ToByte(row[25]);
                        t.Capacity = Convert.ToUInt32(row[26]);
                        t.MIMSI = row[4].ToString();
                        t.UpdateTime = dataAna.GetstringTime((long)row[27]);
                        string tmp = null;
                        if (DataHelper.CountryMap.TryGetValue(Convert.ToInt32(row[29]), out tmp))
                        {
                            t.Nationality = tmp;
                        }
                        else
                        {
                            t.Nationality = "其他";
                        }
                        if (lastTime != 0)
                        {
                            Thread.Sleep(Convert.ToInt32((long)row[27] - lastTime) * 1000);
                        }
                        lastTime = (long)row[27];
                        lock (p.lock_)
                        {
                            p.GetPlayBackData((int)row[28], t);
                        }
                    }
                    currentTime += timeStep + 1;
                }
            }
            catch(Exception)
            {
                p.isError = true;
            }
        }


        private static void FUSDataSimulatie(object obj)
        {
            SituPlayBack p = (SituPlayBack)obj;
            try
            {
                long currentTime = p.startTime;
                long endTime = p.startTime;

                while (currentTime < p.endTime)
                {
                    endTime = currentTime + timeStep;
                    if (endTime > p.endTime)
                        endTime = p.endTime;
                    string sql = String.Format("select * from fuse_data where lTime BETWEEN {0} and {1} ORDER BY lTime ASC", currentTime, endTime);
                    var db = MysqlDBAccess.getInstance();
                    if (db == null)
                        return;
                    DataTable dt = null;
                    db.query(sql, ref dt);
                    long lastTime = 0;
                    int itmp = 0;
                    string strtmp;
                    foreach (DataRow row in dt.Rows)
                    {
                        if (!p.isRunning)
                            break;
                        Target T = new Target((int)row[2], (double)row[33], (float)row[31], TargetSource.Merge);
                        T.Source = TargetSource.Merge;
                        T.Type = TargetType.Unknow;
                        T.Latitude = (double)row[29];
                        T.Longitude = (double)row[28];
                        T.SrcNum = Convert.ToByte(row[4]);
                        T.DataType = Convert.ToByte(row[3]);
                        T.AISType = Convert.ToInt32(row[25]);//AIS设备类型
                                                             //T.IMO = (int)f.ulAISBatchID;//AIS的IMO
                        T.MIMSI = row[36].ToString();//唯一识别码MMSI
                        //雷达批号
                        if(row[35] != DBNull.Value)
                            T.RadarBatchNum = (int)row[35];
                        if (row[37] != DBNull.Value)
                            T.RadarBatchNum2 = (int)row[37];
                        T.CallSign = row[12].ToString();//呼号
                        if (row[39] == DBNull.Value)
                        {
                            itmp = -1;
                        }
                        else
                            itmp = Convert.ToInt32(row[39]);
                        if (!DataHelper.CountryMap.TryGetValue(itmp, out strtmp))
                        {
                            strtmp = "其他";
                        }
                        T.Nationality = strtmp;//国籍
                        T.ArriveTime = row[19].ToString() //预计到达时间
                            + "/" + row[20].ToString() + "/"
                            + row[21].ToString() + "/"
                            + row[22].ToString();
                        T.MaxDeep = (float)row[23];//最大吃水深度
                        T.Capacity = Convert.ToUInt32(row[26]);//船载人数
                        T.Destination = row[24].ToString();//目的地
                        T.Name = row[13].ToString();//船名 
                        T.UpdateTime = dataAna.GetstringTime((long)row[1]);
                        int AlarmNum = (int)row[11];
                        if (AlarmNum == 0)
                        {
                            T.Alarm = AlarmType.None;
                        }
                        else if (AlarmNum > 0)
                        {
                            switch (AlarmNum)
                            {
                                case 201:
                                    T.Alarm = AlarmType.ExpulsionArea;
                                    break;
                                case 202:
                                    T.Alarm = AlarmType.ExpulsionArea;
                                    break;
                                case 203:
                                    T.Alarm = AlarmType.EarlyWarningArea;
                                    break;
                                case 255:
                                    T.Alarm = AlarmType.Contact;
                                    break;
                                default:
                                    break;
                            }

                            if (AlarmNum >= 211 && AlarmNum <= 215)
                            {

                                T.Alarm = AlarmType.ForbiddenZone;
                            }
                            if (AlarmNum >= 221 && AlarmNum <= 225)
                            {
                                T.Alarm = AlarmType.Pipeline;
                            }
                            T.AlarmTime = DataHelper.ConvertIntDateTime(Convert.ToUInt32(row[1])).ToString(DataHelper.DateTimeFormStr);
                        }
                        int alarmState = (int)row[10];
                        switch (alarmState)
                        {
                            case 1:
                                T.Action = AlarmAction.Into;
                                break;
                            case 2:
                                T.Action = AlarmAction.Out;
                                break;
                            case 3:
                                T.Action = AlarmAction.Resident;
                                break;
                            default:
                                T.Action = AlarmAction.None;
                                break;
                        }
                        string tmp = null;
                        if (DataHelper.CountryMap.TryGetValue(Convert.ToInt32(row[39]), out tmp))
                        {
                            T.Nationality = tmp;
                        }

                        if (lastTime != 0)
                        {
                            Thread.Sleep(Convert.ToInt32((long)row[1] - lastTime) * 1000);
                        }
                        lastTime = (long)row[1];
                        lock (p.lock_)
                        {
                            p.GetPlayBackData((int)row[38], T);
                        }
                    }
                    currentTime += timeStep + 1;
                }
            }
            catch (Exception)
            {
                p.isError = true;
            }
        }

        private static void RadarDataSimulatie(object obj)
        {
            SituPlayBack p = (SituPlayBack)obj;
            try
            {
                var db = MysqlDBAccess.getInstance();
                if (db == null)
                    return;
                long currentTime = p.startTime;
                long endTime = p.startTime;

                while (currentTime < p.endTime)
                {
                    endTime = currentTime + timeStep;
                    if (endTime > p.endTime)
                        endTime = p.endTime;
                    string sql = String.Format("select * from radar_data where lFoundTime BETWEEN {0} and {1} ORDER BY lFoundTime ASC", currentTime, endTime);
                    DataTable dt = null;
                    db.query(sql, ref dt);
                    long lastTime = 0;
                    foreach (DataRow row in dt.Rows)
                    {
                        if (!p.isRunning)
                            break;
                        Target T = new Target((int)row[0], (double)row[7], (float)row[6], TargetSource.Radar);//row[13]为雷达ID
                        T.Type = TargetType.Unknow;
                        T.Distance = (int)row[3];//距离
                        T.Latitude = (double)row[9];//纬度
                        T.Longitude = (double)row[8];//经度
                        T.North = (double)row[4];
                        T.RadarID = (int)row[13];
                        T.RadarBatchNum = T.ID;
                        T.UpdateTime = dataAna.GetstringTime((long)row[2]);
                        if (lastTime != 0)
                        {
                            //Console.WriteLine(Convert.ToInt32((long)row[27] - lastTime));
                            Thread.Sleep(Convert.ToInt32((long)row[2] - lastTime) * 1000);
                        }
                        lastTime = (long)row[2];
                        lock (p.lock_)
                        {
                            p.GetPlayBackData((int)row[1], T);
                        }
                    }
                    currentTime += timeStep + 1;
                }
            }
            catch (Exception)
            {
                p.isError = true;
            }
        }

        /// <summary>
        /// 开始态势回放
        /// </summary>
        /// <returns>操作结果</returns>
        public bool StartPlayBack()
        {
            isRunning = true;
            bool status = true;
            if (GetPlayBackData != null && startTime != 0 && endTime != 0)
            {
                try
                {
                    AISPlayBackThread = new Thread(AISDataSimulatie);
                    AISPlayBackThread.Start(this);
                    MergePlayBackThread = new Thread(FUSDataSimulatie);
                    MergePlayBackThread.Start(this);
                    RadarPlayBackThread = new Thread(RadarDataSimulatie);
                    RadarPlayBackThread.Start(this);
                    new Thread(o =>
                    {
                        AISPlayBackThread.Join();
                        MergePlayBackThread.Join();
                        RadarPlayBackThread.Join();
                        if(isRunning)
                            PlayBackFinish();
                    }).Start();
                }
                catch(Exception e)
                {
                    Stop();
                    status = false;
                    throw e;
                }
            }
            else
                status = false;


            return status;
        }
        /// <summary>
        /// 中断态势回放，当用户希望中断回放时调用，此时不会调用结束回调
        /// </summary>
        public void Stop()
        {
            isRunning = false;
        }
    }
}

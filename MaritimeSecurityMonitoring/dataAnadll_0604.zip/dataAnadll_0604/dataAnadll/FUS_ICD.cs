﻿using System.Runtime.InteropServices;

namespace dataAnadll
{
    public class FUS_ICD
    {
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct UDP_Head_S
        {
            // UDP_Head_S
            // 与融合网络数据头定义
            /*  报文名称：融合网络数据头              传输形式：点对点
             *  通信协议：UDP/TCP                     报文长度：8Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式    */
            public byte ucDataType;   //定义数据类型，NAV=1，AIS=2,雷达=3，光电=4，..... 融合=100,  
                                      //201~205=设置第1~5个圈层告警 211~215=设置第1~5个多边形告警 221~225=设置第1~5个管道告警,
                                      //231~235表示取消第1~5个圈层告警,241~245表示取消第1~5个多边形告警区域，251~255表示取消第1~5个管道告警区域
                                      //态势开关机报文166，融合收到开机报文为188	
            public byte ucSource;     //来源,NAV=1，AIS=2,雷达1=3，雷达2=4，光电=5，..... 融合=100,
            public byte ucTarget;     //目的：融合100，监控中心101
            public byte Reserve;      //保留
            public ushort ushTgtNum;  //后续的目标个数；
            public ushort ushLenth;   //数据包长度，不包含数据头，长度为字节数
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Error_S
        {
            //提供给上层的错误消息，供参考
            public string errInfo;  //错误消息内容
            public byte ucMonth;    //接收错误消息时间的月
            public byte ucDay;      //接收错误消息时间的日
            public byte ucHour;     //接收错误消息时间的时
            public byte ucMinite;   //接收错误消息时间的分
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct FusPara_S
        {
            // FusPara_S
            // 融合参数结构体
            /*  报文名称：融合参数结构体          传输形式：点对点
             *  通信协议：TCP                     报文长度：48Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式    */
            public float fXYZThreshold;     //XYZ方向上的门限；0~X m （暂定5000米）
            public float fDisThreshold;     //距离上的门限；0~X m（暂定0）
            public float fAngleThreshold;   //角度的门限；  0~X（暂定0）
            public byte ucAlarmThreshold;   //告警的门限，1表示>=1就提示、告警，2表示>=2才告警
            public long lRdDieTime;         //雷达消失时间，多久认为雷达航迹撤销；（暂定36秒）
            public long lAISDieTime;        //雷达消失时间，多久认为雷达航迹撤销；（暂定36秒）
            public long lM;                 //（暂定为2）
            public long lN;                 //起始规则，M/N,一般选择2/3起始，也可以设置；（暂定为3）
            public byte UcEstiArith;        //估计算法，1，选择最优，2加权 3=SF;（暂定为1）
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 2)]
            public byte[] reserve;          //保留2字节
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct FusTarget_S
        {
            // FusTarget_S
            // 单个融合目标结构体
            /*  报文名称：融合目标结构体          传输形式：点对点
             *  通信协议：UDP                     报文长度：183Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式    */
            public long lTime;            //融合时间: 1970年1月1日到发现目标的秒数
            public ushort lFusBatchID; //融合批号
            public byte FusDataType;  //融合数据类型，（NAV=1，AIS=2,雷达=3，光电=4，.....表示选择最优子源） //融合=100,预测=101，控制命令=200	
            public byte SrcNum;           //子源个数
            public byte ucConditionType;//0=未知，1=陆地，2=空中，3=水面， 4=水下
            public byte ucArmyCivil;  //0=未知，1=军用，2=民用
            public byte ucIFFAttrib;  //0=未知，1=敌，2=我，3=中立，4=友，5=可疑
            public byte ucTargetClass;    //目标类型，待定义
            public byte ucTargetType; //目标型号，待定义，
            public ushort ucAlarmNum;     //低8位为圈层告警区域编号201~205，多边形告警区域编号211~215，管道告警区域编号221~225

            //以下为AIS能够提供的信息，全部保留；如果没有，则不赋值；
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 8)]
            public char[] cCall_ID;   //呼号@@@@@@@ = 默认值，未知，以‘\0’结束
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 35)]
            public char[] cName;     //名称@@@@@@@ = 默认值，未知，以‘\0’结束
            public short shDistanceA;  //单位米；0-511
            public short shDistanceB;  //单位米  0-511
            public byte ucDistanceC;  //单位米  0-63
            public byte ucDistanceD;  //单位米  0-63
            public byte ucShipType;       //船货类型
            public byte ucMonth;      //预计到达时间的月
            public byte ucDay;            //预计到达时间的日
            public byte ucHour;           //预计到达时间的时
            public byte ucMinite;     //预计到达时间的分
            public float fMaxDeep;     //最大吃水深度
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 21)]
            public char[] cDestination;  //目的地，@@@@@@@ = 默认值，未知，以‘\0’结束
            public byte ucAIS_Class;  //AIS设备类型，0=Class_A;1=Class_B;2=基站；3=航标；4=搜索直升机；5=START搜救应答器
            public uint ulCount;     //船载人数
            public long ulTime;           //时间；1970年1月1日到发现目标的秒数
            //融合的位置参数
            public double dLongti;
            public double dLati;
            public float fHeight;          //目标的经纬高；
            public float fDistance;        //目标距离,m
            public float fSpeed;        //目标速度
            public double dNorthCourse;    //目标的方位角
            public double dPitching;       //目标的俯仰角
            //子源的构成关系
            public uint ulRdbatchID; //雷达1的批号；
            public uint ulAISBatchID;    //AIS的ulIMO 范围0-99999999，0表示无AIS
            public uint ulRdbatchID2; //雷达批号2
            public byte flag; //0新增 1更新 2删除
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Alarm_Dot_S
        {
            // Alarm_Dot_S
            // 圈层设置中心点坐标结构
            /*  报文名称：中心点坐标结构体        传输形式：点对点
             *  通信协议：TCP                     报文长度：20Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public double dLongti; 
            public double dLati;    //经纬度
            public float fHeight;  //虽然暂时不用，建议保留；填写0即可。
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Alarm_Circle_S
        {
            // Alarm_Circle_S
            // 圈层设置结构体
            /*  报文名称：圈层设置结构体          传输形式：点对点
             *  通信协议：TCP                     报文长度：26Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public byte ucCycleAlarmNum;   //告警编号：201~205
            public byte ucAlarmLevel;    //告警的级别 0无效
            public Alarm_Dot_S AlarmCenter;       //告警的中心点;
            public float fAlarmR;	       //告警的半径；
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Alarm_Polygon_S
        {
            // Alarm_Polygon_S
            // 不规则告警区域设置结构体
            /*  报文名称：不规则告警区域          传输形式：点对点
             *  通信协议：TCP                     报文长度：203Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public byte ucPolygonAlarmNum;  //告警编号211~215
            public byte ucAlarmLevel;       //告警级别
            public byte ucPotNum;           //多边形的点数构成；必须从1-2-3-顺着排
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 10)]
            public Alarm_Dot_S[] PotArray;	//最多可允许10个点；
        };

        public struct Alarm_Pipe_S
        {

         public byte ucPipeAlarmNum;     //告警编号221~225
         public byte ucAlarmLevel;     //告警级别
         public byte ucPotNum;         //管道点数构成；必须从1-2-3-顺着排，
         public int ucPipeWidth;       //管道宽度
         [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 10)]
         public Alarm_Dot_S[] PotArray;  //最多可允许10个点；
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct RadarPara_S
        {
            // RadarPara_S
            // 雷达站结构体
            /*  报文名称：雷达站结构体           传输形式：点对点
             *  通信协议：UDP                    报文长度：27Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public byte ucRadarID;          //雷达标识号
            public float lDisPrecision;     //距离精度,单位，m
            public float lDirectionPreci;   //方位角精度
            public double dLongti;          //经度 -180~180°
            public double dLati;            //维度 -90~90°
            public ushort lHeight;          //高度
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct RdDetectMsg_S
        {
            // RdDetectMsg_S
            // 单个雷达目标结构体
            /*  报文名称：单个雷达目标结构体              传输形式：点对点
             *  通信协议：UDP                     报文长度：99Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public RadarPara_S PardPara; //雷达参数，
            public ushort lTargetNo;     //批号
            public byte ucTargetFlag;    // 处理标识，0——新增目标，1更新目标，2删除目标
            public long lFoundTime;     //发现时间
            public uint ulTargetDis;    // 距离，单位，米           2017/1/5
            public double dNorthCourse;  //真北方位角，单位°       2017/1/5
            public double dPitching;     //俯仰角，°二维雷达，默认为0；     2017/1/5
            public float  ulTargetSpeed; // 地速度，LBS = 0.1 m/s
            public float  ulTargetCourse;// 航向角		
            public double dLongti;       //经度（-180-180）
            public double dLati;         //纬度（-90，90）
            public float fHeight;        //目标高度；
            public byte ucTargetType;	 //0未知，1- 2- 3- 4- 
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct RdStatus_S
        {
			// RdStatus_S
            // 雷达设备状态结构体
            /*  报文名称：雷达设备状态结构体              传输形式：点对点
             *  通信协议：UDP                     报文长度：99Bit
             *  发方：雷达                    	      
             *  收方：态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public RadarPara_S PardPara;      //雷达站标识结构体
            public byte ucRadarStatus;       //雷达整体状态，1：正常，2：异常(任一模块故障)
            public byte ucAntStatus;        //雷达天线状态，1：正常，n：模块故障码  
            public byte ucTransStatus;      //雷达发射机状态，1：正常，n：模块故障码
            public byte ucRecStatus;        //雷达接收机状态，1：正常，n：模块故障码
            public byte ucProcessorStatus;  //处理器状态，1：正常，n：模块故障码
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct RdScanCourse_S
        {
            public RadarPara_S PardPara;           //雷达站标识结构体
            public double dScanCourse;     //雷达扫描角度，单位：°
            public float fScanSpeed;		//雷达扫描速度：单位：转/秒，精度：0.1转/s
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct AISMsg_S
        {
            // AISMsg_S
            // AIS目标信息结构体
            /*  报文名称：AIS目标信息结构体              传输形式：点对点
             *  通信协议：UDP                     报文长度：142Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public byte ucMsgHead1;       //信息头1 0xeb；
            public byte ucMsgHead2;       //信息头2 0x90;
            public byte ucRptType;        //报文类型1-24；
            public uint ulRecoCode;      //唯一识别码
            public byte ucSailStatus;     //航行状态 1
            public float fDirectSpeed;    //对地航速
            public double dLong;          //经度 181度=未知，单位度
            public double dLat;           //纬度 91度 =未知，单位度
            public float fDirectCourse;   //360=未知，单位度
            public short shTrueHeading;   //511=未知，单位度（有效范围0-359）
            public uint ulIMO;           //IMO范围0-99999999，0：默认值
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 8)]
            public char[] cCall_ID;      //呼号@@@@@@@ = 默认值，未知，以‘\0’结束
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 35)]
            public char[] cName;         //名称@@@@@@@ = 默认值，未知，以‘\0’结束
            public short shDistanceA;    //单位米；0-511
            public short shDistanceB;    //单位米  0-511
            public byte ucDistanceC;     //单位米  0-63
            public byte ucDistanceD;     //单位米  0-63
            public byte ucShipType;      //船货类型
            public byte ucMonth;         //预计到达时间的月
            public byte ucDay;           //预计到达时间的日
            public byte ucHour;          //预计到达时间的时
            public byte ucMinite;        //预计到达时间的分
            public float fMaxDeep;       //最大吃水深度
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 21)]
            public char[] cDestination;  //目的地，@@@@@@@ = 默认值，未知，以‘\0’结束
            public byte ucAIS_Class;     //AIS设备类型，0=Class_A;1=Class_B;2=基站；3=航标；4=搜索直升机；5=START搜救应答器
            public uint ulCount;        //船载人数
            public long ulTime;         //这个参数用来记录时间；
            public byte flag; //0新增 1更新 2删除
        };

        public struct AISMsg
        {
            // AISMsg_S
            /* AIS目标信息结构体
            /* 通信层传送给态势显示的AIS目标结构体  
            */
            public int IMO;   //IMO
            public string MMSI;  //MMSI唯一识别码
            public string CallSign;   //呼号           
            public string Nationality;  //国籍 
            public string UpdateTime;
            public string Name;
            public string ArriveTime;           
            public byte SailStatus;//航行状态          
            public float MaxDeep;//最大吃水深度       
            public int Capacity;//船载人数           
            public string Destination;//目的地
            public int AISType;
            public float fDirectSpeed;    //对地航速
            public double dLong;          //经度 181度=未知，单位度
            public double dLat;           //纬度 91度 =未知，单位度
            public float fDirectCourse;   //360=未知，单位度
            public short shTrueHeading;   //511=未知，单位度（有效范围0-359）
            public byte ucShipType;      //船货类型
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Boot_Down_S
        {
            // Boot_Down_S
            // 态势开机报文
            /*  报文名称：开机报文结构体        传输形式：点对点
             *  通信协议：UDP                     报文长度：13Bit
             *  发方：态势                   	      
             *  收方：融合                	
             *  传输频率：态势开机时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public int  bootDown;    //开、关机，0=关机，1=开机
            public long hostIP1;    //本机IP
            public byte Reserve;  //保留。
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Machine_NetWork_State
        {
            // Machine_NetWork_State
            // 全网设备网络状态
            /*  报文名称：全网设备网络状态        传输形式：点对点
             *  通信协议：UDP                     报文长度：7Bit
             *  发方：融合                   	      
             *  收方：态势 
             *  接收端口 8067  
             *  stateID; //联网状态为1 硬件状态为2  ais报警状态为3 雷达报警状态为4             	
             *  传输频率：2HZ */
            public byte Slpingstate;//卫星罗经联网状态
            public byte AISpingstate;//  ais联网状态  0表示正常 1表示掉线
            public byte Raderpingstate; // 雷达联网状态  0表示正常 1表示掉线
            public byte lightpingstate;//  光电联网状态  0表示正常 1表示掉线
            public byte DBPing;//  数据库服务器联网状态  0表示正常 1表示掉线
            public byte clientAping;//  显控A联网状态 0表示正常 1表示掉线
            public byte clientBping; // 显控B联网状态 0表示正常 1表示掉线
            public byte fusstatus;  //融合状态
            public Machine_NetWork_State(byte ping)
            {
                Slpingstate = ping;//卫星罗经联网状态
                AISpingstate = ping;//  ais联网状态  0表示正常 1表示掉线
                Raderpingstate = ping; // 雷达联网状态  0表示正常 1表示掉线
                lightpingstate = ping;//  光电联网状态  0表示正常 1表示掉线
                DBPing = ping;//  数据库服务器联网状态  0表示正常 1表示掉线
                clientAping = ping;//  显控A联网状态 0表示正常 1表示掉线
                clientBping = ping; // 显控B联网状态 0表示正常 1表示掉线
                fusstatus = ping;  //融合状态
        }
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Machine_Hardware_State
        {
            // Machine_Hardware_State
            // 服务器和显控的硬件状态
            /*  报文名称：服务器和显控的硬件状态        传输形式：点对点
             *  通信协议：UDP                     报文长度：7Bit
             *  发方：融合                   	      
             *  收方：态势                	
             *  传输频率：2HZ */
            public byte Machine_id;    //id  1，2,3,4分别对应融合服务器 数据库服务器 显控A 显控B
            public float CPUrate;  //cpu使用率
            public float Roomrate; //内存使用率
            public float Diskrate; //磁盘占用率
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct AIS_AlrTxt
        {
            public byte channe_alert; //天线信道报警 0正常 1有故障
            public byte genaral_alert; //0正常 1 一般故障
            public byte clock_alert; //时钟报警 0正常 1有故障
            public byte MKD_alert; //MKD报警 0正常 1 有故障
            public byte EPFS_alert; //电子定位系统报警 0正常 1丢失
            public byte sensor_alert;//传感器报警 0正常  1故障
            public byte information_alert; //信息状态报警  0正常 1有无效信息故障
            public byte Machine_State; // ais多部件状态txt信息（非报警） 0表示未发出状态  1表示ais设备输出txt状态

            public AIS_AlrTxt(byte v1, byte v2, byte v3, byte v4, byte v5, byte v6, byte v7,byte v8) : this()
            {
                channe_alert = v1;
                genaral_alert = v2;
                clock_alert = v3;
                MKD_alert = v4;
                EPFS_alert = v5;
                sensor_alert = v6;
                information_alert = v7;
                Machine_State = v8;
            }
        }
    }
}

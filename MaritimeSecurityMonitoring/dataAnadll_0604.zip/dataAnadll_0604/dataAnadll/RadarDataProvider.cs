﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static dataAnadll.FUS_ICD_MySql;
namespace dataAnadll
{
     public class RadarDataProvider
    {
        private int allPageCounts { get; set; }//查询结果的页面总数
        private int pageSize { get; set; }//每页记录数量,默认一千条,可在构造函数里设置
        private StringBuilder conditionStrBuilder { get; set; }//约束条件字符串
        private bool isFromLoadDataBase { get; set; }//是否从导入的数据里查询
        private DataTable latestedDataTable = null;

        private uint startTime;
        private uint endTime;


        public RadarDataProvider(uint startTime_, uint endTime_, int pageSizePara = 1000)
        {
            if (pageSizePara <= 0)
                throw new Exception("每页数量大小参数不合法！");
            pageSize = pageSizePara;
            startTime = DataHelper.ConvertDateTime2UnixTime(DataHelper.ConvertIntDateTime(startTime_).ToUniversalTime());
            endTime = DataHelper.ConvertDateTime2UnixTime(DataHelper.ConvertIntDateTime(endTime_).ToUniversalTime());
        }
        
        public int GetPageNum(out int allPageCountReturn)
        {
            string sql = string.Format("select count(*) from radar_data where lFoundTime BETWEEN {0} and {1}", startTime, endTime);
            DataTable dt = null;
            try
            {
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);

                int tmpCount = Convert.ToInt32(dt.Rows[0][0]);//总行数
                if (tmpCount % pageSize == 0)
                {
                    allPageCountReturn = tmpCount / pageSize;
                }
                else
                {
                    allPageCountReturn = tmpCount / pageSize + 1;
                }
                allPageCounts = allPageCountReturn;
                return tmpCount;
            }
            catch (Exception)
            {
                allPageCountReturn = 0;
                return 0;
            }
        }


        private void GetPage(int currentPage, out DataTable dt)
        {
            if (startTime == 0 || endTime == 0)
                throw new Exception("未初始化查询参数");

            if (this.allPageCounts <= 0)
            {
                throw new Exception("数据库中没有符合条件的数据");
            }
            if (currentPage <= 0 || currentPage > this.allPageCounts)
                throw new Exception("查询的页码超出范围");

            string sql = string.Format("select * from radar_data where lFoundTime BETWEEN {0} and {1} limit {2}, {3}",
                startTime, endTime, (currentPage - 1) * pageSize, pageSize);

            var db = MysqlDBAccess.getInstance();
            dt = latestedDataTable;
            db.query(sql, ref dt);
        }

        public void GetPage(int currentPage, out List<RdDetectMsg_SS> dataList)
        {
            DataTable dt = null;
            GetPage(currentPage, out dt);
            dataList = new List<RdDetectMsg_SS>();
            foreach (DataRow row in dt.Rows)
            {

                RdDetectMsg_SS Radardata = new RdDetectMsg_SS();
                Radardata.radar_count = row[12].ToString();
                Radardata.lTargetNo = row[0].ToString();
                Radardata.ucTargetFlag = row[1].ToString();
                Radardata.lFoundTime = row[2].ToString();
                Radardata.ulTargetDis = row[3].ToString();
                Radardata.dNorthCourse = row[4].ToString();
                Radardata.dPitching = row[5].ToString();
                Radardata.ulTargetSpeed = row[6].ToString();
                Radardata.ulTargetCourse = row[7].ToString();
                Radardata.dLongti = row[8].ToString();
                Radardata.dLati = row[9].ToString();
                Radardata.fHeight = row[10].ToString();
                Radardata.ucTargetType = row[11].ToString();
                Radardata.PardPara.ucRadarID = Convert.ToByte(row[13]);
                dataList.Add(Radardata);
            }
        }


        public void GetFirtstPage(out List<RdDetectMsg_SS> dataList)
        {
            GetPage(1, out dataList);
        }

        public void GetLastPage(out List<RdDetectMsg_SS> dataList)
        {
            GetPage(this.allPageCounts, out dataList);
        }
    }
}

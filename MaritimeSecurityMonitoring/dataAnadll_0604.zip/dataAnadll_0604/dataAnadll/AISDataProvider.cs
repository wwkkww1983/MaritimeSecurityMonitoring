﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static dataAnadll.FUS_ICD_MySql;

namespace dataAnadll
{
    public class AISDataProvider
    {
        private int allPageCounts { get; set; }//查询结果的页面总数
        private int pageSize { get; set; }//每页记录数量,默认一千条,可在构造函数里设置
        private StringBuilder conditionStrBuilder { get; set; }//约束条件字符串
        private DataTable latestedDataTable = null;

        private uint startTime;
        private uint endTime;

        /// <summary>
        /// 初始化构造条件
        /// </summary>
        /// <param name="startTime_">开始时间</param>
        /// <param name="endTime_">结束时间</param>
        /// <param name="pageSizePara">页面大小，默认1000</param>
        public AISDataProvider(uint startTime_, uint endTime_, int pageSizePara = 1000)
        {
            if (pageSizePara <= 0)
                throw new Exception("每页数量大小参数不合法！");
            pageSize = pageSizePara;
            startTime = DataHelper.ConvertDateTime2UnixTime(DataHelper.ConvertIntDateTime(startTime_).ToUniversalTime());
            endTime = DataHelper.ConvertDateTime2UnixTime(DataHelper.ConvertIntDateTime(endTime_).ToUniversalTime());
        }

        /// <summary>
        /// 获取总页数
        /// </summary>
        /// <param name="allPageCountReturn">输出参数，当前条件下的总页数</param>
        /// <returns>当前条件的所有记录条数</returns>
        public int GetPageNum(out int allPageCountReturn)
        {
            string sql = string.Format("select count(*) from ais_data where ulTime BETWEEN {0} and {1}", startTime, endTime);
            DataTable dt = null;
            try
            {
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);

                int tmpCount = Convert.ToInt32(dt.Rows[0][0]);//总行数
                if (tmpCount % pageSize == 0)
                {
                    allPageCountReturn = tmpCount / pageSize;
                }
                else
                {
                    allPageCountReturn = tmpCount / pageSize + 1;
                }
                allPageCounts = allPageCountReturn;
                return tmpCount;
            }
            catch(Exception)
            {
                allPageCountReturn = 0;
                return 0;
            }
        }


        private void GetPage(int currentPage, out DataTable dt)
        {
            if (startTime == 0 || endTime == 0)
                throw new Exception("未初始化查询参数");

            if (this.allPageCounts <= 0)
            {
                throw new Exception("数据库中没有符合条件的数据");
            }
            if (currentPage <= 0 || currentPage > this.allPageCounts)
                throw new Exception("查询的页码超出范围");

            string sql = string.Format("select * from AIS_data where ulTime BETWEEN {0} and {1} limit {2}, {3}", 
                startTime, endTime, (currentPage - 1) * pageSize, pageSize);

            var db = MysqlDBAccess.getInstance();
            dt = latestedDataTable;
            db.query(sql, ref dt);
        }
        /// <summary>
        /// 获取某一页的数据
        /// </summary>
        /// <param name="currentPage">需要获取的页号</param>
        /// <param name="dataList">输出参数，相应的数据</param>
        public void GetPage(int currentPage, out List<AISMsg_SS> dataList)
        {
            DataTable dt = null;
            GetPage(currentPage, out dt);
            dataList = new List<AISMsg_SS>();
            int tmp = 0;
            string strtmp = null;
            foreach(DataRow row in dt.Rows)
            {
                AISMsg_SS AISdata = new AISMsg_SS();
                AISdata.AIS_count = row[0].ToString();
                AISdata.ucMsgHead1 = row[1].ToString();
                AISdata.ucMsgHead2 = row[2].ToString();
                AISdata.ucRptType = row[3].ToString();
                AISdata.ulRecoCode = row[4].ToString();
                if (row[5] == DBNull.Value)
                {
                    tmp = -1;
                }
                else
                    tmp = Convert.ToInt32(row[5]);
                if (!DataHelper.SailStatusMap.TryGetValue(tmp, out strtmp))
                {
                    strtmp = "未知";
                }
                AISdata.ucSailStatus = strtmp;
                AISdata.fDirectSpeed = row[6].ToString();
                AISdata.dLong = row[7].ToString();
                AISdata.dLat = row[8].ToString();
                AISdata.fDirectCourse = row[9].ToString();
                AISdata.shTrueHeading = row[10].ToString();
                AISdata.ulIMO = row[11].ToString();
                AISdata.cCall_ID = row[12].ToString();
                AISdata.cName = row[13].ToString();
                AISdata.shDistanceA = row[14].ToString();
                AISdata.shDistanceB = row[15].ToString();
                AISdata.ucDistanceC = row[16].ToString();
                AISdata.ucDistanceD = row[17].ToString();
                if (row[18] == DBNull.Value)
                {
                    tmp = -1;
                }
                else
                    tmp = Convert.ToInt32(row[18]);
                if (!DataHelper.ShipTypeMap.TryGetValue(tmp, out strtmp))
                {
                    strtmp = "未知";
                }
                AISdata.ucShipType = strtmp;
                AISdata.ucMonth = row[19].ToString();
                AISdata.ucDay = row[20].ToString();
                AISdata.ucHour = row[21].ToString();
                AISdata.ucMinite = row[22].ToString();
                AISdata.fMaxDeep = row[23].ToString();
                AISdata.cDestination = row[24].ToString();
                if (row[25] == DBNull.Value)
                {
                    tmp = -1;
                }
                else
                    tmp = Convert.ToInt32(row[25]);
                if (!DataHelper.AISTypeMap.TryGetValue(tmp, out strtmp))
                {
                    strtmp = "未知";
                }
                AISdata.ucAIS_Class = strtmp;
                AISdata.ulCount = row[26].ToString();
                AISdata.ulTime = row[27].ToString();
                if (row[29] == DBNull.Value)
                {
                    tmp = -1;
                }
                else
                    tmp = Convert.ToInt32(row[29]);
                if (!DataHelper.CountryMap.TryGetValue(tmp, out strtmp))
                {
                    strtmp = "其他";
                }
                AISdata.country = strtmp;

                dataList.Add(AISdata);
            }
        }


        public void GetFirtstPage(out List<AISMsg_SS> dataList)
        {
            GetPage(1, out dataList);
        }

        public void GetLastPage(out List<AISMsg_SS> dataList)
        {
            GetPage(this.allPageCounts, out dataList);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static dataAnadll.FUS_ICD_MySql;

namespace dataAnadll
{

    public class SystemLog
    {
        public string machine_IP { set; get; }
        public string machine_Name { set; get; }
        public Byte machine_Network { set; get; }
        public Byte machine_Workstate { set; get; }
        public DateTime machine_time { set; get; }
        public string reason { set; get; }

    }


    public class SystemLogProvider
    {
        private int allPageCounts { get; set; }//查询结果的页面总数
        private int pageSize { get; set; }//每页记录数量,默认一千条,可在构造函数里设置
        private StringBuilder conditionStrBuilder { get; set; }//约束条件字符串
        private bool isFromLoadDataBase { get; set; }//是否从导入的数据里查询
        private DataTable latestedDataTable = null;

        private DateTime startTime;
        private DateTime endTime;


        public SystemLogProvider(DateTime startTime_, DateTime endTime_, int pageSizePara = 1000)
        {
            if (pageSizePara <= 0)
                throw new Exception("每页数量大小参数不合法！");
            pageSize = pageSizePara;
            startTime = startTime_;
            endTime = endTime_;
        }

        public int GetPageNum(out int allPageCountReturn)
        {
            string sql = string.Format("select COUNT(*) from machine_state_log where machine_time between '{0}' and '{1}'", startTime, endTime);
            DataTable dt = null;
            try
            {
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);

                int tmpCount = Convert.ToInt32(dt.Rows[0][0]);//总行数
                if (tmpCount % pageSize == 0)
                {
                    allPageCountReturn = tmpCount / pageSize;
                }
                else
                {
                    allPageCountReturn = tmpCount / pageSize + 1;
                }
                allPageCounts = allPageCountReturn;
                return tmpCount;
            }
            catch (Exception)
            {
                allPageCountReturn = 0;
                return 0;
            }
        }


        private void GetPage(int currentPage, out DataTable dt)
        {
            if (startTime == null|| endTime == null)
                throw new Exception("未初始化查询参数");

            if (this.allPageCounts <= 0)
            {
                throw new Exception("数据库中没有符合条件的数据");
            }
            if (currentPage <= 0 || currentPage > this.allPageCounts)
                throw new Exception("查询的页码超出范围");

            string sql = string.Format("select * from machine_state_log where machine_time between '{0}' and '{1}' limit {2},{3}",
                startTime, endTime, (currentPage - 1) * pageSize, pageSize);

            var db = MysqlDBAccess.getInstance();
            dt = latestedDataTable;
            db.query(sql, ref dt);
        }

      

        public void GetPage(int currentPage, out List<SystemLog> dataList)
        {
            DataTable dt = null;
            GetPage(currentPage, out dt);
            dataList = new List<SystemLog>();
            foreach (DataRow rows in dt.Rows)
            {
                SystemLog a = new SystemLog();
                a.machine_IP = rows[1].ToString();
                a.machine_Name = rows[2].ToString();
                a.machine_Network =Convert.ToByte(rows[3]);
                a.machine_Workstate= Convert.ToByte(rows[4]);
                a.machine_time = Convert.ToDateTime(rows[5]);   
                a.reason = rows[6].ToString();

                dataList.Add(a);
            }
        }


        public void GetFirtstPage(out List<SystemLog> dataList)
        {
            GetPage(1, out dataList);
        }

        public void GetLastPage(out List<SystemLog> dataList)
        {
            GetPage(this.allPageCounts, out dataList);
        }
    }
}

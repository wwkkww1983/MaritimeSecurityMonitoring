﻿using System;
using System.Collections.Generic;
using System.Data;
using YimaWF.data;

namespace dataAnadll
{
    public class PipeLineProtectAreaManager
    {
        public PipeLineProtectAreaManager()
        { }
        /// <summary>
        /// 更新管道保护区
        /// </summary>
        /// <param name="pl"></param>
        /// <returns></returns>
        public bool UpdatePipeLineProtectArea(Pipeline pl, int geoMultFactor)
        {
            string pointStr = DataHelper.PointList2Str(pl.PointList, geoMultFactor);
            string sql = string.Format("update oil_pipeline_protect_area set name='{0}'," +
            "point_string='{1}',add_time=now(),point_num={2},alarm_level = {3},width = {4}," +
            "remark='{5}' where id={6}", pl.Name, pointStr, pl.PointList.Count,pl.AlarmLevel, pl.width,pl.Remark,
            pl.ID);

            var db = MysqlDBAccess.getInstance();
            var r = db.queryNoResponse(sql, true);
            if (r != 1)
                return false;
            return true;
        }
        /// <summary>
        /// 新增管道保护区
        /// </summary>
        /// <param name="pl"></param>
        /// <returns></returns>
        public bool AddPipeLineProtectArea(Pipeline pl, int geoMultFactor)
        {
            return UpdatePipeLineProtectArea(pl, geoMultFactor);
        }
        /// <summary>
        /// 删除管道保护区
        /// </summary>
        /// <param name="pl"></param>
        /// <returns></returns>
        public bool DeletePipeLineProtectArea(Pipeline pl)
        {
            Pipeline tmp = new Pipeline();
            tmp.ID = pl.ID;
            tmp.Name = "";
            return UpdatePipeLineProtectArea(tmp, 0);
        }
        /// <summary>
        /// 查询所有管道保护区
        /// </summary>
        /// <returns></returns>
        public List<Pipeline> GetAllPipeLineProtectArea(int geoMultFactor)
        {
            string sql = "select id,name,point_string,width,remark,alarm_level from oil_pipeline_protect_area";
            List<Pipeline> pipelinelist = new List<Pipeline>();
            var db = MysqlDBAccess.getInstance();
            DataTable dt = null;
            db.query(sql, ref dt);
            foreach (DataRow row in dt.Rows)
            {
                if (row[2].ToString().Length > 0)
                {
                    Pipeline pl = new Pipeline();
                    pl.ID = Convert.ToInt32(row[0]);
                    pl.Name = row[1].ToString();
                    pl.PointList = DataHelper.PointStr2List(row[2].ToString(), geoMultFactor);
                    pl.width = Convert.ToInt32(row[3]);
                    pl.Remark = row[4].ToString();
                    pl.AlarmLevel = (int)row[5];
                    pipelinelist.Add(pl);
                }
            }
            return pipelinelist;
        }
    }
}

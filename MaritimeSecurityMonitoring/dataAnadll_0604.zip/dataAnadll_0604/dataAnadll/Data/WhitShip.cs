using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class WhiteShip
    {
        public int MMSI {set; get; }
        public string ShipNumber {set; get; }
        public uint IMO {set; get; }
        public string CallID {set; get; }
        public string ShipName {set; get; }
        public string ShipDepartment {set; get; }
        public string ShipUsage {set; get; }
    }
}
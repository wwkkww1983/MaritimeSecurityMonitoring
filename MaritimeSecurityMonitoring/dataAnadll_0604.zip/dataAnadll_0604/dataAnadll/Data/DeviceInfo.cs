using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class DeviceInfo
    {
        public string Name {set;get;}
        public string IP {set;get;}
        public int Port1 {set;get;}
        public int Port2 {set;get;}
        public int Port3 {set;get;}
        public int Port4 {set;get;}
    }
}
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class OperationLog
    {
        public int UserID { set; get; }
        public string OptionName { set; get; }
        public int LogType { set; get; }
        public string Result { set; get; }
        public string Note { set; get; }
        public string UserName { set; get; }
        public DateTime OptionTime { set; get; }
        public string IP { set; get; }
    }
}
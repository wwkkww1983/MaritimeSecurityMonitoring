using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class User
    {
        public int ID {set; get; }
        public string Name {get; set;}
        public int RoleID {get; set;}
        public string Department {set; get;}
        public string Level {set; get;}
        public string Email {get; set;}
        public string Telephone {get; set;}
        public string Phone {get; set;}

        public string Password { get; set; }
    }
}
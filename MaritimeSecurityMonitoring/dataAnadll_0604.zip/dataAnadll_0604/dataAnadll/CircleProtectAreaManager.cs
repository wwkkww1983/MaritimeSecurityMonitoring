﻿using System;
using System.Collections.Generic;
using System.Data;
using YimaEncCtrl;
using YimaWF.data;

namespace dataAnadll
{
    public class CircleProtectAreaManager
    {
        public CircleProtectAreaManager()
        { }
        /// <summary>
        /// 更新圆形保护区
        /// </summary>
        /// <param name="pl">保护区类</param>
        /// <param name="geoMultFactor">乘积因子</param>
        /// <returns>操作结果</returns>
        public bool UpdateCircleProtectArea(ProtectZone pz, int geoMultFactor)
        {
            var a = pz.ContentColor.ToString();
            string sql = string.Format("update alarm_circle set name='{0}'," +
            "alarm_level={1},radius={2},colour = {3}" +
            " where id={4}", pz.Name, pz.AlarmLevel, pz.Radius,
             pz.ContentColor.ToArgb() & 0xffffff, pz.ID);

            var db = MysqlDBAccess.getInstance();
            var r = db.queryNoResponse(sql, true);
            if (r != 1)
                return false;
            return true;
        }
        /// <summary>
        /// 新增圈层区域
        /// </summary>
        /// <param name="pl"></param>
        /// <returns></returns>
        public bool AddCircleProtectArea(ProtectZone pz, int geoMultFactor)
        {
            return UpdateCircleProtectArea(pz, geoMultFactor);
        }
        /// <summary>
        /// 删除圈层区域
        /// </summary>
        /// <param name="pl"></param>
        /// <returns></returns>
        public bool DeletePipeLineProtectArea(ProtectZone pz)
        {
            ProtectZone tmp = new ProtectZone(null, 0,System.Drawing.Color.FromArgb(0));
            tmp.ID = pz.ID;
            tmp.Name = "";
            return UpdateCircleProtectArea(tmp, 0);
        }
        /// <summary>
        /// 查询所有圈层保护区
        /// </summary>
        /// <returns></returns>
        public List<ProtectZone> GetAllCircleProtectArea(int geoMultFactor)
        {
            string sql = "select ac.id,ac.name,ac.radius,ac.colour,pc.point_string from alarm_circle as ac, platform_center as pc where pc.id = 1;";
            List<ProtectZone> circleprotectlist = new List<ProtectZone>();
            var db = MysqlDBAccess.getInstance();
            DataTable dt = null;
            db.query(sql, ref dt);
            foreach (DataRow row in dt.Rows)
            {
                float r = 0;
                if(row[2].ToString().Length > 0)
                    r = (float)row[2];
                if (r != 0)
                {
                    var a = DataHelper.PointStr2List((string)row[4], geoMultFactor)[0];
                    //var b = (int)row[3];
                   // var color = System.Drawing.Color.FromArgb(b & 255, b >> 8 & 255, b >> 16 & 255);
                    //var d = color.ToArgb();
                    ProtectZone pz = new ProtectZone(DataHelper.PointStr2List((string)row[4], geoMultFactor)[0], r, System.Drawing.Color.FromArgb((int)row[3]));
                    pz.ID = Convert.ToInt32(row[0]);
                    pz.Name = row[1].ToString();
                    var c = pz.ContentColor.ToArgb();
                    circleprotectlist.Add(pz);
                }
            }
            return circleprotectlist;
        }
    }
}

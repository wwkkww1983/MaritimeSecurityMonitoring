﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class FUS_ICD_MySql
    {
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct FusPara_S
        {
            // FusPara_S
            // 融合参数结构体
            /*  报文名称：融合参数结构体          传输形式：点对点
             *  通信协议：TCP                     报文长度：48Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式    */
            public float fXYZThreshold;     //XYZ方向上的门限；0~X m （暂定5000米）
            public float fDisThreshold;     //距离上的门限；0~X m（暂定0）
            public float fAngleThreshold;   //角度的门限；  0~X（暂定0）
            public byte ucAlarmThreshold;   //告警的门限，1表示>=1就提示、告警，2表示>=2才告警
            public long lRdDieTime;         //雷达消失时间，多久认为雷达航迹撤销；（暂定36秒）
            public long lAISDieTime;        //雷达消失时间，多久认为雷达航迹撤销；（暂定36秒）
            public long lM;                 //（暂定为2）
            public long lN;                 //起始规则，M/N,一般选择2/3起始，也可以设置；（暂定为3）
            public byte UcEstiArith;        //估计算法，1，选择最优，2加权 3=SF;（暂定为1）
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 2)]
            public byte[] reserve;          //保留2字节
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct FusTarget_S
        {
            // FusTarget_S
            // 单个融合目标结构体
            /*  报文名称：融合目标结构体          传输形式：点对点
             *  通信协议：UDP                     报文长度：183Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式    */
            public int Fus_count;         //FUS自增标识
            public long lTime;            //融合时间: 1970年1月1日到发现目标的秒数
            public ushort lFusBatchID; //融合批号
            public byte FusDataType;  //融合数据类型，（NAV=1，AIS=2,雷达=3，光电=4，.....表示选择最优子源） //融合=100,预测=101，控制命令=200	
            public byte SrcNum;           //子源个数
            public byte ucConditionType;//0=未知，1=陆地，2=空中，3=水面， 4=水下
            public byte ucArmyCivil;  //0=未知，1=军用，2=民用
            public byte ucIFFAttrib;  //0=未知，1=敌，2=我，3=中立，4=友，5=可疑
            public byte ucTargetClass;    //目标类型，待定义
            public byte ucTargetType; //目标型号，待定义，
            public int ucAlarmNum_State;   //高8位为圈层告警区域编号201~205，多边形告警区域编号211~215，管道告警区域编号221~225
            public int ucAlarmNum;         //低8位中低2位为驶入驶出告警，1为驶入，2为驶出，3为驻留 
            //以下为AIS能够提供的信息，全部保留；如果没有，则不赋值；
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 8)]
            public char[] cCall_ID;   //呼号@@@@@@@ = 默认值，未知，以‘\0’结束
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 35)]
            public char[] cName;     //名称@@@@@@@ = 默认值，未知，以‘\0’结束
            public short shDistanceA;  //单位米；0-511
            public short shDistanceB;  //单位米  0-511
            public byte ucDistanceC;  //单位米  0-63
            public byte ucDistanceD;  //单位米  0-63
            public byte ucShipType;       //船货类型
            public byte ucMonth;      //预计到达时间的月
            public byte ucDay;            //预计到达时间的日
            public byte ucHour;           //预计到达时间的时
            public byte ucMinite;     //预计到达时间的分
            public float fMaxDeep;     //最大吃水深度
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 21)]
            public char[] cDestination;  //目的地，@@@@@@@ = 默认值，未知，以‘\0’结束
            public byte ucAIS_Class;  //AIS设备类型，0=Class_A;1=Class_B;2=基站；3=航标；4=搜索直升机；5=START搜救应答器
            public uint ulCount;     //船载人数
            public long ulTime;           //时间；1970年1月1日到发现目标的秒数
            //融合的位置参数
            public double dLongti;
            public double dLati;
            public float fHeight;          //目标的经纬高；
            public float fDistance;        //目标距离,m
            public float fSpeed;        //目标速度
            public double dNorthCourse;    //目标的方位角
            public double dPitching;       //目标的俯仰角
            //子源的构成关系
            public uint ulRdbatchID; //雷达的批号，无雷达=0；
            public uint ulAISBatchID;    //AIS的ulIMO 范围0-99999999，0表示无AIS
            public uint ulOpticalID; //光学提供的目标批号，0表示不存在；
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Alarm_Dot_S
        {
            // Alarm_Dot_S
            // 圈层设置中心点坐标结构
            /*  报文名称：中心点坐标结构体        传输形式：点对点
             *  通信协议：TCP                     报文长度：20Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public double dLongti;
            public double dLati;    //经纬度
            public float fHeight;  //虽然暂时不用，建议保留；填写0即可。
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Alarm_Circle_S
        {
            // Alarm_Circle_S
            // 圈层设置结构体
            /*  报文名称：圈层设置结构体          传输形式：点对点
             *  通信协议：TCP                     报文长度：26Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public byte ucCycleAlarmNum;   //告警编号：201~205
            public byte ucAlarmLevel;    //告警的级别 0无效
            public Alarm_Dot_S AlarmCenter;       //告警的中心点;
            public float fAlarmR;	       //告警的半径；
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Alarm_Polygon_S
        {
            // Alarm_Polygon_S
            // 不规则告警区域设置结构体
            /*  报文名称：不规则告警区域          传输形式：点对点
             *  通信协议：TCP                     报文长度：203Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public byte ucPolygonAlarmNum;  //告警编号211~215
            public byte ucAlarmLevel;       //告警级别
            public byte ucPotNum;           //多边形的点数构成；必须从1-2-3-顺着排
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 10)]
            public Alarm_Dot_S[] PotArray;	//最多可允许10个点；
        };

        public struct Alarm_Pipe_S
        {

            public byte ucPipeAlarmNum;     //告警编号221~225
            public byte ucAlarmLevel;     //告警级别
            public byte ucPotNum;         //管道点数构成；必须从1-2-3-顺着排，
            public int ucPipeWidth;       //管道宽度
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 10)]
            public Alarm_Dot_S[] PotArray;  //最多可允许10个点；
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct RadarPara_S
        {
            // RadarPara_S
            // 雷达站结构体
            /*  报文名称：雷达站结构体           传输形式：点对点
             *  通信协议：UDP                    报文长度：27Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public byte ucRadarID;          //雷达标识号
            public float lDisPrecision;     //距离精度,单位，m
            public float lDirectionPreci;   //方位角精度
            public double dLongti;          //经度 -180~180°
            public double dLati;            //维度 -90~90°
            public ushort lHeight;          //高度
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct RdDetectMsg_S
        {
            // RdDetectMsg_S
            // 单个雷达目标结构体
            /*  报文名称：单个雷达目标结构体              传输形式：点对点
             *  通信协议：UDP                     报文长度：99Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public RadarPara_S PardPara; //雷达参数，
            public int radar_count;         //radar自增标识
            public ushort lTargetNo;     //批号
            public byte ucTargetFlag;    // 处理标识，0——新增目标，1更新目标，2删除目标
            public long lFoundTime;     //发现时间
            public uint ulTargetDis;    // 距离，单位，米           2017/1/5
            public double dNorthCourse;  //真北方位角，单位°       2017/1/5
            public double dPitching;     //俯仰角，°二维雷达，默认为0；     2017/1/5
            public float ulTargetSpeed; // 地速度，LBS = 0.1 m/s
            public float ulTargetCourse;// 航向角		
            public double dLongti;       //经度（-180-180）
            public double dLati;         //纬度（-90，90）
            public float fHeight;        //目标高度；
            public byte ucTargetType;	 //0未知，1- 2- 3- 4- 
        };


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct RdDetectMsg_SS
        {
            // RdDetectMsg_S
            // 单个雷达目标结构体
            /*  报文名称：单个雷达目标结构体              传输形式：点对点
             *  通信协议：UDP                     报文长度：99Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public RadarPara_S PardPara; //雷达参数，
            public string radar_count;         //radar自增标识
            public string lTargetNo;     //批号
            public string ucTargetFlag;    // 处理标识，0——新增目标，1更新目标，2删除目标
            public string lFoundTime;     //发现时间
            public string ulTargetDis;    // 距离，单位，米           2017/1/5
            public string dNorthCourse;  //真北方位角，单位°       2017/1/5
            public string dPitching;     //俯仰角，°二维雷达，默认为0；     2017/1/5
            public string ulTargetSpeed; // 地速度，LBS = 0.1 m/s
            public string ulTargetCourse;// 航向角		
            public string dLongti;       //经度（-180-180）
            public string dLati;         //纬度（-90，90）
            public string fHeight;        //目标高度；
            public string ucTargetType;	 //0未知，1- 2- 3- 4- 
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct RdStatus_S
        {
            // RdStatus_S
            // 雷达设备状态结构体
            /*  报文名称：雷达设备状态结构体              传输形式：点对点
             *  通信协议：UDP                     报文长度：99Bit
             *  发方：雷达                    	      
             *  收方：态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public RadarPara_S PardPara;      //雷达站标识结构体
            public byte ucRadarStatus;       //雷达整体状态，1：正常，2：异常(任一模块故障)
            public byte ucAntStatus;        //雷达天线状态，1：正常，n：模块故障码  
            public byte ucTransStatus;      //雷达发射机状态，1：正常，n：模块故障码
            public byte ucRecStatus;        //雷达接收机状态，1：正常，n：模块故障码
            public byte ucProcessorStatus;  //处理器状态，1：正常，n：模块故障码
            public double dScanCourse;     //雷达扫描角度，单位：°
            public float fScanSpeed;		//雷达扫描速度：单位：转/秒，精度：0.1转/s
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct AISMsg_S
        {
            // AISMsg_S
            // AIS目标信息结构体
            /*  报文名称：AIS目标信息结构体              传输形式：点对点
             *  通信协议：UDP                     报文长度：142Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public int AIS_count;         //AIS自增标识
            public byte ucMsgHead1;       //信息头1 0xeb；
            public byte ucMsgHead2;       //信息头2 0x90;
            public byte ucRptType;        //报文类型1-24；
            public uint ulRecoCode;      //唯一识别码
            public byte ucSailStatus;     //航行状态 1
            public float fDirectSpeed;    //对地航速
            public double dLong;          //经度 181度=未知，单位度
            public double dLat;           //纬度 91度 =未知，单位度
            public float fDirectCourse;   //360=未知，单位度
            public short shTrueHeading;   //511=未知，单位度（有效范围0-359）
            public uint ulIMO;           //IMO范围0-99999999，0：默认值
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 8)]
            public char[] cCall_ID;      //呼号@@@@@@@ = 默认值，未知，以‘\0’结束
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 35)]
            public char[] cName;         //名称@@@@@@@ = 默认值，未知，以‘\0’结束
            public short shDistanceA;    //单位米；0-511
            public short shDistanceB;    //单位米  0-511
            public byte ucDistanceC;     //单位米  0-63
            public byte ucDistanceD;     //单位米  0-63
            public byte ucShipType;      //船货类型
            public byte ucMonth;         //预计到达时间的月
            public byte ucDay;           //预计到达时间的日
            public byte ucHour;          //预计到达时间的时
            public byte ucMinite;        //预计到达时间的分
            public float fMaxDeep;       //最大吃水深度
            [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 21)]
            public char[] cDestination;  //目的地，@@@@@@@ = 默认值，未知，以‘\0’结束
            public byte ucAIS_Class;     //AIS设备类型，0=Class_A;1=Class_B;2=基站；3=航标；4=搜索直升机；5=START搜救应答器
            public uint ulCount;        //船载人数
            public long ulTime;         //这个参数用来记录时间；
        };

        public struct AISMsg
        {
            // AISMsg_S
            /* AIS目标信息结构体
            /* 通信层传送给态势显示的AIS目标结构体  
            */
            public int IMO;   //IMO
            public string MMSI;  //MMSI唯一识别码
            public string CallSign;   //呼号           
            public string Nationality;  //国籍 
            public string UpdateTime;
            public string Name;
            public string ArriveTime;
            public byte SailStatus;//航行状态          
            public float MaxDeep;//最大吃水深度       
            public int Capacity;//船载人数           
            public string Destination;//目的地
            public int AISType;
            public float fDirectSpeed;    //对地航速
            public double dLong;          //经度 181度=未知，单位度
            public double dLat;           //纬度 91度 =未知，单位度
            public float fDirectCourse;   //360=未知，单位度
            public short shTrueHeading;   //511=未知，单位度（有效范围0-359）
            public byte ucShipType;      //船货类型
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Boot_Down_S
        {
            // Boot_Down_S
            // 态势开机报文
            /*  报文名称：开机报文结构体        传输形式：点对点
             *  通信协议：UDP                     报文长度：13Bit
             *  发方：态势                   	      
             *  收方：融合                	
             *  传输频率：态势开机时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public int bootDown;    //开、关机，0=关机，1=开机
            public long hostIP1;    //本机IP
            public byte Reserve;  //保留。
        };

        public struct AISMsg_SS
        {
            // AISMsg_S
            // AIS目标信息结构体
            /*  报文名称：AIS目标信息结构体              传输形式：点对点
             *  通信协议：UDP                     报文长度：142Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式  */
            public string AIS_count;         //AIS自增标识
            public string ucMsgHead1;       //信息头1 0xeb；
            public string ucMsgHead2;       //信息头2 0x90;
            public string ucRptType;        //报文类型1-24；
            public string ulRecoCode;      //唯一识别码
            public string ucSailStatus;     //航行状态 1
            public string fDirectSpeed;    //对地航速
            public string dLong;          //经度 181度=未知，单位度
            public string dLat;           //纬度 91度 =未知，单位度
            public string fDirectCourse;   //360=未知，单位度
            public string shTrueHeading;   //511=未知，单位度（有效范围0-359）
            public string ulIMO;           //IMO范围0-99999999，0：默认值
            public string cCall_ID;      //呼号@@@@@@@ = 默认值，未知，以‘\0’结束         
            public string cName;         //名称@@@@@@@ = 默认值，未知，以‘\0’结束
            public string shDistanceA;    //单位米；0-511
            public string shDistanceB;    //单位米  0-511
            public string ucDistanceC;     //单位米  0-63
            public string ucDistanceD;     //单位米  0-63
            public string ucShipType;      //船货类型
            public string ucMonth;         //预计到达时间的月
            public string ucDay;           //预计到达时间的日
            public string ucHour;          //预计到达时间的时
            public string ucMinite;        //预计到达时间的分
            public string fMaxDeep;       //最大吃水深度
            public string cDestination;  //目的地，@@@@@@@ = 默认值，未知，以‘\0’结束
            public string ucAIS_Class;     //AIS设备类型，0=Class_A;1=Class_B;2=基站；3=航标；4=搜索直升机；5=START搜救应答器
            public string ulCount;        //船载人数
            public string ulTime;         //这个参数用来记录时间；
            public string country;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct FusTarget_SS
        {
            // FusTarget_S
            // 单个融合目标结构体
            /*  报文名称：融合目标结构体          传输形式：点对点
             *  通信协议：UDP                     报文长度：183Bit
             *  发方：态势/融合                    	      
             *  收方：融合/态势	                	
             *  传输频率：需要时发送
             *  所有的数据，均采用UDP_Head_S + 对应接口的形式    */
            public string Fus_count;         //FUS自增标识
            public string lTime;            //融合时间: 1970年1月1日到发现目标的秒数
            public string lFusBatchID; //融合批号
            public string FusDataType;  //融合数据类型，（NAV=1，AIS=2,雷达=3，光电=4，.....表示选择最优子源） //融合=100,预测=101，控制命令=200	
            public string SrcNum;           //子源个数
            public string ucConditionType;//0=未知，1=陆地，2=空中，3=水面， 4=水下
            public string ucArmyCivil;  //0=未知，1=军用，2=民用
            public string ucIFFAttrib;  //0=未知，1=敌，2=我，3=中立，4=友，5=可疑
            public string ucTargetClass;    //目标类型，待定义
            public string ucTargetType; //目标型号，待定义，
            public string ucAlarmNum_State;   //高8位为圈层告警区域编号201~205，多边形告警区域编号211~215，管道告警区域编号221~225
            public string ucAlarmNum;         //低8位中低2位为驶入驶出告警，1为驶入，2为驶出，3为驻留 
            //以下为AIS能够提供的信息，全部保留；如果没有，则不赋值；
            public string cCall_ID;   //呼号@@@@@@@ = 默认值，未知，以‘\0’结束
            public string cName;     //名称@@@@@@@ = 默认值，未知，以‘\0’结束
            public string shDistanceA;  //单位米；0-511
            public string shDistanceB;  //单位米  0-511
            public string ucDistanceC;  //单位米  0-63
            public string ucDistanceD;  //单位米  0-63
            public string ucShipType;       //船货类型
            public string ucMonth;      //预计到达时间的月
            public string ucDay;            //预计到达时间的日
            public string ucHour;           //预计到达时间的时
            public string ucMinite;     //预计到达时间的分
            public string fMaxDeep;     //最大吃水深度
            public string cDestination;  //目的地，@@@@@@@ = 默认值，未知，以‘\0’结束
            public string ucAIS_Class;  //AIS设备类型，0=Class_A;1=Class_B;2=基站；3=航标；4=搜索直升机；5=START搜救应答器
            public string ulCount;     //船载人数
            public string ulTime;           //时间；1970年1月1日到发现目标的秒数
            //融合的位置参数
            public string dLongti;
            public string dLati;
            public string fHeight;          //目标的经纬高；
            public string fDistance;        //目标距离,m
            public string fSpeed;        //目标速度
            public string dNorthCourse;    //目标的方位角
            public string dPitching;       //目标的俯仰角
            //子源的构成关系
            public string ulRdbatchID; //雷达的批号，无雷达=0；
            public string ulAISBatchID;    //AIS的ulIMO 范围0-99999999，0表示无AIS
            public string ulOpticalID; //光学提供的目标批号，0表示不存在；
            public string country;
        };
    }
}

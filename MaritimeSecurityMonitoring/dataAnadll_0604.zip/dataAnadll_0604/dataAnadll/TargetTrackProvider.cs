﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YimaWF.data;

namespace dataAnadll
{
    public class TargetTrackProvider
    {
        public static int SkipNum = 10;


        public TargetTrackProvider()
        {
        }

        /// <summary>
        /// 获取AIS批号的list
        /// </summary>
        /// <param name="startTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <returns>批号list</returns>
        public List<int> GetAISTargetIDList(DateTime startTime, DateTime endTime)
        {
            List<int> list = new List<int>();

            string sql = string.Format("select ulRecoCode from AIS_data where ulTime BETWEEN {0} and {1} group by ulRecoCode  ORDER BY ulTime ASC",
            DataHelper.ConvertDateTime2UnixTime(startTime.ToUniversalTime()), DataHelper.ConvertDateTime2UnixTime(endTime.ToUniversalTime()));


            try
            {
                DataTable dt = null;
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);
                foreach (DataRow row in dt.Rows)
                {
                    list.Add((int)row[0]);
                }
            }
            catch (System.Exception e)
            {

                throw e;
            }

            return list;
        }

        /// <summary>
        /// 获取融合批号的list
        /// </summary>
        /// <param name="startTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <returns>批号list</returns>
        public List<int> GetFuseTargetIDList(DateTime startTime, DateTime endTime)
        {
            List<int> list = new List<int>();

            string sql = string.Format("select lFusBatchID from fuse_data where lTime BETWEEN {0} and {1} group by lFusBatchID  ORDER BY lTime ASC",
            DataHelper.ConvertDateTime2UnixTime(startTime.ToUniversalTime()), DataHelper.ConvertDateTime2UnixTime(endTime.ToUniversalTime()));


            try
            {
                DataTable dt = null;
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);
                foreach (DataRow row in dt.Rows)
                {
                    list.Add((int)row[0]);
                }
            }
            catch (System.Exception e)
            {

                throw e;
            }

            return list;
        }

        /// <summary>
        /// 获取雷达批号已经相应的雷达ID
        /// </summary>
        /// <param name="startTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <returns>int[]的list，int[0]为雷达批号，int[1]为雷达ID</returns>
        public List<int[]> GetRadarTargetIDList(DateTime startTime, DateTime endTime, int radarID)
        {
            List<int[]> list = new List<int[]>();

            string[] sqls = new string[1];
            sqls[0] = string.Format("select lTargetNo,radar_id  from radar_data where radar_id={0} and lFoundTime BETWEEN {1} and {2} group by lTargetNo  ORDER BY lFoundTime ASC;",
            radarID, DataHelper.ConvertDateTime2UnixTime(startTime.ToUniversalTime()), DataHelper.ConvertDateTime2UnixTime(endTime.ToUniversalTime()));
            //sqls[1] = string.Format("select lTargetNo,radar_id  from radar_data where radar_id=2 and lFoundTime BETWEEN {0} and {1} group by lTargetNo  ORDER BY lFoundTime ASC;",
            //DataHelper.ConvertDateTime2UnixTime(startTime.ToUniversalTime()), DataHelper.ConvertDateTime2UnixTime(endTime.ToUniversalTime()));

            try
            {
                List<DataTable> dts = null;
                var db = MysqlDBAccess.getInstance();
                db.query(sqls, ref dts);
                foreach (DataTable dt in dts)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        int[] tmp = new int[2];
                        tmp[0] = (int)row[0];
                        tmp[1] = (int)row[1];
                        list.Add(tmp);
                    }
                }

            }
            catch (System.Exception e)
            {

                throw e;
            }

            return list;
        }
        /// <summary>
        /// 获取AIS目标的航迹
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <param name="targetID">目标AIS批号</param>
        /// <param name="geoMultFactor"></param>
        /// <returns>Target类，包含目标航迹，直接传入海图ShowTargetTrack接口即可</returns>
        public Target GetAISTargetTrack(DateTime startTime, DateTime endTime, int targetID, int geoMultFactor)
        {
            Target t = new Target(targetID, 0, 0, TargetSource.AIS);
            string sql = string.Format("select fDirectCourse, ulTime, dLong, dLat, type from AIS_data where ulRecoCode={0} AND ulTime BETWEEN {1} and {2} ORDER BY ulTime ASC", 
            targetID, DataHelper.ConvertDateTime2UnixTime(startTime.ToUniversalTime()), DataHelper.ConvertDateTime2UnixTime(endTime.ToUniversalTime()));

            try
            {
                DataTable dt = null;
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);
                int count = 1;
                foreach(DataRow row in dt.Rows)
                {
                    if (count == 1 || count == dt.Rows.Count || count % TargetTrackProvider.SkipNum == 0 || ((int)row[4]) == 2)
                    {
                        TrackPoint tp = new TrackPoint(DataHelper.GetGeoPoint((double)row[2], (double)row[3], geoMultFactor));
                        tp.Course = (double)row[0];
                        tp.Time = DataHelper.ConvertIntDateTime(Convert.ToUInt32(row[1])).ToString();
                        t.Track.Add(tp);
                        if (((int)row[4]) == 2)
                            break;
                    }
                    count++;
                }
            }
            catch (System.Exception e)
            {
                
                throw e;
            }
            return t;
        }


        public Target GetFuseTargetTrack(DateTime startTime, DateTime endTime, int targetID, int geoMultFactor)
        {
            Target t = new Target(targetID, 0, 0, TargetSource.Merge);
            string sql = string.Format("select dNorthCourse, lTime, dLongti, dLati, type from fuse_data where lFusBatchID={0} AND lTime BETWEEN {1} and {2} ORDER BY lTime ASC", 
            targetID, DataHelper.ConvertDateTime2UnixTime(startTime.ToUniversalTime()), DataHelper.ConvertDateTime2UnixTime(endTime.ToUniversalTime()));

            try
            {
                DataTable dt = null;
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);
                int count = 1;
                foreach(DataRow row in dt.Rows)
                {
                    if (count == 1 || count == dt.Rows.Count || count % TargetTrackProvider.SkipNum == 0 || ((int)row[4]) == 2)
                    {
                        TrackPoint tp = new TrackPoint(DataHelper.GetGeoPoint((double)row[2], (double)row[3], geoMultFactor));
                        tp.Course = (double)row[0];
                        tp.Time = DataHelper.ConvertIntDateTime(Convert.ToUInt32(row[1])).ToString(DataHelper.DateTimeFormStr);
                        t.Track.Add(tp);
                        if (((int)row[4]) == 2)
                            break;
                    }
                    count++;
                }
            }
            catch (System.Exception e)
            {
                
                throw e;
            }
            return t;
        }

        public Target GetRadarTargetTrack(DateTime startTime, DateTime endTime, int targetID, int radarID, int geoMultFactor)
        {
            Target t = new Target(targetID, 0, 0, TargetSource.Radar);
            string sql = string.Format("select ulTargetCourse, lFoundTime, dLongti, dLati, ucTargetFlag from radar_data where lTargetNo={0} and radar_id={1} AND lFoundTime BETWEEN {2} and {3} ORDER BY lFoundTime ASC", 
            targetID, radarID, DataHelper.ConvertDateTime2UnixTime(startTime.ToUniversalTime()), DataHelper.ConvertDateTime2UnixTime(endTime.ToUniversalTime()));

            try
            {
                DataTable dt = null;
                var db = MysqlDBAccess.getInstance();
                db.query(sql, ref dt);
                int count = 1;
                foreach(DataRow row in dt.Rows)
                {
                    if (count == 1 || count == dt.Rows.Count || count % TargetTrackProvider.SkipNum == 0 || ((int)row[4]) == 2)
                    {
                        TrackPoint tp = new TrackPoint(DataHelper.GetGeoPoint((double)row[2], (double)row[3], geoMultFactor));
                        tp.Course = (double)row[0];
                        tp.Time = DataHelper.ConvertIntDateTime(Convert.ToUInt32(row[1])).ToString();
                        t.Track.Add(tp);
                        if (((int)row[4]) == 2)
                            break;
                    }
                    count++;
                }
            }
            catch (System.Exception e)
            {
                
                throw e;
            }
            return t;
        }
    }
}

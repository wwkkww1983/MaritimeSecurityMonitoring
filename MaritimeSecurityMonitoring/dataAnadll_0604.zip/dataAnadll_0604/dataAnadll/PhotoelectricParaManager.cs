﻿using System;
using System.Data;


namespace dataAnadll
{
    public class PhotoelectricParaManager
    {
        public PhotoelectricParaManager()
        { }
        /// <summary>
        /// 修改光电参数
        /// </summary>
        /// <param name="pps"></param>
        /// <returns></returns>
        public bool UpdatePhotoelectricPara(PhotoelectricParas pps)
        {
            string sql = string.Format("update PhotoelectricModule set azimuth_drive_drift_compensate={0}," +
            "pitch_drive_drift_compensate={1},azimuth_gyro_drift_compensate={2},pitch_gyro_drift_compensate = {3},"+
            "set_height = {4} where id={5}", pps.AzimuthDriverCompensation,pps.PitchDriveCompensation,
            pps.AzimuthGyroCompensation,pps.PitchgGyroCompensation,pps.SetHeight,1);

            var db = MysqlDBAccess.getInstance();
            var r = db.queryNoResponse(sql, true);
            if (r != 1)
                return false;
            return true;
        }
        /// <summary>
        /// 新增光电参数
        /// </summary>
        /// <param name="pps"></param>
        /// <returns></returns>
        public bool AddPhotoelectricPara(PhotoelectricParas pps)
        {
            return UpdatePhotoelectricPara(pps);
        }
       
        /// <summary>
        /// 查询现在的光电参数
        /// </summary>
        /// <returns></returns>
        public PhotoelectricParas GetPhotoelectricParas()
        {
            string sql = "select azimuth_drive_drift_compensate,pitch_drive_drift_compensate,azimuth_gyro_drift_compensate,"+
                "pitch_gyro_drift_compensate,set_height from PhotoelectricModule";
            PhotoelectricParas pps = new PhotoelectricParas();
            var db = MysqlDBAccess.getInstance();
            DataTable dt = null;
            db.query(sql, ref dt);
            pps.AzimuthDriverCompensation = (int)(dt.Rows[0][0]);
            pps.PitchDriveCompensation = (int)(dt.Rows[0][1]);
            pps.AzimuthGyroCompensation = (int)(dt.Rows[0][2]);
            pps.PitchgGyroCompensation = (int)(dt.Rows[0][3]);
            pps.SetHeight = (float)(dt.Rows[0][4]);
            //pps.PitchUpLimit = (int)(dt.Rows[0][5]);
            //pps.AzimuthLeftLimit = (int)(dt.Rows[0][6]);
            //pps.AzimuthRightLimit = (int)(dt.Rows[0][7]);
            return pps;
        }
        /// <summary>
        /// 光电参数类
        /// </summary>
    }

    public class PhotoelectricParas
    {
        public int AzimuthDriverCompensation; //方位驱动器补偿量
        public int PitchDriveCompensation; //俯仰驱动器补偿量
        public int AzimuthGyroCompensation; //方位陀螺补偿量
        public int PitchgGyroCompensation; //俯仰陀螺补偿量
        //public int PitchLowerLimit; //俯仰下限位角度
        //public int PitchUpLimit; //俯仰上限位角度
        //public int AzimuthLeftLimit; //方位左限位角度
        //public int AzimuthRightLimit; //方位右限位角度
        public float SetHeight;    //光电架设高度
    }
}

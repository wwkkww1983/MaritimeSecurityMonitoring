using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dataAnadll
{
    public class DeviceInfoManager
    {
        /// <summary>
        /// ���������豸����
        /// </summary>
        /// <param name="name">�豸����</param>
        /// <param name="ip">IP</param>
        /// <param name="port1">�˿�1</param>
        /// <param name="port2">�˿�2</param>
        /// <param name="port3">�˿�3</param>
        /// <param name="port4">�˿�4</param>
        /// <returns>�������</returns>
        public bool AddDeviceInfo(string name, string ip, int port1, int port2, int port3, int port4)
        {
            string sql = string.Format("insert into IP_parameter values ('{0}','{1}',{2},{3},{4},{5},0)", 
            name, ip, port1, port2, port3, port4);
            if(MysqlDBAccess.getInstance().queryNoResponse(sql, false) == 1)
                return true;
            else
                return false;
        }

        /// <summary>
        /// ��ȡ�����豸�Ĳ���
        /// </summary>
        /// <returns>�豸��������</returns>
        public List<DeviceInfo> GetAllDeviceInfo()
        {
            string sql = "select * from IP_parameter";
            DataTable dt = null;
            List<DeviceInfo> list = new List<DeviceInfo>();
            if(MysqlDBAccess.getInstance().query(sql, ref dt) > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    DeviceInfo di = new DeviceInfo();
                    di.Name = (string)row[0];
                    di.IP = (string)row[1];
                    di.Port1 = (int)row[2];
                    di.Port2 = (int)row[3];
                    di.Port3 = (int)row[4];
                    di.Port4 = (int)row[5];
                    list.Add(di);
                }
            }
            return list;
        }

        /// <summary>
        /// ����ĳһ���豸�Ĳ�����ͨ���豸���������豸
        /// </summary>
        /// <param name="di">������</param>
        /// <returns>�������</returns>
        public bool UpdateDeviceInfo(DeviceInfo di)
        {
            string sql = string.Format("update IP_parameter set IP='{0}',port_1={1},port_2={2},port_3={3},port_4={4} where device_name='{5}'",
            di.IP, di.Port1, di.Port2, di.Port3, di.Port4, di.Name);
            if(MysqlDBAccess.getInstance().queryNoResponse(sql, false) == 1)
                return true;
            else
                return false;
        }

        /// <summary>
        /// ɾ��ĳһ���豸�Ĳ�����ͨ���豸���������豸
        /// </summary>
        /// <param name="deviceName">�豸��</param>
        /// <returns>�������</returns>
        public bool DeleteDeviceInfo(string deviceName)
        {
            string sql = string.Format("delete from ip_parameter where device_name ='{0}'", deviceName);
            if (MysqlDBAccess.getInstance().queryNoResponse(sql, false) == 1)
                return true;
            else
                return false;
        }
    }
}
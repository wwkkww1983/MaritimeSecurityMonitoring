using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace dataAnadll
{
    public class TrackEventManager
    {
        /// <summary>
        /// д������¼�
        /// </summary>
        /// <param name="name">�¼�����</param>
        /// <param name="dis">�¼�����</param>
        /// <param name="startTime">��ʼʱ��</param>
        /// <param name="endTime">����ʱ��</param>
        /// <returns>�������</returns>
        public bool WriteTrackEvent(string name, string dis, DateTime startTime, DateTime endTime, int type)
        {
            string sql = string.Format("insert into track_event values (0,'{0}','{1}', '{2}', '{3}', {4});", 
            name, dis, startTime.ToString(DataHelper.DateTimeFormStr), endTime.ToString(DataHelper.DateTimeFormStr), type);
            var db = MysqlDBAccess.getInstance();
            var r = db.queryNoResponse(sql, false);
            if(r != 1)
                return false;
            return true;
        }


        /*public List<TrackEvent> GetTrackEvent(DateTime startTime, DateTime endTime)
        {
            List<TrackEvent> list = new List<TrackEvent>();
            string sql = string.Format("select * from track_event where end_time > '{0}' and end_time < '{1}';",
                startTime.ToString(DataHelper.DateTimeFormStr), endTime.ToString(DataHelper.DateTimeFormStr));
            DataTable dt = null;
            var db = MysqlDBAccess.getInstance();
            db.query(sql, ref dt);

            foreach (DataRow row in dt.Rows)
            {
                TrackEvent te = new TrackEvent();
                te.Name = row[1].ToString();
                te.Description = row[2].ToString();
                te.StartTime = (DateTime)row[3];
                te.EndTime = (DateTime)row[4];
                list.Add(te);
            }

            return list;
        }*/
    }
}
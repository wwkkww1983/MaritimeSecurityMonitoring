﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace dataAnadll
{
    public class PhotoelectricControl
    {
        public PhotoelectricControl()
        { }
        /// <summary>
        /// 光电主控权获取
        /// </summary>
        /// <param name="UserID">用户ID</param>
        /// <returns></returns>
        public int GetPhotoelectricControl(int UserID,out string Msg)
        {
            Dictionary<int, string> result = new Dictionary<int, string>();
            int ID = -3;
            Msg = "";
            if(GetFlagCount(ref ID,ref Msg))
            {
                if (UserID == ID)
                {
                    return ID;
                }
                return -1;
            }
            if (!UpdatePhotoelectricControl(UserID, 1))
            {
                InsertPhotoelectricControl(UserID);
            }
            ID = UserID;
            return ID;
        }

        /// <summary>
        /// 查询是否有控制权
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        private bool GetFlagCount(ref int UserID,ref string msg)
        {
            string sql = "SELECT id,name from user_manage,photoelectric_control where user_manage.id = photoelectric_control.user_id and photoelectric_control.ctr_flag = 1;";
            try
            {
                DataTable dt = null;
                var db = MysqlDBAccess.getInstance();
                int num = db.query(sql, ref dt);
                if (num == 1)
                {
                    UserID = (int)dt.Rows[0][0];
                    msg = "用户："+dt.Rows[0][1].ToString()+",已拥有控制权";
                    return true;
                }else if(num >1)
                {
                    msg = "控制权冲突";
                    return true;
                }
                else
                {
                    UserID = 0;
                    return false;
                }
            }catch
            {
                msg = "获取异常";
                return true;
            }
        }
        /// <summary>
        /// 用户权变更
        /// </summary>
        /// <param name="ID">用户ID</param>
        /// <param name="ctr">开关  1开 | 0关</param>
        /// <returns></returns>
        public bool UpdatePhotoelectricControl(int ID,int ctr = 0)
        {
            string sql = string.Format("UPDATE photoelectric_control set ctr_flag = {0} WHERE user_id ={1} and ctr_flag = 1;",
                ctr, ID);
            if(ctr == 1)
                {
                sql = string.Format("UPDATE photoelectric_control set ctr_flag = {0} WHERE user_id ={1};",
                ctr, ID);
                }
                try
                {
                var db = MysqlDBAccess.getInstance();
                int num = db.queryNoResponse(sql);
                if (num >= 1)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch
                {
                    return false;
                }
            }

        private bool InsertPhotoelectricControl(int ID)
        {
            string sql = string.Format("INSERT INTO photoelectric_control (user_id,ctr_flag) VALUES ({0},{1});",
                ID, 1);
            try
            {
                var db = MysqlDBAccess.getInstance();
                int num = db.queryNoResponse(sql);
                if (num >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
    }   
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YimaEncCtrl;

namespace dataAnadll
{
    public class DataHelper
    {
        public static Dictionary<int, string> CountryMap = new Dictionary<int, string>();
        public static Dictionary<int, string> AISTypeMap = new Dictionary<int, string>();
        public static Dictionary<int, string> SailStatusMap = new Dictionary<int, string>();
        public static Dictionary<int, string> ShipTypeMap = new Dictionary<int, string>();
        public static string DateTimeFormStr = "yyyy-MM-dd HH:mm:ss";
        private static DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
        public static DateTime ConvertIntDateTime(uint utime)
        {
            DateTime time = DateTime.MinValue;
            DateTime tmpTime = startTime;
            time = tmpTime.AddSeconds(utime);
            return time;
        }

        static DataHelper()
        {
            CountryMap.Add(412, "中国");
            CountryMap.Add(413, "中国");
            CountryMap.Add(574, "越南");
            CountryMap.Add(576, "越南");
            CountryMap.Add(533, "马来西亚");

            AISTypeMap.Add(0, "Class_A");
            AISTypeMap.Add(1, "Class_B");
            AISTypeMap.Add(2, "基站");
            AISTypeMap.Add(3, "航标");
            AISTypeMap.Add(4, "搜索直升机");
            AISTypeMap.Add(5, "START搜救应答器");


            SailStatusMap.Add(0, "发动机使用中");
            SailStatusMap.Add(1, "锚泊");
            SailStatusMap.Add(2, "未操纵");
            SailStatusMap.Add(3, "有限适航性");
            SailStatusMap.Add(4, "受船舶吃水限制");
            SailStatusMap.Add(5, "系泊");
            SailStatusMap.Add(6, "搁浅");
            SailStatusMap.Add(7, "从事捕捞");
            SailStatusMap.Add(8, "航行中");
            SailStatusMap.Add(9, "留做将来修正导航状态");
            SailStatusMap.Add(10, "留做将来修正导航状态");
            SailStatusMap.Add(11, "留做将来用");
            SailStatusMap.Add(12, "留做将来用");
            SailStatusMap.Add(13, "留做将来用");
            SailStatusMap.Add(14, "AIS-SART（现行的）");
            SailStatusMap.Add(15, "未规定，默认值（也用于测试中的AIS-SART）");


            ShipTypeMap.Add(20, "WIG，一般");
            ShipTypeMap.Add(21, "WIG，载运危险品，X（2）污染物");
            ShipTypeMap.Add(22, "WIG，载运危险品，Y（2）污染物");
            ShipTypeMap.Add(23, "WIG，载运危险品，Z（2）污染物");
            ShipTypeMap.Add(24, "WIG，载运危险品，OS（2）污染物");
            ShipTypeMap.Add(30, "船舶，捕捞");
            ShipTypeMap.Add(31, "船舶，拖船");
            ShipTypeMap.Add(32, "船舶，拖船（推带长度超过200\r\nm或宽度超过25 m）");
            ShipTypeMap.Add(33, "船舶，从事挖掘或水下作业");
            ShipTypeMap.Add(34, "船舶，从事潜水作业");
            ShipTypeMap.Add(35, "船舶，从事军事行动");
            ShipTypeMap.Add(36, "船舶，帆船");
            ShipTypeMap.Add(37, "船舶，游艇");
            ShipTypeMap.Add(40, "HSC，一般");
            ShipTypeMap.Add(41, "HSC，载运危险品，X（2）污染物");
            ShipTypeMap.Add(42, "HSC，载运危险品，Y（2）污染物");
            ShipTypeMap.Add(43, "HSC，载运危险品，Z（2）污染物");
            ShipTypeMap.Add(44, "HSC，载运危险品，OS（2）污染物");
            ShipTypeMap.Add(50, "引航船舶");
            ShipTypeMap.Add(51, "搜救船舶");
            ShipTypeMap.Add(52, "拖轮");
            ShipTypeMap.Add(53, "港口补给船");
            ShipTypeMap.Add(54, "安装有防污染设施或设备的船舶");
            ShipTypeMap.Add(55, "执法船舶");
            ShipTypeMap.Add(56, "备用 – 当地船舶指配使用");
            ShipTypeMap.Add(57, "备用 – 当地船舶指配使用");
            ShipTypeMap.Add(58, "医疗运送船舶");
            ShipTypeMap.Add(59, "非武装冲突参与国的船舶和航空器");
            ShipTypeMap.Add(60, "客轮，一般");
            ShipTypeMap.Add(61, "客轮，载运危险品，X（2）污染物");
            ShipTypeMap.Add(62, "客轮，载运危险品，Y（2）污染物");
            ShipTypeMap.Add(63, "客轮，载运危险品，Z（2）污染物");
            ShipTypeMap.Add(64, "客轮，载运危险品，OS（2）污染物");
            ShipTypeMap.Add(70, "货轮，一般");
            ShipTypeMap.Add(71, "货轮，载运危险品，X（2）污染物");
            ShipTypeMap.Add(72, "货轮，载运危险品，Y（2）污染物");
            ShipTypeMap.Add(73, "货轮，载运危险品，Z（2）污染物");
            ShipTypeMap.Add(74, "货轮，载运危险品，OS（2）污染物");
            ShipTypeMap.Add(80, "油轮，一般");
            ShipTypeMap.Add(81, "油轮，载运危险品，X（2）污染物");
            ShipTypeMap.Add(82, "油轮，载运危险品，Y（2）污染物");
            ShipTypeMap.Add(83, "油轮，载运危险品，Z（2）污染物");
            ShipTypeMap.Add(84, "油轮，载运危险品，OS（2）污染物");
            ShipTypeMap.Add(90, "其他船舶，一般");
            ShipTypeMap.Add(91, "其他船舶，载运危险品，X（2）污染物");
            ShipTypeMap.Add(92, "其他船舶，载运危险品，Y（2）污染物");
            ShipTypeMap.Add(93, "其他船舶，载运危险品，Z（2）污染物");
            ShipTypeMap.Add(94, "其他船舶，载运危险品，OS（2）污染物");
        }

        public static uint ConvertDateTime2UnixTime(DateTime dt)
        {
            uint intResult = 0;
            intResult = Convert.ToUInt32((dt - startTime).TotalSeconds);
            return intResult;
        }


        public static GeoPoint GetGeoPoint(double longitude, double latitude, int multFactor)
        {
            GeoPoint gp = new GeoPoint();
            gp.x = Convert.ToInt32(longitude * multFactor);
            gp.y = Convert.ToInt32(latitude * multFactor);
            return gp;
        }

        public static string PointList2Str(List<GeoPoint> list, int geoMultFactor)
        {
            string pointStr = "";
            foreach (var gp in list)
            {
                if (gp != null)
                {
                    double x = (double)gp.x / geoMultFactor;
                    double y = (double)gp.y / geoMultFactor;
                    pointStr += string.Format("{0:R},{1:R},0;", x, y);
                }
            }
            return pointStr;
        }

        public static List<GeoPoint> PointStr2List(string pointStr, int geoMultFactor)
        {
            List<GeoPoint> list = new List<GeoPoint>();
            foreach (var points in pointStr.Split(';'))
            {
                if (points.Length > 0)
                {
                    var tmp = points.Split(',');
                    GeoPoint gp = new GeoPoint();
                    gp.x = Convert.ToInt32(double.Parse(tmp[0]) * geoMultFactor);
                    gp.y = Convert.ToInt32(double.Parse(tmp[1]) * geoMultFactor);
                    list.Add(gp);
                }
            }
            return list;
        }
    }
}
